#!/usr/bin/env python3
"""Collect CSS BB codes using BP-OSD, QDistRnd and QDistEvol upper bounds.

Defaults: 10000 accepted codes, 1000 trials PER method PER code, min upper
bound <=14. No SAT, MILP, enumeration, RIS teaching routine or neural labels.
Run --dry-run without scientific dependencies to inspect candidate inputs.
SQLite is the durable source of truth; JSONL files are reviewable exports.
"""
from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import multiprocessing
import sqlite3
import sys
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path

from bb_distance_candidates import candidate_for_index, SAMPLER_VERSION, DEDUP_SCOPE

METHODS = ("BP-OSD", "QDistRnd", "QDistEvol")
HERE = Path(__file__).resolve().parent
SCHEMA_VERSION = 1


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def json_text(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False)


def sha256_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2,
                                    allow_nan=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def write_jsonl(path, rows):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8") as stream:
        for row in rows:
            stream.write(json_text(row) + "\n")
    temporary.replace(path)


class RunLock:
    """Prevent simultaneous jobs from duplicating the same search budget."""
    def __init__(self, path):
        self.path = Path(path)

    def __enter__(self):
        self.handle = self.path.open("a+")
        try:
            fcntl.flock(self.handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            self.handle.close()
            raise RuntimeError("This output directory is already in use by another process")
        return self

    def __exit__(self, *_):
        self.handle.close()


def open_database(path, config):
    db = sqlite3.connect(path)
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("PRAGMA synchronous=FULL")
    db.execute("PRAGMA foreign_keys=ON")
    db.executescript("""
      CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS candidates (
        id TEXT PRIMARY KEY, candidate_index INTEGER UNIQUE NOT NULL,
        canonical_key TEXT UNIQUE NOT NULL, payload TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS attempts (
        attempt_index INTEGER PRIMARY KEY, outcome TEXT NOT NULL,
        candidate_id TEXT, reason TEXT);
      CREATE TABLE IF NOT EXISTS results (
        candidate_id TEXT NOT NULL REFERENCES candidates(id),
        method TEXT NOT NULL, payload TEXT NOT NULL,
        PRIMARY KEY(candidate_id, method));
    """)
    existing = db.execute("SELECT value FROM metadata WHERE key='config'").fetchone()
    if existing and json.loads(existing[0]) != config:
        db.close()
        raise ValueError("Run configuration/source changed; use a new output directory")
    with db:
        if not existing:
            db.execute("INSERT INTO metadata VALUES ('config', ?)", (json_text(config),))
            db.execute("INSERT INTO metadata VALUES ('created_utc', ?)", (utc_now(),))
    return db


def store_result(db, result):
    if result.get("method") not in METHODS:
        raise ValueError("Unknown method result")
    with db:
        # No REPLACE: a finished method can never silently acquire a second budget.
        db.execute("INSERT INTO results VALUES (?, ?, ?)",
                   (result["id"], result["method"], json_text(result)))


def result_seed(seed, row, method):
    material = f"bb1000:{seed}:{row['id']}:{method}"
    return int.from_bytes(hashlib.sha256(material.encode()).digest()[:4], "big")


def classify(row, records, trials, max_upper):
    """Build a training record only from three completed, validated budgets."""
    by_method = {record["method"]: record for record in records}
    if len(records) != len(by_method) or any(m not in METHODS for m in by_method):
        raise ValueError("Duplicate or unrecognized methods")
    if len(by_method) != 3:
        return "unfinished", None
    if any(r.get("id") != row["id"] or r.get("status") != "ok"
           or r.get("requested_trials") != trials or r.get("returned_trials") != trials
           or not r.get("budget_completed") or not r.get("valid_upper_bound")
           or type(r.get("d_upper")) is not int or r["d_upper"] < 1
           for r in records):
        return "method_failed", None
    best = min((by_method[m] for m in METHODS), key=lambda record: record["d_upper"])
    if best["d_upper"] > max_upper:
        # This does NOT prove the true distance exceeds max_upper.
        return "upper_above_threshold", None
    label = dict(row)
    label.update(
        d_upper=best["d_upper"], d_exact=None, is_exact=False,
        label_kind="heuristic_upper_bound",
        label_rule="minimum validated witness weight after all three complete budgets",
        selected_method=best["method"], trials_per_method=trials,
        witness_type="Z", witness_format="qubit_indices_0_based",
        witness=best["witness"]["Z"],
        methods={m: {key: by_method[m].get(key) for key in (
            "d_upper", "returned_distance", "reported_distance_matches_weight",
            "requested_trials", "returned_trials", "seed_argument",
            "algorithm_wall_seconds", "algorithm_cpu_seconds")}
                 for m in METHODS},
        certification="Validated nontrivial logical witness; no optimality proof",
    )
    return "accepted", label


def snapshot(db, config, output, include_audit=False, state="running"):
    grouped = defaultdict(list)
    raw_results = [json.loads(payload) for (payload,) in db.execute(
        "SELECT payload FROM results ORDER BY candidate_id, method")]
    for record in raw_results:
        grouped[record["id"]].append(record)
    candidates = [json.loads(payload) for (payload,) in db.execute(
        "SELECT payload FROM candidates ORDER BY candidate_index")]
    labels, audits = [], []
    outcomes = Counter()
    for row in candidates:
        outcome, label = classify(row, grouped[row["id"]], config["trials"], config["max_upper"])
        outcomes[outcome] += 1
        if label is not None:
            labels.append(label)
        if include_audit:
            audits.append(dict(row, label_outcome=outcome))
    if len(labels) > config["target"]:
        raise RuntimeError("Internal error: more accepted codes than the target")
    attempts = dict(db.execute("SELECT outcome, count(*) FROM attempts GROUP BY outcome"))
    stats = {
        "updated_utc": utc_now(), "state": state,
        "target": config["target"], "accepted": len(labels),
        "target_reached": len(labels) == config["target"],
        "requested_trials_per_method": config["trials"],
        "max_upper": config["max_upper"], "exactly_certified_count": 0,
        "candidate_proposals": sum(attempts.values()), "proposal_outcomes": attempts,
        "distinct_candidates_searched_or_pending": len(candidates),
        "candidate_outcomes": dict(outcomes), "saved_method_results": len(raw_results),
        "completed_method_budgets": sum(bool(r.get("budget_completed")) for r in raw_results),
        "recorded_actual_trials": sum(r.get("returned_trials") or 0 for r in raw_results),
        "algorithm_cpu_seconds": sum(r.get("algorithm_cpu_seconds") or 0 for r in raw_results),
        "sum_algorithm_wall_seconds": sum(r.get("algorithm_wall_seconds") or 0 for r in raw_results),
        "wall_time_note": "Sum of individual calls; not whole-job elapsed time",
        "accepted_upper_histogram": dict(sorted(Counter(r["d_upper"] for r in labels).items())),
        "accepted_length_strata": dict(Counter(r["length_stratum"] for r in labels)),
        "accepted_connected": sum(r["connected"] for r in labels),
        "dedup_scope": DEDUP_SCOPE,
        "sampling_warning": "Upper-bound filtering changes the accepted distribution; not paper's dataset",
    }
    write_jsonl(output / "accepted.jsonl", labels)
    write_json(output / "summary.json", stats)
    if include_audit:
        write_jsonl(output / "candidates.jsonl", audits)
        write_jsonl(output / "methods.jsonl", raw_results)
        write_jsonl(output / "attempts.jsonl", (
            {"attempt_index": index, "outcome": outcome, "candidate_id": cid, "reason": reason}
            for index, outcome, cid, reason in db.execute("SELECT * FROM attempts ORDER BY attempt_index")))
    return stats


def fill_batch(db, config, size, max_candidates, max_attempts):
    pending = [json.loads(payload) for (payload,) in db.execute("""
      SELECT c.payload FROM candidates c LEFT JOIN results r ON r.candidate_id=c.id
      GROUP BY c.id HAVING count(r.method)<3 ORDER BY c.candidate_index LIMIT ?
    """, (size,))]
    distinct = db.execute("SELECT count(*) FROM candidates").fetchone()[0]
    index = db.execute("SELECT COALESCE(max(attempt_index)+1,0) FROM attempts").fetchone()[0]
    with db:
        while len(pending) < size and distinct < max_candidates and index < max_attempts:
            proposal = candidate_for_index(index, config["seed"], **config["sampling"])
            row = proposal["candidate"]
            outcome, reason, candidate_id = "structural_rejection", proposal["reason"], None
            if proposal["status"] == "ok":
                previous = db.execute("SELECT id FROM candidates WHERE canonical_key=?",
                                      (row["canonical_key"],)).fetchone()
                if previous:
                    outcome, reason, candidate_id = "duplicate", DEDUP_SCOPE, previous[0]
                else:
                    db.execute("INSERT INTO candidates VALUES (?, ?, ?, ?)",
                               (row["id"], index, row["canonical_key"], json_text(row)))
                    pending.append(row)
                    distinct += 1
                    outcome, reason, candidate_id = "scheduled", None, row["id"]
            db.execute("INSERT INTO attempts VALUES (?, ?, ?, ?)",
                       (index, outcome, candidate_id, reason))
            index += 1
    return pending


def execute_batch(db, rows, config, executor, runner):
    futures = {}
    for row in rows:
        completed = {m for (m,) in db.execute(
            "SELECT method FROM results WHERE candidate_id=?", (row["id"],))}
        for method in METHODS:
            if method not in completed:
                future = executor.submit(runner, row, method, config["trials"],
                                         result_seed(config["seed"], row, method))
                futures[future] = row["id"], method
    failures = []
    for future in as_completed(futures):
        # Worker crashes/interrupts do not become finished budgets. Resume reruns
        # only calls that have no committed result; their lost work is extra cost.
        result = future.result()
        expected_id, expected_method = futures[future]
        if (result.get("id"), result.get("method")) != (expected_id, expected_method):
            raise RuntimeError("Worker returned a result for the wrong task")
        store_result(db, result)
        if result.get("status") != "ok":
            failures.append(result)
        print(json_text({"event": "method_finished", "id": result["id"],
                         "method": result["method"], "status": result["status"],
                         "trials": result.get("returned_trials"),
                         "d_upper": result.get("d_upper")}), flush=True)
    return failures


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=HERE / "runs/bb-distance-10000")
    parser.add_argument("--target", type=int, default=10000)
    parser.add_argument("--trials", type=int, default=1000)
    parser.add_argument("--max-upper", type=int, default=14)
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--seed", type=int, default=20261028)
    parser.add_argument("--max-candidates", type=int, default=70000,
                        help="Stop incomplete rather than search unlimited distinct codes")
    parser.add_argument("--max-attempts", type=int, default=7000000)
    parser.add_argument("--n-min", type=int, default=18)
    parser.add_argument("--n-max", type=int, default=360)
    parser.add_argument("--ell-min", type=int, default=3)
    parser.add_argument("--ell-max", type=int, default=30)
    parser.add_argument("--m-min", type=int, default=3)
    parser.add_argument("--m-max", type=int, default=30)
    parser.add_argument("--terms-a", type=int, default=3)
    parser.add_argument("--terms-b", type=int, default=3)
    parser.add_argument("--dry-run", action="store_true",
                        help="Print eight valid candidate inputs; perform no distance searches")
    parser.add_argument("--export-only", action="store_true",
                        help="Regenerate exports from an existing journal without searching")
    args = parser.parse_args(argv)
    for name in ("target", "trials", "max_upper", "workers", "max_candidates", "max_attempts"):
        if getattr(args, name) < 1:
            parser.error(f"--{name.replace('_', '-')} must be positive")
    if args.trials < 100:
        parser.error("Use at least 100 total trials for the 100-generation QDistEvol configuration")
    if args.seed < 0 or args.max_candidates < args.target or args.max_attempts < args.target:
        parser.error("Seed must be nonnegative and search caps must be >= target")
    if args.dry_run and args.export_only:
        parser.error("--dry-run and --export-only are mutually exclusive")
    return args


def main(argv=None):
    args = parse_args(argv)
    sampling = {key: getattr(args, key) for key in (
        "ell_min", "ell_max", "m_min", "m_max", "n_min", "n_max", "terms_a", "terms_b")}
    # Validate dimensions and support sizes before any backend initialization.
    candidate_for_index(0, args.seed, **sampling)
    if args.dry_run:
        rows, keys = [], set()
        for index in range(min(args.max_attempts, 10000)):
            proposal = candidate_for_index(index, args.seed, **sampling)
            row = proposal["candidate"]
            if proposal["status"] == "ok" and row["canonical_key"] not in keys:
                rows.append(row)
                keys.add(row["canonical_key"])
                if len(rows) == 8:
                    break
        print(json.dumps({"mode": "dry_run_no_distance_search", "target": args.target,
                          "trials_per_method": args.trials, "max_upper": args.max_upper,
                          "methods": METHODS, "examples": rows}, ensure_ascii=False, indent=2))
        return 0

    from bb_distance_backend import backend_manifest, init_worker, run_method
    source = backend_manifest()
    config = {"schema_version": SCHEMA_VERSION, "target": args.target, "trials": args.trials,
              "max_upper": args.max_upper, "seed": args.seed, "sampling": sampling,
              "sampler_version": SAMPLER_VERSION, "methods": list(METHODS),
              "source": source,
              "driver_hashes": {name: sha256_file(HERE / name) for name in (
                  "generate_bb_distance_dataset.py", "bb_distance_backend.py",
                  "bb_distance_candidates.py", "bb_code_algebra.py")}}
    output = args.output_dir.expanduser().resolve()
    if args.export_only and not (output / "state.sqlite3").is_file():
        raise ValueError("--export-only requires an existing state.sqlite3")
    output.mkdir(parents=True, exist_ok=True)
    with RunLock(output / ".run.lock"):
        db = open_database(output / "state.sqlite3", config)
        state = "interrupted"
        try:
            if not (output / "manifest.json").exists():
                write_json(output / "manifest.json", {"created_utc": utc_now(), "config": config,
                    "budget_rule": "Exactly one complete call per code/method, no threshold early stop",
                    "resume_rule": "Reuse committed calls; rerun interrupted calls from scratch",
                    "label_rule": "All three valid, full budgets; take min upper <= max_upper",
                    "paper_note": "Named methods match paper; candidate sampling and undocumented settings are explicit choices"})
            stats = snapshot(db, config, output)
            if args.export_only:
                state = "complete" if stats["target_reached"] else "exported_incomplete"
                return 0
            if stats["target_reached"]:
                state = "complete"
                print("Target already reached; no searches started.", flush=True)
                return 0
            print(json_text({"event": "starting", "accepted": stats["accepted"],
                             "target": args.target, "workers": args.workers}), flush=True)
            with ProcessPoolExecutor(max_workers=args.workers,
                    mp_context=multiprocessing.get_context("spawn"), initializer=init_worker) as pool:
                while not stats["target_reached"]:
                    # A batch cannot overshoot the requested accepted-record count.
                    size = min(args.workers, args.target - stats["accepted"])
                    rows = fill_batch(db, config, size, args.max_candidates, args.max_attempts)
                    if not rows:
                        state = "candidate_limit_reached"
                        print("Search cap reached before target. Data remain valid but incomplete.", flush=True)
                        return 2
                    failures = execute_batch(db, rows, config, pool, run_method)
                    stats = snapshot(db, config, output)
                    print(json_text({"event": "batch_finished", "accepted": stats["accepted"],
                                     "target": args.target, "outcomes": stats["candidate_outcomes"]}), flush=True)
                    if failures:
                        state = "method_error"
                        print("A method failed validation/execution; inspect methods.jsonl. "
                              "Failed codes are excluded. Fix the cause before resuming.", file=sys.stderr)
                        return 1
            state = "complete"
            return 0
        finally:
            try:
                snapshot(db, config, output, include_audit=True, state=state)
            finally:
                db.close()


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(130)
