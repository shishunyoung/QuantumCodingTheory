#!/usr/bin/env python3
"""Deterministic CSS BB candidate construction; no distance search is performed.

Code construction, binary rank, commutation and structural bookkeeping use the
standalone bb_code_algebra helpers, which contain no distance-search routines.
The sampling distribution is explicit and is not claimed to reproduce the
unreleased candidate distribution of the BBNet paper.
"""
from __future__ import annotations

import hashlib
import json
import random
from functools import lru_cache

from bb_code_algebra import (
    build_css_matrices, canonical_group, commutes, gf2_rank,
)


SAMPLER_VERSION = "css_bb_stratified_axis_grid_v1"
DEDUP_SCOPE = "independent_cyclic_translations_A_B_swap_coordinate_axis_swap_only"


def _integer(value, name, minimum=0):
    if type(value) is not int or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")
    return value


def _support(support, ell, m, name):
    pairs = []
    for pair in support:
        if len(pair) != 2:
            raise ValueError(f"{name} monomials need exactly two exponents")
        a = _integer(pair[0], f"{name}.a")
        b = _integer(pair[1], f"{name}.b")
        if a >= ell or b >= m:
            raise ValueError(f"{name} exponents are outside the cyclic grid")
        pairs.append((a, b))
    if not pairs or len(set(pairs)) != len(pairs):
        raise ValueError(f"{name} must be nonempty and contain no repeated monomials")
    return tuple(sorted(pairs))


def canonical_key(row):
    """Deduplicate only the explicitly supported CSS symmetries.

    Equal keys prove equivalence under these symmetries.  Unequal keys do not
    prove inequivalence under every qubit permutation or group presentation.
    No distance value enters this key.
    """
    ell = _integer(row["ell"], "ell", 1)
    m = _integer(row["m"], "m", 1)
    if row.get("C") or row.get("D"):
        raise ValueError("This sampler supports CSS BB codes only")
    a = _support(row["A"], ell, m, "A")
    b = _support(row["B"], ell, m, "B")
    key, _ = canonical_group(ell, m, a, b)
    return key


def _component_count(n, check_sets):
    """Number of components in the joint CSS Tanner graph.

    Joining the qubits of each nonzero check gives the same component count
    as including that check as a graph vertex.  Isolated qubits are retained.
    """
    parent = list(range(n))

    def find(value):
        while parent[value] != value:
            parent[value] = parent[parent[value]]
            value = parent[value]
        return value

    for checks in check_sets:
        for original in checks:
            row = original
            if not row:
                continue
            first = (row & -row).bit_length() - 1
            while row:
                bit = row & -row
                a, b = find(first), find(bit.bit_length() - 1)
                if a != b:
                    parent[b] = a
                row ^= bit
    return len({find(i) for i in range(n)})


def structural_metadata(ell, m, A, B):
    """Compute n,k and check commutation, without evaluating any distance."""
    ell, m = _integer(ell, "ell", 1), _integer(m, "m", 1)
    a, b = _support(A, ell, m, "A"), _support(B, ell, m, "B")
    hx, hz = build_css_matrices(ell, m, a, b)
    if not commutes(hx, hz):
        raise ValueError("Constructed CSS checks do not commute")
    n = 2 * ell * m
    rx, rz = gf2_rank(hx), gf2_rank(hz)
    components = _component_count(n, (hx, hz))
    return {
        "n": n, "k": n - rx - rz,
        "rank_hx": rx, "rank_hz": rz,
        "commutation_checked": True,
        "css_tanner_components": components,
        "connected": components == 1,
    }


@lru_cache(maxsize=32)
def _dimension_strata(ell_min, ell_max, m_min, m_max, n_min, n_max,
                      terms_a, terms_b):
    for name, value in locals().copy().items():
        _integer(value, name, 1)
    if ell_min > ell_max or m_min > m_max or n_min > n_max:
        raise ValueError("Minimum range endpoints must not exceed maxima")
    # Five fixed intervals for the defaults: 18..72,73..144,145..216,
    # 217..288,289..360.  Requested smaller/larger ranges intersect these
    # intervals; n>360 gets an extra interval rather than silently vanishing.
    edges = [(1, 72), (73, 144), (145, 216), (217, 288), (289, 360)]
    if n_max > 360:
        edges.append((361, n_max))
    result = []
    for lower, upper in edges:
        lower, upper = max(lower, n_min), min(upper, n_max)
        if lower > upper:
            continue
        pairs = tuple(
            (ell, m)
            for ell in range(ell_min, ell_max + 1)
            for m in range(m_min, m_max + 1)
            if lower <= 2 * ell * m <= upper
            # Both axis and grid sampling must be able to supply the terms.
            and ell + m - 1 >= max(terms_a, terms_b)
        )
        if pairs:
            result.append((lower, upper, pairs))
    if not result:
        raise ValueError("No lattice meets the requested ranges and support sizes")
    return tuple(result)


def candidate_for_index(index, seed, ell_min=3, ell_max=30, m_min=3, m_max=30,
                        n_min=18, n_max=360, terms_a=3, terms_b=3):
    """Generate one independently seeded proposal, including k=0 rejections.

    The result is ``{status, reason, candidate}``.  A rejected proposal retains
    its construction and structural audit in ``candidate`` for traceability.
    Status ``ok`` only means that the code encodes at least one logical qubit;
    it says nothing about the code's distance or uniqueness in a dataset.

    Proposals rotate through nonempty length strata.  In each stratum they
    alternate axis and full-grid supports, with each chosen lattice equally
    likely inside that stratum.  Label filtering changes the accepted-data
    distribution, which need not be balanced across strata or distances.
    Connected and disconnected codes are both retained and explicitly marked.
    """
    _integer(index, "index")
    _integer(seed, "seed")
    settings = dict(ell_min=ell_min, ell_max=ell_max, m_min=m_min, m_max=m_max,
                    n_min=n_min, n_max=n_max, terms_a=terms_a, terms_b=terms_b)
    strata = _dimension_strata(**settings)
    lower, upper, dimensions = strata[index % len(strata)]
    family = "axis" if (index // len(strata)) % 2 == 0 else "grid"
    material = {"version": SAMPLER_VERSION, "index": index, "seed": seed,
                "settings": settings}
    digest = hashlib.sha256(json.dumps(material, sort_keys=True,
                                      separators=(",", ":")).encode()).hexdigest()
    candidate_seed = int(digest[:16], 16)
    rng = random.Random(candidate_seed)
    ell, m = rng.choice(dimensions)
    if family == "axis":
        pool = [(a, 0) for a in range(ell)] + [(0, b) for b in range(1, m)]
    else:
        pool = [(a, b) for a in range(ell) for b in range(m)]
    A = sorted(rng.sample(pool, terms_a))
    B = sorted(rng.sample(pool, terms_b))
    row = {
        "id": f"bb-{index:09d}-{digest[:12]}",
        "candidate_index": index, "raw_attempt": index + 1,
        "candidate_seed": candidate_seed,
        "sampler_version": SAMPLER_VERSION,
        "family": "CSS", "sampling_family": family,
        "length_stratum": f"n{lower}-{upper}",
        "ell": ell, "m": m,
        "A": [list(pair) for pair in A], "B": [list(pair) for pair in B],
        "C": [], "D": [], "support_sizes": [terms_a, terms_b],
        "dedup_scope": DEDUP_SCOPE,
    }
    row.update(structural_metadata(ell, m, A, B))
    row["canonical_key"] = canonical_key(row)
    # Existing train_css uses group_id to keep equivalent codes in one split.
    row["group_id"] = row["canonical_key"]
    if row["k"] <= 0:
        return {"status": "rejected", "reason": "no_logical_qubits", "candidate": row}
    return {"status": "ok", "reason": None, "candidate": row}
