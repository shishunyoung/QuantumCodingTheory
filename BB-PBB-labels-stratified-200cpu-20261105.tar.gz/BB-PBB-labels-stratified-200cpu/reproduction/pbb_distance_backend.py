#!/usr/bin/env python3
"""Full-symplectic PBB adapters for three unmodified, frozen heuristics.

Imports are standard-library only until init_worker.  Each run_method performs
one complete upstream call with its requested budget; there are no warmups,
distance thresholds, or substitute solvers.  Returned logical operators are
validated in the original 2*n coordinates and weighted by popcount(X | Z).
"""
from __future__ import annotations

import contextlib
import hashlib
import os
from pathlib import Path
import time
import traceback

import bb_distance_backend as frozen
from pbb_code_algebra import pauli_weight, prepare_code, validate_witness

SOURCE_COMMIT = frozen.SOURCE_COMMIT
VENDOR_DIR = frozen.VENDOR_DIR
METHODS = frozen.METHODS
METHOD_IDS = frozen.METHOD_IDS
THREAD_VARIABLES = frozen.THREAD_VARIABLES
SEED_LIMITATION = frozen.SEED_LIMITATION
DEFAULT_TRIALS = 10000
_WORKER = {}


def method_params(method, trials=DEFAULT_TRIALS):
    return frozen.method_params(method, trials)


def backend_manifest():
    """Verify the frozen backend and disclose the different search space."""
    manifest = frozen.backend_manifest()
    manifest.update({
        "adapter_sha256": frozen._sha256(__file__),
        "shared_backend_helpers_sha256": frozen._sha256(frozen.__file__),
        "construction_helpers_sha256": frozen._sha256(
            Path(__file__).with_name("pbb_code_algebra.py")),
        "shared_binary_algebra_sha256": frozen._sha256(
            Path(__file__).with_name("bb_code_algebra.py")),
        "default_trials_per_method": DEFAULT_TRIALS,
        "default_params": {method: method_params(method) for method in METHODS},
        "search_scope": "full PBB stabilizer normalizer modulo stabilizer; tB=2",
        "physical_weight": "popcount(X | Z); Y counts as one physical qubit",
        "raw_distance_policy": (
            "Retain upstream d unchanged; use physical weight of the independently "
            "verified returned logical operator as the upper bound, flag differences."
        ),
        "budget_convention": "each of three methods receives the full requested trials",
        "required_input": "commuting, positive-k, genuinely non-CSS stabilizer rowspace",
    })
    return manifest


def init_worker():
    """Reuse the pinned import verification; perform no search during setup."""
    if not _WORKER:
        backend_manifest()
        metadata = frozen.init_worker()
        _WORKER.update(np=frozen._WORKER["np"], cd=frozen._WORKER["cd"],
                       metadata=metadata)
    return _WORKER["metadata"]


def _prepare_candidate(candidate):
    prepared = prepare_code(candidate)
    if prepared["k"] <= 0:
        raise ValueError("Candidate must have k > 0")
    if not prepared["structure"]["non_css"]:
        raise ValueError("Candidate stabilizer rowspace is CSS, not a genuine PBB sample")
    return prepared


def verify_result(prepared, raw, trials):
    """Validate a full budget and original-coordinate nontrivial Pauli witness."""
    count = frozen._exact_int(raw.get("T"), "Returned trial count")
    if count != trials:
        raise ValueError(f"Incomplete trial budget: returned {count}, required {trials}")
    distance = frozen._exact_int(raw.get("d"), "Returned distance")
    bits = frozen._json_safe(raw.get("L", []))
    n = prepared["n"]
    if not isinstance(bits, (tuple, list)) or len(bits) != 2 * n:
        raise ValueError("Returned Pauli witness must be a flat vector of length 2*n")
    if any(type(bit) is not int or bit not in (0, 1) for bit in bits):
        raise ValueError("Returned Pauli witness must contain binary integer bits")
    vector = sum(bit << index for index, bit in enumerate(bits))
    if not validate_witness(vector, prepared):
        raise ValueError("Returned witness is zero, has nonzero syndrome, or is a stabilizer")
    weight = pauli_weight(vector, n)
    witness = {
        "representation": "original grid qubit indices; binary symplectic X|Z",
        "x_indices": [i for i in range(n) if bits[i]],
        "z_indices": [i for i in range(n) if bits[n + i]],
    }
    return {
        "upper_bound": weight, "d_upper": weight, "witness": witness,
        "weight_mismatch": distance != weight,
        "reported_distance_matches_weight": distance == weight,
        "validation": {"zero_symplectic_syndrome": True, "nonstabilizer": True,
                       "physical_weight_recomputed": True, "complete_trial_budget": True},
    }


def run_method(candidate, method, trials=DEFAULT_TRIALS, seed=0):
    """Run exactly one complete method; failed evidence remains explicitly failed."""
    params = method_params(method, trials)
    started, cpu_started = time.perf_counter(), time.process_time()
    result = {
        "id": candidate.get("id"), "method": method, "backend_method": METHOD_IDS[method],
        "trials": trials, "requested_trials": trials, "returned_trials": None,
        "seed_argument": seed, "source_commit": SOURCE_COMMIT, "pid": os.getpid(),
        "started_utc": frozen._utc_now(), "status": "failed", "valid": False,
        "budget_completed": False, "valid_upper_bound": False,
        "upper_bound": None, "d_upper": None, "witness": None,
        "raw_distance": None, "returned_distance": None, "returned_witness_bits": None,
        "weight_mismatch": None, "reported_distance_matches_weight": None,
        "requested_params": dict(params), "effective_params": None,
        "algorithm_wall_seconds": None, "algorithm_cpu_seconds": None,
        "ell": candidate["ell"], "m": candidate["m"],
        "n": 2 * candidate["ell"] * candidate["m"],
        "label_kind": "verified_heuristic_upper_bound", "is_exact": False,
    }
    capture = frozen._Capture()
    try:
        if not _WORKER:
            init_worker()
        result["worker_metadata"] = _WORKER["metadata"]
        np, cd = _WORKER["np"], _WORKER["cd"]
        prep_start, prep_cpu = time.perf_counter(), time.process_time()
        prepared = _prepare_candidate(candidate)
        matrix = np.asarray([[(row >> i) & 1 for i in range(2 * prepared["n"])]
                             for row in prepared["stabilizers"]], dtype=np.int8)
        result.update(k=prepared["k"], structure=prepared["structure"],
                      preparation_wall_seconds=time.perf_counter() - prep_start,
                      preparation_cpu_seconds=time.process_time() - prep_cpu)
        algorithm_start, algorithm_cpu = time.perf_counter(), time.process_time()
        try:
            with contextlib.redirect_stdout(capture), contextlib.redirect_stderr(capture):
                raw = cd.codeDistance(matrix, tB=2, method=METHOD_IDS[method],
                                      params=params, seed=seed)
        finally:
            result["algorithm_wall_seconds"] = time.perf_counter() - algorithm_start
            result["algorithm_cpu_seconds"] = time.process_time() - algorithm_cpu
            result["effective_params"] = frozen._json_safe(params)
        result["returned_trials"] = frozen._json_safe(raw.get("T"))
        result["raw_distance"] = result["returned_distance"] = frozen._json_safe(raw.get("d"))
        result["returned_witness_bits"] = frozen._json_safe(raw.get("L", []))
        result["R"] = frozen._json_safe(raw.get("R"))
        result["budget_completed"] = (
            frozen._exact_int(result["returned_trials"], "Returned trial count") == trials)
        progress = str(raw.get("progress", ""))
        result["progress"] = {"text_prefix": progress[:12000],
                              "total_characters": len(progress),
                              "sha256": hashlib.sha256(progress.encode()).hexdigest(),
                              "truncated": len(progress) > 12000}
        verify_start, verify_cpu = time.perf_counter(), time.process_time()
        result.update(verify_result(prepared, raw, trials))
        result.update(status="ok", valid=True, valid_upper_bound=True,
                      verification_wall_seconds=time.perf_counter() - verify_start,
                      verification_cpu_seconds=time.process_time() - verify_cpu)
    except Exception as error:
        result["error"] = f"{type(error).__name__}: {error}"
        result["traceback"] = traceback.format_exc(limit=10)
    result["captured_output"] = capture.result()
    result["elapsed_seconds"] = result["task_wall_seconds"] = time.perf_counter() - started
    result["cpu_seconds"] = result["task_cpu_seconds"] = time.process_time() - cpu_started
    result["finished_utc"] = frozen._utc_now()
    return result


def validate_method_result(candidate, method, result, expected_trials):
    """Parent-side acceptance boundary; never trust a worker's valid flag alone.

    The returned copy contains validated/validation_error. A failed call or any
    contradictory raw evidence cannot be admitted as a completed label.
    """
    checked = dict(result)
    checked.update(validated=False, validation_error=None)
    try:
        params = method_params(method, expected_trials)
        if result.get("method") != method or result.get("backend_method") != METHOD_IDS[method]:
            raise ValueError("Result method does not match requested method")
        if result.get("id") != candidate.get("id"):
            raise ValueError("Result candidate identity does not match")
        if (result.get("source_commit") != SOURCE_COMMIT or
                result.get("requested_params") != params):
            raise ValueError("Result backend pin or requested parameters differ")
        effective = result.get("effective_params")
        if not isinstance(effective, dict):
            raise ValueError("Result has no effective backend parameters")
        # For the pinned full-symplectic paths all explicitly requested values
        # remain unchanged: QDistRnd already requests genCount=1, tB=2 retains
        # GF4blockRep=2, tabuLength=0 does not expand, and randomLO=1 preserves
        # the requested BP-OSD iterCount. Upstream may add method, priors, etc.
        for name, value in params.items():
            if name not in effective or effective[name] != value:
                raise ValueError(f"Effective backend parameter changed: {name}")
        if effective.get("method") != METHOD_IDS[method]:
            raise ValueError("Effective backend method differs from the requested method")
        for field in ("trials", "requested_trials", "returned_trials"):
            if frozen._exact_int(result.get(field), field) != expected_trials:
                raise ValueError(f"Result {field} does not match complete requested budget")
        if (result.get("status") != "ok" or result.get("valid") is not True or
                result.get("valid_upper_bound") is not True or
                result.get("budget_completed") is not True):
            raise ValueError("Worker did not report a successful complete method call")
        if result.get("is_exact") is not False:
            raise ValueError("Heuristic result must not claim exact distance")
        prepared = _prepare_candidate(candidate)
        if (result.get("n") != prepared["n"] or result.get("k") != prepared["k"] or
                result.get("ell") != candidate["ell"] or result.get("m") != candidate["m"]):
            raise ValueError("Result code dimensions differ from independent reconstruction")
        recomputed = verify_result(prepared, {
            "T": result["returned_trials"], "d": result["raw_distance"],
            "L": result["returned_witness_bits"]}, expected_trials)
        for field in ("upper_bound", "d_upper", "witness", "weight_mismatch",
                      "reported_distance_matches_weight"):
            if result.get(field) != recomputed[field]:
                raise ValueError(f"Result {field} contradicts independently checked raw evidence")
        if result.get("returned_distance") != result["raw_distance"]:
            raise ValueError("Returned distance evidence is inconsistent")
        checked.update(validated=True, validation=recomputed["validation"])
    except Exception as error:
        checked["validation_error"] = f"{type(error).__name__}: {error}"
    return checked
