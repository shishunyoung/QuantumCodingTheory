#!/usr/bin/env python3
"""Sparse PBB proposals by exact matching of GF(2) commutation signatures.

For fixed A,B, enumerate all one-/two-term C,D supports and solve
    A C^T + C A^T = B D^T + D B^T
without requiring either side to vanish separately. Candidate generation
samples a bounded number of BB parents and matches, then independently checks
the full stabilizer matrix. It does not compute distances or reproduce the
authors' unpublished candidate distribution. The old product sampler is not
modified and is never used as a fallback.
"""
from __future__ import annotations

from bisect import bisect_right
from collections import Counter, defaultdict
import hashlib
from itertools import combinations
import json
import random

from bb_distance_candidates import (
    _dimension_strata, candidate_for_index as css_candidate_for_index,
    SAMPLER_VERSION as CSS_SAMPLER_VERSION,
)
from pbb_code_algebra import DEDUP_SCOPE, _integer, canonical_key, prepare_code, support


SAMPLER_VERSION = "pbb_sparse_commutation_signature_match_v1"
CONSTRUCTION_FAMILY = "pbb_sparse_joint_commutation_match"
DEFAULT_PERTURBATION_PATTERNS = ((2, 2), (1, 2), (2, 1))


def _dimensions(ell, m):
    _integer(ell, "ell", 1)
    _integer(m, "m", 1)
    if ell > 30 or m > 30 or 2 * ell * m > 360:
        raise ValueError("Signature search requires ell,m<=30 and n=2*ell*m<=360")


def _term_count(value, name):
    if type(value) is not int or value not in (1, 2):
        raise ValueError(name + " must be 1 or 2")
    return value


def normalize_perturbation_patterns(patterns):
    if not isinstance(patterns, (list, tuple)) or not patterns:
        raise ValueError("perturbation_patterns must be a nonempty list/tuple")
    result = []
    for pair in patterns:
        if not isinstance(pair, (list, tuple)) or len(pair) != 2:
            raise ValueError("Each perturbation pattern must be a (C terms,D terms) pair")
        item = (_term_count(pair[0], "terms_c"), _term_count(pair[1], "terms_d"))
        if item in result:
            raise ValueError("Duplicate perturbation pattern")
        result.append(item)
    return tuple(result)


def commutation_signature(ell, m, P, Q):
    """Packed support of P Q^T + Q P^T, bit index x*m+y, over GF(2).

    This polynomial calculation does not use the matrix commutation validator.
    Repeated contributions toggle the same bit, including self-inverse shifts.
    """
    _dimensions(ell, m)
    P, Q = support(P, ell, m, "P"), support(Q, ell, m, "Q")
    signature = 0
    for a, b in P:
        for c, d in Q:
            signature ^= 1 << (((a - c) % ell) * m + (b - d) % m)
            signature ^= 1 << (((c - a) % ell) * m + (d - b) % m)
    return signature


def _signature_buckets(ell, m, P, terms):
    points = tuple((x, y) for x in range(ell) for y in range(m))
    singles = [commutation_signature(ell, m, P, [point]) for point in points]
    buckets = defaultdict(list)
    for indices in combinations(range(len(points)), terms):
        signature = 0
        for index in indices:
            signature ^= singles[index]
        buckets[signature].append(tuple(points[index] for index in indices))
    return buckets


def _match_groups(ell, m, A, B, terms_c, terms_d, require_cross_cancellation):
    _dimensions(ell, m)
    _term_count(terms_c, "terms_c")
    _term_count(terms_d, "terms_d")
    if type(require_cross_cancellation) is not bool:
        raise ValueError("require_cross_cancellation must be a boolean")
    A, B = support(A, ell, m, "A"), support(B, ell, m, "B")
    if min(len(A), len(B)) < 2:
        raise ValueError("A and B need at least two terms")
    left = _signature_buckets(ell, m, A, terms_c)
    right = _signature_buckets(ell, m, B, terms_d)
    signatures = sorted(left.keys() & right.keys())
    if require_cross_cancellation:
        signatures = [signature for signature in signatures if signature]
    groups, cumulative = [], []
    count = 0
    for signature in signatures:
        groups.append((signature, left[signature], right[signature]))
        count += len(left[signature]) * len(right[signature])
        cumulative.append(count)
    return groups, cumulative


def _solution(signature, C, D):
    return {"C": [list(term) for term in C], "D": [list(term) for term in D],
            "cross_signature_hex": hex(signature), "cross_cancellation": signature != 0}


def find_sparse_perturbations(ell, m, A, B, terms_c, terms_d,
                              require_cross_cancellation=False):
    """Yield every fixed-weight commuting pair C,D for the supplied A,B.

    This search is exhaustive in the explicitly requested support sizes, not
    in all possible PBB constructions. Results may have k=0 or CSS rowspace;
    callers must use prepare_code before accepting a code. No distance labels
    or paper examples enter the search. Enumeration may have many results;
    the random sampler below selects via bucket sizes without enumerating
    their full Cartesian products.
    """
    groups, _ = _match_groups(ell, m, A, B, terms_c, terms_d, require_cross_cancellation)
    for signature, left, right in groups:
        for C in left:
            for D in right:
                yield _solution(signature, C, D)


def _solution_at_rank(groups, cumulative, rank):
    group_index = bisect_right(cumulative, rank)
    offset = rank - (cumulative[group_index - 1] if group_index else 0)
    signature, left, right = groups[group_index]
    return _solution(signature, left[offset // len(right)], right[offset % len(right)])


def candidate_for_index(index, seed, ell_min=3, ell_max=30, m_min=3, m_max=30,
                        n_min=18, n_max=360, terms_a=3, terms_b=3,
                        perturbation_patterns=DEFAULT_PERTURBATION_PATTERNS,
                        max_base_attempts=64, max_matches_per_base=8,
                        require_cross_cancellation=True):
    """Return a deterministic bounded proposal in the existing sampler format.

    Patterns rotate by proposal index; this is an explicit proposal policy,
    not a claimed author mixture. Parent draws keep their proposal's lattice
    length stratum and axis/grid mode. All matching C,D pairs have equal
    probability before k/non-CSS rejection within a given parent. At most
    max_matches_per_base distinct pairs are tested, so rejection is NOT a
    proof that no admissible PBB exists for that parent or lattice.

    The parent-k prefilter is exact: projecting a PBB stabilizer to its X
    part gives rank[AB], while its kernel includes [B^T A^T]; hence its rank
    is at least the CSS parent rank and k_PBB <= k_CSS. We still independently
    reconstruct k for every selected PBB, rather than assuming equality.
    """
    _integer(index, "index")
    _integer(seed, "seed")
    for name, value in (("ell_min", ell_min), ("ell_max", ell_max),
                        ("m_min", m_min), ("m_max", m_max)):
        _integer(value, name, 3)
        if value > 30:
            raise ValueError(name + " exceeds 30")
    for name, value in (("n_min", n_min), ("n_max", n_max)):
        _integer(value, name, 18)
        if value > 360:
            raise ValueError(name + " exceeds 360")
    _integer(terms_a, "terms_a", 2)
    _integer(terms_b, "terms_b", 2)
    _integer(max_base_attempts, "max_base_attempts", 1)
    _integer(max_matches_per_base, "max_matches_per_base", 1)
    if type(require_cross_cancellation) is not bool:
        raise ValueError("require_cross_cancellation must be a boolean")
    patterns = normalize_perturbation_patterns(perturbation_patterns)
    base_settings = dict(ell_min=ell_min, ell_max=ell_max, m_min=m_min, m_max=m_max,
                         n_min=n_min, n_max=n_max, terms_a=terms_a, terms_b=terms_b)
    strata = _dimension_strata(**base_settings)
    settings = dict(base_settings, perturbation_patterns=[list(pair) for pair in patterns],
                    max_base_attempts=max_base_attempts, max_matches_per_base=max_matches_per_base,
                    require_cross_cancellation=require_cross_cancellation)
    material = {"version": SAMPLER_VERSION, "index": index, "seed": seed, "settings": settings}
    digest = hashlib.sha256(json.dumps(material, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    candidate_seed = int(digest[:16], 16)
    rng = random.Random(candidate_seed)
    terms_c, terms_d = patterns[index % len(patterns)]
    reasons, attempts = Counter(), []
    last = None
    for attempt in range(max_base_attempts):
        # A stride of two complete stratum cycles preserves axis/grid mode and
        # stratum, while using an independently seeded CSS proposal each time.
        base_index = index // len(patterns) + attempt * 2 * len(strata)
        base = css_candidate_for_index(base_index, candidate_seed, **base_settings)["candidate"]
        ell, m = base["ell"], base["m"]
        row = {
            "id": f"pbb-sparse-{index:09d}-{digest[:12]}",
            "candidate_index": index, "raw_attempt": index + 1,
            "candidate_seed": candidate_seed, "sampler_seed": seed,
            "sampler_version": SAMPLER_VERSION, "family": "PBB",
            "sampling_family": base["sampling_family"],
            "construction_family": CONSTRUCTION_FAMILY, "length_stratum": base["length_stratum"],
            "ell": ell, "m": m, "n": 2 * ell * m,
            "A": base["A"], "B": base["B"], "C": [], "D": [],
            "requested_support_sizes": [terms_a, terms_b, terms_c, terms_d],
            "dedup_scope": DEDUP_SCOPE,
            "base_css_canonical_key": base["canonical_key"],
        }
        last = row
        attempt_record = {"base_attempt": attempt, "base_candidate_index": base_index,
                          "base_css_id": base["id"], "base_css_seed": base["candidate_seed"],
                          "base_css_k": base["k"], "ell": ell, "m": m,
                          "matching_pairs": None, "tested_pairs": 0}
        attempts.append(attempt_record)
        if base["k"] <= 0:
            attempt_record["outcome"] = "no_parent_logical_qubits"
            reasons["no_parent_logical_qubits"] += 1
            continue
        groups, cumulative = _match_groups(ell, m, base["A"], base["B"], terms_c, terms_d,
                                            require_cross_cancellation)
        match_count = cumulative[-1] if cumulative else 0
        attempt_record["matching_pairs"] = match_count
        if not match_count:
            attempt_record["outcome"] = "no_matching_sparse_supports_for_parent"
            reasons["no_matching_sparse_supports_for_parent"] += 1
            continue
        sampled_ranks = rng.sample(range(match_count), min(match_count, max_matches_per_base))
        for rank in sampled_ranks:
            matched = _solution_at_rank(groups, cumulative, rank)
            candidate = dict(row, C=matched["C"], D=matched["D"])
            # The matrix implementation is independent of the polynomial hash
            # signatures; a disagreement is a bug and must propagate, not hide
            # among ordinary structural rejections.
            prepared = prepare_code(candidate)
            candidate.update(prepared["structure"])
            attempt_record["tested_pairs"] += 1
            last = candidate
            if candidate["k"] > base["k"]:
                raise AssertionError("PBB k exceeds the CSS parent rank bound")
            if candidate["k"] <= 0:
                reasons["matched_code_no_logical_qubits"] += 1
                continue
            if not candidate["non_css"]:
                reasons["matched_code_css_rowspace"] += 1
                continue
            attempt_record["outcome"] = "accepted"
            candidate["canonical_key"] = canonical_key(candidate)
            candidate["group_id"] = candidate["canonical_key"]
            candidate["provenance"] = {
                "distribution": "explicit_sparse_match_sampler_not_author_dataset",
                "settings": settings, "seed_material": material, "seed_sha256": digest,
                "base_css_sampler": CSS_SAMPLER_VERSION,
                "base_css_id": base["id"], "base_css_seed": base["candidate_seed"],
                "base_css_canonical_key": base["canonical_key"], "base_css_k": base["k"],
                "construction": "AC^T+CA^T=BD^T+DB^T over GF(2)[Z_ell x Z_m]",
                "selected_match_rank": rank, "matching_pairs_for_selected_parent": match_count,
                "cross_signature_hex": matched["cross_signature_hex"],
                "cross_cancellation": matched["cross_cancellation"],
                "signature_match_exhaustive_for_selected_support_sizes": True,
                "full_stabilizer_independently_checked": True,
                "base_attempts_used": len(attempts), "base_attempts": attempts,
                "rejection_counts": dict(reasons),
                "selection": "uniform without replacement over matching pairs within each parent; first accepted structural match",
                "proposal_distance_searches": 0,
                "paper_examples_used_as_seeds": False,
            }
            return {"status": "ok", "reason": None, "candidate": candidate}
        attempt_record["outcome"] = "sampled_matches_failed_structural_checks"
    last["provenance"] = {
        "distribution": "explicit_sparse_match_sampler_not_author_dataset",
        "settings": settings, "seed_material": material, "seed_sha256": digest,
        "base_attempts_used": len(attempts), "base_attempts": attempts,
        "rejection_counts": dict(reasons), "proposal_distance_searches": 0,
        "absence_of_admissible_code_proved": False,
    }
    return {"status": "rejected", "reason": "bounded_sparse_search_exhausted", "candidate": last}
