#!/usr/bin/env python3
"""Standard-library algebra for Pauli bivariate bicycle (PBB) codes.

The convention is S = [A B | C D; 0 0 | B^T A^T].  Each binary
symplectic row is an int: X occupies the low n bits and Z the next n.
This module checks structures and supplied witnesses, not code distances.
"""
from __future__ import annotations

import hashlib
import json

from bb_code_algebra import gf2_rank, polynomial_matrix, popcount, row_basis, transpose


DEDUP_SCOPE = "common_cyclic_translation_ABCD_register_swap_coordinate_axis_swap_only"


def _integer(value, name, minimum=0):
    if type(value) is not int or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")
    return value


def support(value, ell, m, name="support"):
    """Validate an already reduced GF(2) support; duplicates are an error."""
    pairs = []
    for pair in value:
        if len(pair) != 2:
            raise ValueError(f"{name} monomials need exactly two exponents")
        a, b = _integer(pair[0], f"{name}.a"), _integer(pair[1], f"{name}.b")
        if a >= ell or b >= m:
            raise ValueError(f"{name} exponents are outside the cyclic grid")
        pairs.append((a, b))
    if not pairs or len(set(pairs)) != len(pairs):
        raise ValueError(f"{name} must be nonempty with no repeated monomials")
    return tuple(sorted(pairs))


def _spec(row):
    ell, m = _integer(row["ell"], "ell", 1), _integer(row["m"], "m", 1)
    supports = tuple(support(row[name], ell, m, name) for name in "ABCD")
    if min(len(supports[0]), len(supports[1])) < 2:
        raise ValueError("PBB A and B must each contain at least two monomials")
    return ell, m, supports


def multiply_support(left, right, ell, m):
    """Cyclic polynomial multiplication over GF(2), including cancellations."""
    ell, m = _integer(ell, "ell", 1), _integer(m, "m", 1)
    left, right = support(left, ell, m), support(right, ell, m)
    terms = set()
    for a, b in left:
        for c, d in right:
            term = ((a + c) % ell, (b + d) % m)
            if term in terms:
                terms.remove(term)
            else:
                terms.add(term)
    return tuple(sorted(terms))


def is_self_reciprocal(value, ell, m):
    terms = support(value, ell, m)
    return set(terms) == {((-a) % ell, (-b) % m) for a, b in terms}


def symplectic_product(left, right, n):
    mask = (1 << n) - 1
    return (popcount((left & mask) & (right >> n))
            + popcount((left >> n) & (right & mask))) % 2


def pauli_weight(vector, n):
    """Physical Pauli weight: Y=(X=1,Z=1) counts as one qubit."""
    _integer(n, "n", 1)
    _integer(vector, "vector")
    if vector >> (2 * n):
        raise ValueError("Pauli vector exceeds 2*n bits")
    return popcount((vector & ((1 << n) - 1)) | (vector >> n))


def _components(n, stabilizers):
    parent = list(range(n))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    mask = (1 << n) - 1
    for vector in stabilizers:
        remaining = (vector & mask) | (vector >> n)
        if not remaining:
            continue
        first = (remaining & -remaining).bit_length() - 1
        while remaining:
            bit = remaining & -remaining
            a, b = find(first), find(bit.bit_length() - 1)
            if a != b:
                parent[b] = a
            remaining ^= bit
    return len({find(i) for i in range(n)})


def prepare_code(row):
    """Build and independently audit all PBB stabilizer rows.

    Noncommuting inputs are errors.  k=0 and CSS rowspaces are returned with
    explicit metadata, so a sampler can record their rejection reasons.
    Rowspace non-CSS is stronger than observing a mixed X/Z generator.
    """
    ell, m, supports = _spec(row)
    size, n = ell * m, 2 * ell * m
    a, b, c, d = [polynomial_matrix(ell, m, terms) for terms in supports]
    at, bt = transpose(a, size), transpose(b, size)
    sx = [ai | (bi << size) for ai, bi in zip(a, b)] + [0] * size
    sz = ([ci | (di << size) for ci, di in zip(c, d)]
          + [bi | (ai << size) for bi, ai in zip(bt, at)])
    stabilizers = [x | (z << n) for x, z in zip(sx, sz)]
    for i, left in enumerate(stabilizers):
        for right in stabilizers[i + 1:]:
            if symplectic_product(left, right, n):
                raise ValueError("PBB stabilizer generators do not commute")
    basis = row_basis(stabilizers)
    rank, rx, rz = len(basis), gf2_rank(sx), gf2_rank(sz)
    pure_x, pure_z = rank - rz, rank - rx
    k = n - rank
    if "n" in row and row["n"] != n:
        raise ValueError("Stored n disagrees with the constructed PBB code")
    if "k" in row and row["k"] != k:
        raise ValueError("Stored k disagrees with the constructed PBB code")
    components = _components(n, stabilizers)
    structure = {
        "n": n, "k": k, "rank_stabilizers": rank,
        "rank_sx": rx, "rank_sz": rz,
        "pure_x_dimension": pure_x, "pure_z_dimension": pure_z,
        "non_css": pure_x + pure_z < rank,
        "commutation_checked": True,
        "pbb_tanner_components": components, "connected": components == 1,
        "support_sizes": [len(terms) for terms in supports],
        "maximum_generator_pauli_weight": max(pauli_weight(v, n) for v in stabilizers),
    }
    return {"n": n, "k": k, "stabilizers": stabilizers,
            "stabilizer_basis": basis, "structure": structure}


def validate_witness(vector, prepared):
    """Check a nontrivial normalizer element, independent of a search backend."""
    n = prepared["n"]
    if type(vector) is not int or vector <= 0 or vector >> (2 * n):
        return False
    stabilizers = prepared["stabilizers"]
    if any(symplectic_product(vector, row, n) for row in stabilizers):
        return False
    # Recompute the rank instead of trusting a backend's rowspace or k.
    return gf2_rank(stabilizers + [vector]) == gf2_rank(stabilizers) + 1


def canonical_spec(row):
    """Canonicalize only common translation, register swap, and axis swap.

    Common translation merely reindexes each generator block. Register and
    coordinate swaps are qubit permutations. Consequently these operations
    preserve physical Pauli weight and distance. Independent A/B shifts from
    the CSS sampler are intentionally NOT used for PBB.
    """
    ell, m, supports = _spec(row)
    variants = []
    for axis_swap in (False, True):
        dims = (m, ell) if axis_swap else (ell, m)
        terms = tuple(tuple((b, a) for a, b in group) for group in supports) if axis_swap else supports
        for register_swap in (False, True):
            groups = (terms[1], terms[0], terms[3], terms[2]) if register_swap else terms
            # A lexicographically minimal translated A contains the origin;
            # checking its own support as translation anchors is sufficient.
            for da, db in groups[0]:
                shifted = tuple(tuple(sorted(((a - da) % dims[0], (b - db) % dims[1])
                                             for a, b in group)) for group in groups)
                variants.append((*dims, *shifted))
    best = min(variants)
    return {"ell": best[0], "m": best[1],
            **{name: best[i + 2] for i, name in enumerate("ABCD")}}


def canonical_key(row):
    """Equal keys certify only the documented symmetry equivalences."""
    serial = json.dumps(canonical_spec(row), sort_keys=True, separators=(",", ":"))
    return "pbb-" + hashlib.sha256(serial.encode("utf-8")).hexdigest()
