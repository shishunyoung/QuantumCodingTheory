#!/usr/bin/env python3
"""Fresh process per complete PBB method, preserving all trial budgets.

Python API: run_isolated(candidate, method, trials=10000, seed=0).
CLI: --request request.json --response response.json, where request contains
candidate, method, trials and seed. Temporary files follow the job's TMPDIR.
An interrupted/failed child raises; its partial budget is never a result.
"""
from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import platform
import signal
import subprocess
import sys
import tempfile
import time
import traceback
from datetime import datetime, timezone

THREAD_VARIABLES = ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
                    "NUMBA_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "BLIS_NUM_THREADS")
POLICY = "pbb_fresh_python_child_per_complete_method_v1"
AUDIT_ENV = "PBB_DISTANCE_ISOLATION_AUDIT_PATH"


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def overlay_manifest():
    return {
        "execution_policy": POLICY,
        "launcher_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "python_executable": sys.executable,
        "python_version": platform.python_version(),
        "trial_budgets_and_seeds": "passed unchanged to one full PBB run_method call",
        "memory_scope": "OS reclaims child memory between complete calls",
        "single_call_memory_limit": "scheduler job limit; no per-call memory cap",
        "import_and_jit_scope": "repeated in each child",
        "slurm_job_id": os.environ.get("SLURM_JOB_ID"),
    }


def _audit(event):
    path = os.environ.get(AUDIT_ENV)
    if not path:
        return
    record = json.dumps({"recorded_utc": utc_now(), **event}, sort_keys=True,
                        ensure_ascii=False, allow_nan=False)
    with open(path, "a", encoding="utf-8") as stream:
        fcntl.flock(stream.fileno(), fcntl.LOCK_EX)
        stream.write(record + "\n")
        stream.flush()
        os.fsync(stream.fileno())
        fcntl.flock(stream.fileno(), fcntl.LOCK_UN)


def init_outer_worker():
    for variable in THREAD_VARIABLES:
        os.environ[variable] = "1"


def _write_json(path, value):
    target = Path(path)
    temporary = target.with_name(target.name + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, allow_nan=False),
                         encoding="utf-8")
    temporary.replace(target)


def child_main(request_path, response_path):
    request = json.loads(Path(request_path).read_text(encoding="utf-8"))
    init_outer_worker()
    import pbb_distance_backend as backend
    result = backend.run_method(request["candidate"], request["method"],
                                request["trials"], request["seed"])
    _write_json(response_path, {"result": result, "child_pid": os.getpid(),
                              "launcher_sha256": overlay_manifest()["launcher_sha256"]})
    return 0


def _tail(path, limit=16000):
    with open(path, "rb") as stream:
        stream.seek(0, os.SEEK_END)
        stream.seek(max(0, stream.tell() - limit))
        return stream.read().decode("utf-8", errors="replace")


def _isolated_call(candidate, method, trials, seed, *, timeout_seconds=None,
                   child_command=None):
    """child_command is an internal stdlib-test seam, not a production CLI option."""
    if timeout_seconds is not None and timeout_seconds <= 0:
        raise ValueError("timeout_seconds must be positive or None")
    started = time.perf_counter()
    profile = {**overlay_manifest(), "outer_worker_pid": os.getpid(),
               "started_utc": utc_now(), "timeout_seconds": timeout_seconds}
    identity = {"id": candidate.get("id"), "method": method,
                "requested_trials": trials, "seed_argument": seed}
    _audit({"event": "child_call_started", **identity, "execution_overlay": profile})
    try:
        with tempfile.TemporaryDirectory(prefix="pbb-distance-method-") as temporary:
            directory = Path(temporary)
            request_path, response_path = directory / "request.json", directory / "response.json"
            _write_json(request_path, {"candidate": candidate, "method": method,
                                     "trials": trials, "seed": seed})
            command = (list(child_command) if child_command is not None else
                       [sys.executable, str(Path(__file__).resolve()), "--isolated-child"])
            environment = os.environ.copy()
            for variable in THREAD_VARIABLES:
                environment[variable] = "1"
            log_path = directory / "child.log"
            with log_path.open("wb") as log:
                process = subprocess.Popen(command + [str(request_path), str(response_path)],
                                           stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                                           env=environment, start_new_session=True)
                try:
                    returncode = process.wait(timeout=timeout_seconds)
                except BaseException:
                    # Reap the whole isolated process group on timeout/interruption.
                    try:
                        os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    process.wait()
                    raise
            profile["child_returncode"] = returncode
            if returncode != 0:
                raise RuntimeError(f"Child exited with code {returncode}; log tail: {_tail(log_path)}")
            if not response_path.is_file():
                raise RuntimeError(f"Child produced no response; log tail: {_tail(log_path)}")
            envelope = json.loads(response_path.read_text(encoding="utf-8"))
            if envelope.get("launcher_sha256") != profile["launcher_sha256"]:
                raise RuntimeError("Child/parent launcher hashes differ")
            result = envelope["result"]
            if not isinstance(result, dict) or any(result.get(key) != value
                                                   for key, value in identity.items()):
                raise RuntimeError("Child result identity, trial request, or seed differs")
            child_pid = envelope.get("child_pid")
            if (type(child_pid) is not int or child_pid <= 0 or child_pid == os.getpid()
                    or result.get("pid") != child_pid):
                raise RuntimeError("Backend PID is not a separate child process identity")
            profile.update(child_pid=child_pid, finished_utc=utc_now(),
                           child_lifetime_wall_seconds=time.perf_counter() - started)
            result["execution_overlay"] = profile
            _audit({"event": "child_call_finished", **identity,
                    "status": result.get("status"), "execution_overlay": profile})
            return result
    except Exception as error:
        profile.update(finished_utc=utc_now(),
                       child_lifetime_wall_seconds=time.perf_counter() - started)
        _audit({"event": "child_call_failed_uncommitted", **identity,
                "error": f"{type(error).__name__}: {error}", "execution_overlay": profile})
        raise RuntimeError(f"Isolated {method} for {candidate.get('id')} failed; "
                           "no completed budget may be committed") from error


def run_isolated(candidate, method, trials=10000, seed=0, timeout_seconds=None):
    return _isolated_call(candidate, method, trials, seed, timeout_seconds=timeout_seconds)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--request", type=Path, required=True)
    parser.add_argument("--response", type=Path, required=True)
    parser.add_argument("--timeout-seconds", type=float)
    args = parser.parse_args(argv)
    request = json.loads(args.request.read_text())
    result = run_isolated(request["candidate"], request["method"], request.get("trials", 10000),
                          request.get("seed", 0), args.timeout_seconds)
    _write_json(args.response, result)
    return 0


if __name__ == "__main__":
    try:
        if len(sys.argv) == 4 and sys.argv[1] == "--isolated-child":
            raise SystemExit(child_main(sys.argv[2], sys.argv[3]))
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(130)
    except Exception:
        traceback.print_exc()
        raise SystemExit(1)
