#!/usr/bin/env python3
"""Accumulate *validated labels*, not merely candidates, in frozen child batches.

BB selects odd U in 3..25 from A4B4; PBB selects U in 2..25 from sparse
joint-commutation candidates. All candidate labels and raw method evidence stay
in child directories, including surplus/out-of-range/even results. This wrapper
does not replace any heuristic or modify the old frozen generators.

Optional BB quotas reserve separate counts for odd U in 3..7, 9..13, 15..19,
and 21..25. Only the tightest known witnessed U of each own full-Aut orbit is
eligible; a newly found smaller witnessed U can move or remove an earlier selection.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import signal
import shutil
import subprocess
import sys
import time

import generate_bb_odd_bound_campaign as bb
import generate_pbb_sparse_campaign as pbb
from training_paper import build_orbit_map as orbit

HERE = Path(__file__).resolve().parent
SCHEMA = 'bb_pbb_label_extension_target_v1'
TRIALS = 10000
METHODS = tuple(pbb.METHODS)
BB_ODD_BINS = (('3_7', 3, 7), ('9_13', 9, 13), ('15_19', 15, 19), ('21_25', 21, 25))
SOURCE_FILES = tuple(sorted(set((*bb.SOURCE_FILES, *pbb.SOURCE_FILES, Path(__file__).name,
                                'training_paper/build_orbit_map.py', 'training_paper/orbit_identity.cpp'))))
STOP = {'requested': False, 'signal': None, 'count': 0}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_json(path):
    return pbb.base.read_json(Path(path).read_text())


def rows(path):
    with Path(path).open() as stream:
        return [pbb.base.read_json(line) for line in stream if line.strip()]


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def encode(value):
    return pbb.base.json_text(value)


def write_json(path, value):
    pbb.base.write_json(path, value)


def write_rows(path, records):
    pbb.common.write_jsonl_stream(path, records)


def construction(row, family):
    if family == 'bb':
        key = bb.base.structural_key(row)
        family_name = 'CSS'
    else:
        require(row.get('family') == 'PBB', 'PBB exclusions require PBB constructions')
        prepared = pbb.base.prepare_code(row)
        require(prepared['k'] > 0 and prepared['structure']['non_css'], 'PBB exclusion is not a positive-k non-CSS code')
        key = pbb.sampler.canonical_key(row)
        family_name = 'PBB'
    require(row.get('canonical_key', key) == key, 'Construction identity mismatch')
    return {name: row.get(name, []) for name in ('ell', 'm', 'A', 'B', 'C', 'D')} | {
        'family': family_name, 'canonical_key': key}


def source_hashes():
    return {name: sha(HERE / name) for name in SOURCE_FILES}


def orbit_input_rows(path, kind, family):
    prefix = 'pbbaut-v2-' if kind == 'prior' and family == 'pbb' else 'bbaut-v2-'
    result = set()
    for row in rows(path):
        value = row.get('orbit_id')
        require(isinstance(value, str) and value.startswith(prefix) and len(value) == len(prefix) + 64
                and all(char in '0123456789abcdef' for char in value[len(prefix):]),
                'Invalid/full-Aut-version incompatible exclusion identity')
        result.add(value)
    return result


def freeze_config(args):
    output = args.output_dir
    manifest_path = output / 'configuration.json'
    sources = []
    for i, path in enumerate(args.exclude):
        path = path.expanduser().resolve()
        require(path.is_file(), 'Missing exclusion source: ' + str(path))
        sources.append({'source': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size,
                        'snapshot': f'inputs/exclusion-{i:03d}.jsonl'})
    require(len({s['source'] for s in sources}) == len(sources), 'Duplicate exclusion paths')
    require(sources, 'Supply --exclude with prior candidates / reserved codes')
    orbit_sources = []
    for kind, paths in [('prior', args.prior_orbits), ('reserved_parent', args.reserved_parent_orbits)]:
        require(paths, 'Supply full-Aut exclusion files for ' + kind)
        for i, path in enumerate(paths):
            path = path.expanduser().resolve()
            require(path.is_file(), 'Missing full-Aut exclusion source: ' + str(path))
            orbit_input_rows(path, kind, args.family)
            orbit_sources.append({'kind': kind, 'source': str(path), 'sha256': sha(path),
                                  'bytes': path.stat().st_size, 'snapshot': f'inputs/{kind}-orbits-{i:03d}.jsonl'})
    config = {
        'schema': SCHEMA, 'family': args.family, 'target_labels': args.target,
        'batch_candidates': args.batch_candidates, 'seed': args.seed,
        'seed_rule': 'root seed + zero-based batch index * 1009',
        'trials_per_method': TRIALS, 'methods': list(METHODS),
        'source_sha256': source_hashes(),
        'backend': (bb.base.backend if args.family == 'bb' else pbb.base.backend).backend_manifest(),
        'exclusion_sources': sources,
        'orbit_sources': orbit_sources, 'orbit_identity_version': orbit.VERSION,
        'selection': 'odd witnessed U3..25' if args.family == 'bb' else 'witnessed U2..25',
        'ordering': 'Own full-Aut orbits in first-appearance order; minimum known witnessed U per orbit, earliest real record on ties; then select first target eligible orbits',
        'dedup_scope': orbit.SCOPE,
        'dedup_limit': 'Declared full-Aut orbit only, not arbitrary code isomorphism. Group all parent/descendant associations before final training.',
        'parent_policy': 'Reject reserved CSS-parent orbits; parent distances are never copied to descendants.',
        'sampling_scope': 'Our explicit structure-coverage sampler, not unpublished author sampling frequencies',
        'is_exact': False,
    }
    if args.bb_odd_quotas is not None:
        config['bb_odd_quotas'] = list(args.bb_odd_quotas)
        config['bb_odd_bins'] = [{'name': name, 'lower': low, 'upper': high} for name, low, high in BB_ODD_BINS]
        config['ordering'] += '; independent strict per-bin quotas, no borrowing between bins'
        bb_odd_quota_map(config)
    if manifest_path.exists():
        require(read_json(manifest_path) == config, 'Frozen configuration/source/input changed; use a new directory')
        for entry in sources + orbit_sources:
            require(sha(output / entry['snapshot']) == entry['sha256'], 'Frozen exclusion snapshot changed')
    else:
        require(not (output / 'batches').exists(), 'Existing batches lack wrapper configuration')
        (output / 'inputs').mkdir(exist_ok=True)
        for entry in sources + orbit_sources:
            data = Path(entry['source']).read_bytes()
            require(hashlib.sha256(data).hexdigest() == entry['sha256'], 'Exclusion source changed during copy')
            pbb.base.atomic_bytes(output / entry['snapshot'], data)
        write_json(manifest_path, config)
    keys = set()
    for entry in sources:
        records = rows(output / entry['snapshot'])
        require(records, 'Empty exclusion input')
        keys.update(construction(row, args.family)['canonical_key'] for row in records)
    return config, keys


class OrbitIndex:
    """Recompute each audited batch's exact identities; do not trust cached IDs."""
    def __init__(self, output, config, cxx=None):
        self.output, self.config = output, config
        self.prior, self.reserved = set(), set()
        for entry in config['orbit_sources']:
            values = orbit_input_rows(output / entry['snapshot'], entry['kind'], config['family'])
            (self.prior if entry['kind'] == 'prior' else self.reserved).update(values)
        compiler = cxx or os.environ.get('CXX') or shutil.which('g++') or shutil.which('clang++')
        require(compiler is not None, 'C++17 compiler required; set CXX or --cxx')
        directory = output / '.orbit_helper'
        directory.mkdir(exist_ok=True)
        self.binary, command = orbit.compile_helper(directory, compiler)
        reference = orbit.validate_reference(self.binary)
        write_json(directory / 'build.json', {'compiler_command': command, 'binary_sha256': sha(self.binary),
                   'identity_version': orbit.VERSION, 'reference_validation': reference})

    def batch(self, candidates, batch):
        specs, links = [], []
        for candidate in candidates:
            own = construction(candidate, self.config['family'])
            orbit.validate_row(own)
            mother = dict(own, family='CSS', C=[], D=[])
            mother['canonical_key'] = bb.base.structural_key(mother)
            orbit.validate_row(mother)
            links.append((len(specs), len(specs) + 1))
            specs.extend([own, mother])
        keys = orbit.calculate_keys(self.binary, specs)
        identities = [{'id': row['id'], 'canonical_key': row['canonical_key'],
                       'orbit_id': orbit.orbit_id(keys[own]),
                       'parent_css_orbit_id': orbit.orbit_id(keys[mother])}
                      for row, (own, mother) in zip(candidates, links)]
        write_rows(batch / 'full_aut_identities.jsonl', identities)
        return identities


def batch_request(config, output, index, prior_batches):
    require(index == len(prior_batches), 'Batch history must be contiguous')
    exclusions = [output / entry['snapshot'] for entry in config['exclusion_sources']]
    exclusions.extend(output / 'batches' / f'batch-{i:04d}' / 'candidates.jsonl'
                      for i in range(index))
    return {'schema': SCHEMA, 'family': config['family'], 'batch_index': index,
            'seed': config['seed'] + index * 1009,
            'candidate_target': config['batch_candidates'],
            'trials_per_method': TRIALS,
            'exclusions': [{'path': str(path.resolve()), 'sha256': sha(path)} for path in exclusions],
            'wrapper_configuration_sha256': hashlib.sha256(encode(config).encode()).hexdigest()}


def command_for(args, request, batch):
    script = 'generate_bb_odd_bound_campaign.py' if args.family == 'bb' else 'generate_pbb_sparse_campaign.py'
    command = [sys.executable, '-B', '-u', str(HERE / script), '--output-dir', str(batch),
               '--seed', str(request['seed']), '--trials', str(TRIALS),
               '--workers', str(args.workers), '--prepare-workers', str(args.prepare_workers)]
    if args.family == 'bb':
        command += ['--mode', 'pilot', '--pilot-count', str(request['candidate_target']),
                    '--structure-weights', '1', '0', '0', '0', '0']
        exclusion_flag = '--exclude'
    else:
        command += ['--target', str(request['candidate_target'])]
        exclusion_flag = '--skip-codes'
    for entry in request['exclusions']:
        command += [exclusion_flag, entry['path']]
    if args.prepare_only:
        command.append('--prepare-only')
    return command


def eligible(row, family):
    value = row.get('d_upper')
    require(type(value) is int and value > 0, 'Invalid upper bound')
    return 3 <= value <= 25 and value % 2 == 1 if family == 'bb' else 2 <= value <= 25


def bb_odd_bin(value):
    """Return the fixed odd-label bin; even or out-of-range bounds have none."""
    if type(value) is not int or value % 2 == 0:
        return None
    return next((name for name, low, high in BB_ODD_BINS if low <= value <= high), None)


def bb_odd_quota_map(config):
    quotas = config.get('bb_odd_quotas')
    if quotas is None:
        return None
    require(config['family'] == 'bb', 'BB odd quotas apply only to --family bb')
    require(isinstance(quotas, (list, tuple)) and len(quotas) == len(BB_ODD_BINS)
            and all(type(value) is int and value >= 0 for value in quotas),
            'BB odd quotas need four nonnegative integers')
    require(sum(quotas) == config['target_labels'], 'BB odd quotas must sum to target labels')
    return dict(zip((name for name, _, _ in BB_ODD_BINS), quotas))


def validate_batch(batch, request, config, excluded):
    """Recheck receipt, configuration, all raw method witnesses and label min."""
    receipt = read_json(batch / 'completion_verified.json')
    expected_state = 'pilot_complete_verified' if config['family'] == 'bb' else 'complete_verified'
    require(receipt.get('state') == expected_state and receipt.get('all_witnesses_verified') is True
            and receipt.get('is_exact') is False, 'Child batch has no complete witnessed receipt')
    count = request['candidate_target']
    require(receipt.get('trials_per_method') == TRIALS and receipt.get('actual_trials') == count * 3 * TRIALS,
            'Child receipt budget/count differs')
    hashes = receipt.get('output_sha256', {})
    require({'candidates.jsonl', 'methods.jsonl', 'labels.jsonl'} <= set(hashes), 'Receipt omits evidence files')
    for name, digest in hashes.items():
        require(Path(name).name == name and sha(batch / name) == digest, 'Receipt output hash differs: ' + name)
    leaf = read_json(batch / 'configuration.json')
    require(receipt.get('configuration_sha256') == hashlib.sha256(encode(leaf).encode()).hexdigest(),
            'Child configuration hash differs')
    require(leaf['seed'] == request['seed'] and leaf['sampler_version'] == (
        bb.SAMPLER_VERSION if config['family'] == 'bb' else pbb.sampler.SAMPLER_VERSION), 'Child seed/sampler differs')
    if config['family'] == 'bb':
        require(leaf['mode'] == 'pilot' and leaf['pilot_count'] == count and leaf['trials'] == TRIALS
                and leaf['sampling']['structure_weights'] == [1, 0, 0, 0, 0], 'Wrong BB batch sampling/budget')
        source_field, backend_field, deps = 'source_hashes', 'source', bb.SOURCE_FILES
    else:
        require(leaf['target_codes'] == count and leaf['trials_per_method'] == TRIALS
                and leaf['sampling']['terms_a'] == leaf['sampling']['terms_b'] == 3
                and leaf['sampling']['require_cross_cancellation'] is True
                and leaf['sampling']['perturbation_patterns'] == [[2, 2], [1, 2], [2, 1]],
                'Wrong PBB batch sampling/budget')
        source_field, backend_field, deps = 'source_sha256', 'backend', pbb.SOURCE_FILES
    require(leaf[source_field] == {name: config['source_sha256'][name] for name in deps}
            and leaf[backend_field] == config['backend'], 'Child source/backend differs')
    sampling = leaf['sampling']
    require(all(sampling[key] == value for key, value in
                [('ell_min', 3), ('ell_max', 30), ('m_min', 3), ('m_max', 30), ('n_min', 18), ('n_max', 360)]),
            'Child corpus differs from paper-range configuration')
    candidates, labels, raw_methods = (rows(batch / name) for name in
                                      ('candidates.jsonl', 'labels.jsonl', 'methods.jsonl'))
    require(len(candidates) == len(labels) == count and len(raw_methods) == count * 3, 'Child evidence counts differ')
    by_id = {row['id']: row for row in candidates}
    require(len(by_id) == count and len({r['canonical_key'] for r in candidates}) == count, 'Duplicate child candidates')
    require([row['id'] for row in labels] == [row['id'] for row in candidates], 'Label order differs from candidates')
    methods = {}
    for result in raw_methods:
        key = (result.get('id'), result.get('method'))
        require(key not in methods and key[0] in by_id and key[1] in METHODS, 'Duplicate/unknown child method')
        methods[key] = result
    for candidate, label in zip(candidates, labels):
        key = construction(candidate, config['family'])['canonical_key']
        require(key not in excluded, 'Child candidate overlaps prior population')
        if config['family'] == 'bb':
            bb.validate_candidate(candidate, leaf, replay=False)
            require(len(candidate['A']) == len(candidate['B']) == 4, 'BB target requires A4B4 candidates')
            expected = bb.base.label_for(candidate, [methods[(candidate['id'], method)] for method in METHODS], leaf)
            require({k: v for k, v in label.items() if k != 'quota_outcome'} == expected, 'BB label differs from audited minimum')
        else:
            pbb.validate_candidate(candidate, leaf)
            checked = {}
            for method in METHODS:
                result = methods[(candidate['id'], method)]
                require(result.get('seed_argument') == pbb.base.result_seed(leaf['seed'], candidate['id'], method),
                        'PBB result seed differs')
                checked[method] = pbb.base.backend.validate_method_result(candidate, method, result, TRIALS)
                require(checked[method]['validated'], 'PBB raw witness/parameters/budget failed independent check')
            require(label == pbb.base.make_label(candidate, checked, TRIALS), 'PBB label differs from audited minimum')
    return candidates, labels, {'batch_index': request['batch_index'], 'codes': count,
                               'receipt_sha256': sha(batch / 'completion_verified.json'),
                               'candidate_sha256': sha(batch / 'candidates.jsonl'),
                               'label_sha256': sha(batch / 'labels.jsonl')}


def select_labels(config, all_labels, identities, prior, reserved):
    require(len(all_labels) == len(identities), 'Full-Aut identities do not cover every label')
    qualifying, decisions, best = [], [], {}
    quotas, selected_by_bin = bb_odd_quota_map(config), Counter()
    for i, (row, identity) in enumerate(zip(all_labels, identities)):
        require(row['id'] == identity['id'] and row['canonical_key'] == identity['canonical_key'],
                'Full-Aut identities are out of label order')
        eligible(row, config['family'])  # Validate even the rejected records' bound type.
        own = identity['orbit_id']
        if own not in best or row['d_upper'] < all_labels[best[own]]['d_upper']:
            best[own] = i
    outcomes = {}
    for own, i in best.items():
        row, identity = all_labels[i], identities[i]
        if own not in prior and identity['parent_css_orbit_id'] not in reserved and eligible(row, config['family']):
            if quotas is None:
                outcomes[i] = 'selected' if len(qualifying) < config['target_labels'] else 'surplus_qualifying'
            else:
                bucket = bb_odd_bin(row['d_upper'])
                require(bucket in quotas, 'Eligible BB upper bound lacks a quota bin')
                outcomes[i] = 'selected' if selected_by_bin[bucket] < quotas[bucket] else 'quota_full'
                if outcomes[i] == 'selected':
                    selected_by_bin[bucket] += 1
            qualifying.append(dict(row, **{key: identity[key] for key in ('orbit_id', 'parent_css_orbit_id')}))
    for i, (row, identity) in enumerate(zip(all_labels, identities)):
        own, parent = identity['orbit_id'], identity['parent_css_orbit_id']
        if own in prior:
            reason = 'prior_full_aut_orbit'
        elif parent in reserved:
            reason = 'reserved_parent_css_orbit'
        elif i != best[own]:
            reason = ('superseded_full_aut_bound' if row['d_upper'] > all_labels[best[own]]['d_upper']
                      else 'duplicate_new_full_aut_orbit')
        else:
            reason = outcomes.get(i, 'outside_label_selection')
        decision = dict(identity, d_upper=row['d_upper'], selection_outcome=reason)
        if quotas is not None:
            decision['bb_odd_bin'] = bb_odd_bin(row['d_upper'])
        decisions.append(decision)
    return qualifying, decisions


def export_aggregate(output, config, batches, all_labels, state, active=None,
                     *, identities=(), prior=frozenset(), reserved=frozenset()):
    qualifying, decisions = select_labels(config, all_labels, identities, prior, reserved)
    # Per-bin selection is not a prefix of all qualifying labels: an early
    # surplus low-U orbit must not displace a later under-filled high-U orbit.
    selected_keys = {(row['id'], row['canonical_key']) for row in decisions
                     if row['selection_outcome'] == 'selected'}
    selected = [row for row in qualifying if (row['id'], row['canonical_key']) in selected_keys]
    surplus = [row for row in qualifying if (row['id'], row['canonical_key']) not in selected_keys]
    quotas = bb_odd_quota_map(config)
    write_rows(output / 'all_labels.jsonl', all_labels)
    write_rows(output / 'selected_labels.jsonl', selected)
    write_rows(output / 'surplus_qualifying_labels.jsonl', surplus)
    write_rows(output / 'outside_selection_labels.jsonl', (row for row in all_labels if not eligible(row, config['family'])))
    write_rows(output / 'bb_even_labels.jsonl', (row for row in all_labels if config['family'] == 'bb' and row['d_upper'] % 2 == 0))
    write_rows(output / 'selection_audit.jsonl', decisions)
    write_rows(output / 'full_aut_rejected_labels.jsonl', (dict(row, selection_audit=decision)
        for row, decision in zip(all_labels, decisions) if decision['selection_outcome'] in
        ('prior_full_aut_orbit', 'reserved_parent_css_orbit', 'duplicate_new_full_aut_orbit', 'superseded_full_aut_bound')))
    summary = {'schema': SCHEMA, 'updated_utc': pbb.base.utc_now(), 'state': state, 'family': config['family'],
               'target_labels': config['target_labels'], 'selected_labels': len(selected),
               'remaining_labels': max(0, config['target_labels'] - len(selected)),
               'qualifying_labels': len(qualifying), 'surplus_qualifying_labels': max(0, len(qualifying) - len(selected)),
               'completed_batches': len(batches), 'searched_codes_in_completed_batches': len(all_labels),
               'completed_batch_method_results': len(all_labels) * 3,
               'actual_trials_in_completed_batches': len(all_labels) * 3 * TRIALS,
               'selected_upper_histogram': dict(sorted(Counter(row['d_upper'] for row in selected).items())),
               'all_upper_histogram': dict(sorted(Counter(row['d_upper'] for row in all_labels).items())),
               'even_labels_retained': sum(row['d_upper'] % 2 == 0 for row in all_labels) if config['family'] == 'bb' else None,
               'selection_outcomes': dict(Counter(row['selection_outcome'] for row in decisions)),
               'active_batch': active, 'dedup_scope': config['dedup_scope'], 'is_exact': False,
               'progress_note': 'Top-level selected count includes audited complete batches only; active child journals retain partial results.'}
    if config['family'] == 'bb':
        available_by_bin = Counter(bb_odd_bin(row['d_upper']) for row in qualifying)
        selected_by_bin = Counter(bb_odd_bin(row['d_upper']) for row in selected)
        summary['bb_odd_bins'] = {
            name: {'range': [low, high], 'target': None if quotas is None else quotas[name],
                   'selected': selected_by_bin[name],
                   'remaining': None if quotas is None else max(0, quotas[name] - selected_by_bin[name]),
                   'available': available_by_bin[name],
                   'surplus': available_by_bin[name] - selected_by_bin[name]}
            for name, low, high in BB_ODD_BINS}
    if quotas is not None:
        summary['bb_odd_quotas'] = config['bb_odd_quotas']
        summary['bb_odd_quotas_complete'] = all(
            summary['bb_odd_bins'][name]['selected'] == quota for name, quota in quotas.items())
    summary['target_complete'] = (len(selected) == config['target_labels']
                                  and summary.get('bb_odd_quotas_complete', True))
    write_json(output / 'summary.json', summary)
    write_json(output / 'completed_batches.json', batches)
    return summary


def stop_signal(signum, _frame):
    STOP.update(requested=True, signal=signum, count=STOP['count'] + 1)


def run_child(command, batch, family, progress_callback):
    """Drain the complete batch on signals; isolated solver children finish too."""
    with (batch / 'driver.log').open('ab') as stream:
        child = subprocess.Popen(command, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
        last_progress = float('-inf')
        try:
            while child.poll() is None:
                if time.monotonic() - last_progress >= 30:
                    progress_callback()
                    last_progress = time.monotonic()
                time.sleep(1)
        except BaseException:
            print('Wrapper export failed; waiting for the current child batch to finish before exiting.',
                  file=sys.stderr, flush=True)
            raise
        finally:
            # Old PBB workers create isolated solver children. Keep the wrapper
            # lock until its coordinator has joined them, even if a disk write fails.
            child.wait()
        return child.returncode


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--family', choices=['bb', 'pbb'], required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--exclude', '--inputs', type=Path, action='append', default=[])
    parser.add_argument('--prior-orbits', type=Path, action='append', required=True)
    parser.add_argument('--reserved-parent-orbits', type=Path, action='append', required=True)
    parser.add_argument('--cxx', help='C++17 compiler; defaults to CXX, g++, then clang++')
    parser.add_argument('--target', type=int, default=2000)
    parser.add_argument('--bb-odd-quotas', type=int, nargs=4, metavar=('U3_7', 'U9_13', 'U15_19', 'U21_25'),
                        help='Optional BB-only strict bin counts; nonnegative, sum must equal --target')
    parser.add_argument('--batch-candidates', type=int, default=200)
    parser.add_argument('--seed', type=int)
    parser.add_argument('--workers', type=int, default=1)
    parser.add_argument('--prepare-workers', type=int)
    parser.add_argument('--max-batches', type=int, default=1000)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--prepare-only', action='store_true')
    mode.add_argument('--export-only', action='store_true')
    args = parser.parse_args(argv)
    args.prepare_workers = args.workers if args.prepare_workers is None else args.prepare_workers
    args.seed = args.seed if args.seed is not None else (2026110503 if args.family == 'bb' else 2026110504)
    if min(args.target, args.batch_candidates, args.workers, args.prepare_workers, args.max_batches) < 1 or args.seed < 0:
        parser.error('Positive counts and nonnegative seed are required')
    try:
        bb_odd_quota_map({'family': args.family, 'target_labels': args.target, 'bb_odd_quotas': args.bb_odd_quotas})
    except ValueError as error:
        parser.error(str(error))
    if not args.exclude:
        parser.error('Supply --exclude with prior/reserved constructions')
    allocated = os.environ.get('SLURM_CPUS_PER_TASK')
    if allocated and max(args.workers, args.prepare_workers) > int(allocated):
        parser.error('Workers exceed Slurm allocation')
    args.output_dir = args.output_dir.expanduser().resolve()
    return args


def main(argv=None, runner=None):
    args = parse_args(argv)
    STOP.update(requested=False, signal=None, count=0)
    output = args.output_dir
    handlers = {sig: signal.getsignal(sig) for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGUSR1)}
    for sig in handlers:
        signal.signal(sig, stop_signal)
    try:
        with pbb.base.run_lock(output):
            config, excluded = freeze_config(args)
            orbit_index = OrbitIndex(output, config, args.cxx)
            (output / 'batches').mkdir(exist_ok=True)
            batches, all_labels, identities = [], [], []
            def export(state, active=None):
                return export_aggregate(output, config, batches, all_labels, state, active,
                    identities=identities, prior=orbit_index.prior, reserved=orbit_index.reserved)
            expected_dirs = []
            for index in range(args.max_batches):
                require(source_hashes() == config['source_sha256'], 'Source changed while task was running')
                batch = output / 'batches' / f'batch-{index:04d}'
                expected_dirs.append(batch.name)
                request = batch_request(config, output, index, batches)
                if batch.exists():
                    require((batch / 'request.json').is_file() and read_json(batch / 'request.json') == request,
                            'Existing child batch request changed or is incomplete')
                else:
                    if args.export_only:
                        export('exported_incomplete')
                        return 75
                    batch.mkdir()
                    write_json(batch / 'request.json', request)
                require(all(sha(Path(entry['path'])) == entry['sha256'] for entry in request['exclusions']),
                        'Child exclusion input changed')
                receipt = batch / 'completion_verified.json'
                if not receipt.exists():
                    active = {'batch_index': index, 'directory': str(batch), 'candidate_target': request['candidate_target']}
                    def progress():
                        current = dict(active)
                        if (batch / 'summary.json').exists():
                            try:
                                child = read_json(batch / 'summary.json')
                                current['child_summary'] = {key: child.get(key) for key in
                                    ('state', 'selected', 'completed', 'completed_codes', 'saved_method_results',
                                     'recorded_actual_trials', 'paper_range_completed_codes')}
                            except (OSError, ValueError):
                                current['child_summary_unavailable'] = True
                        export('stopping_after_batch' if STOP['requested'] else 'running_batch', current)
                    progress()
                    if args.export_only or STOP['requested']:
                        export('stopped_partial', active)
                        return 75
                    command = command_for(args, request, batch)
                    status = (runner or run_child)(command, batch, args.family, progress)
                    if args.prepare_only:
                        export('prepared_first_incomplete_batch' if status == 0 else 'prepare_failed', active)
                        return status
                    if status or not receipt.exists():
                        export('stopped_partial' if STOP['requested'] else 'child_failed_partial', active)
                        return 75 if STOP['requested'] or status in (2, 75, 130, -signal.SIGINT) else 1
                candidates, labels, evidence = validate_batch(batch, request, config, excluded)
                batch_identities = orbit_index.batch(candidates, batch)
                evidence['full_aut_identities_sha256'] = sha(batch / 'full_aut_identities.jsonl')
                for row in candidates:
                    require(row['canonical_key'] not in excluded, 'Duplicate candidate across batches')
                    excluded.add(row['canonical_key'])
                batches.append(evidence)
                all_labels.extend(labels)
                identities.extend(batch_identities)
                summary = export('running')
                print(encode(summary), flush=True)
                if summary['target_complete']:
                    require(not any(p.name not in expected_dirs for p in (output / 'batches').iterdir() if p.is_dir()),
                            'Unexpected additional child batches after target')
                    summary = export('complete_verified')
                    names = ['selected_labels.jsonl', 'all_labels.jsonl', 'surplus_qualifying_labels.jsonl',
                             'outside_selection_labels.jsonl', 'bb_even_labels.jsonl', 'summary.json', 'completed_batches.json',
                             'selection_audit.jsonl', 'full_aut_rejected_labels.jsonl']
                    write_json(output / 'completion_verified.json', {
                        'schema': SCHEMA, 'state': 'complete_verified', 'family': args.family,
                        'target_labels': config['target_labels'], 'selected_labels': summary['selected_labels'],
                        'searched_codes': len(all_labels), 'trials_per_method': TRIALS,
                        'actual_trials': len(all_labels) * 3 * TRIALS,
                        'all_batch_witnesses_independently_rechecked': True,
                        'full_aut_new_unique_selected_labels': summary['selected_labels'],
                        'reserved_parent_overlap': 0,
                        'bb_odd_quotas': config.get('bb_odd_quotas'),
                        'bb_odd_bins': summary.get('bb_odd_bins'),
                        'bb_odd_quotas_complete': summary.get('bb_odd_quotas_complete'),
                        'configuration_sha256': sha(output / 'configuration.json'),
                        'output_sha256': {name: sha(output / name) for name in names}, 'is_exact': False})
                    return 0
                if STOP['requested']:
                    export('stopped_after_batch')
                    return 75
            export('max_batches_reached')
            return 75
    finally:
        for sig, handler in handlers.items():
            signal.signal(sig, handler)


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f'Label target task failed: {type(error).__name__}: {error}', file=sys.stderr, flush=True)
        raise SystemExit(1)
