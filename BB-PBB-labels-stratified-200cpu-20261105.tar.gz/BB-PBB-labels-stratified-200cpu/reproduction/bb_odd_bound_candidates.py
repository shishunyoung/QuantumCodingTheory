#!/usr/bin/env python3
"""Deterministic non-A3B3 CSS BB proposals for an odd-upper-bound campaign.

The allowed unordered support-size pairs each contain an even size. This
removes the both-odd support parity obstruction, but does not guarantee an odd
distance or upper bound. No distance search or label screening occurs here.
Only the caller can admit a code after its complete three-method budget.

Structure weights and length/axis-grid balance describe proposals *before*
structural rejection, corpus deduplication and label filtering. Accepted-code
frequencies will generally differ. The sampling distribution is ours, not the
unpublished distribution used by the BBNet authors.
"""
from __future__ import annotations

import hashlib
import json
import random
from functools import lru_cache

from bb_distance_candidates import DEDUP_SCOPE, canonical_key, structural_metadata


SAMPLER_VERSION = "css_bb_odd_capable_weighted_structure_length_axis_grid_v1"
STRUCTURES = ((4, 4), (2, 3), (3, 4), (4, 5), (2, 4))
STRUCTURE_NAMES = tuple(f"A{a}B{b}" for a, b in STRUCTURES)
DEFAULT_STRUCTURE_WEIGHTS = (4, 2, 2, 1, 1)
LENGTH_BINS = ((18, 72), (73, 144), (145, 216), (217, 288), (289, 360))


def _integer(value, name, minimum=0):
    if type(value) is not int or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")
    return value


def normalize_structure_weights(weights):
    """Validate and normalize list/tuple CLI/config values to a stable tuple."""
    if not isinstance(weights, (list, tuple)) or len(weights) != len(STRUCTURES):
        raise ValueError(f"structure_weights must contain {len(STRUCTURES)} integers")
    result = tuple(_integer(value, "structure weight") for value in weights)
    if not sum(result):
        raise ValueError("At least one structure weight must be positive")
    return result


@lru_cache(maxsize=64, typed=True)
def _dimension_strata(ell_min, ell_max, m_min, m_max, n_min, n_max,
                      terms_a, terms_b):
    """Nonempty intersections with fixed corpus length strata.

    Both axis and full-grid pools must have sufficient distinct monomials.
    The range checks live here as well so direct helper calls cannot bypass
    validation through cached equal-looking bool/float arguments.
    """
    for name in ("ell_min", "ell_max", "m_min", "m_max"):
        _integer(locals()[name], name, 3)
    for name in ("n_min", "n_max"):
        _integer(locals()[name], name, 18)
    for name in ("terms_a", "terms_b"):
        _integer(locals()[name], name, 2)
    if ell_min > ell_max or m_min > m_max or n_min > n_max:
        raise ValueError("Minimum range endpoints must not exceed maxima")
    if ell_max > 30 or m_max > 30 or n_max > 360:
        raise ValueError("This corpus requires ell,m <= 30 and n = 2*ell*m <= 360")
    result = []
    needed = max(terms_a, terms_b)
    for low, high in LENGTH_BINS:
        lower, upper = max(low, n_min), min(high, n_max)
        if lower > upper:
            continue
        pairs = tuple((ell, m)
                      for ell in range(ell_min, ell_max + 1)
                      for m in range(m_min, m_max + 1)
                      if lower <= 2 * ell * m <= upper
                      and ell + m - 1 >= needed and ell * m >= needed)
        if pairs:
            result.append((lower, upper, pairs))
    if not result:
        raise ValueError("No lattice meets the requested ranges and support sizes")
    return tuple(result)


def candidate_for_index(index, seed, ell_min=3, ell_max=30, m_min=3, m_max=30,
                        n_min=18, n_max=360, connected_only=True, k_max=0,
                        structure_weights=DEFAULT_STRUCTURE_WEIGHTS):
    """Return ``{status, reason, candidate}`` for one independently seeded proposal.

    In each structure cycle, structures receive their exact integer weights.
    Successive cycles rotate through nonempty length strata; after a complete
    length pass the support mode switches between axis and full grid. With
    defaults, every 100 proposals cover the full weighted structure x five
    length strata x two support modes. Dimensions are uniform among ordered
    (ell,m) pairs within the selected stratum, not uniform over block lengths.

    A/B register swaps are equivalent under DEDUP_SCOPE, so mixed sizes are
    emitted only in their listed orientation. k_max=0 imposes no upper cap.
    Rejected proposals retain their full construction and structural metadata.
    """
    _integer(index, "index")
    _integer(seed, "seed")
    _integer(k_max, "k_max")
    if type(connected_only) is not bool:
        raise ValueError("connected_only must be a boolean")
    weights = normalize_structure_weights(structure_weights)
    # Validate all positive-weight structure pools, not only the chosen one.
    pools = {name: _dimension_strata(ell_min, ell_max, m_min, m_max, n_min, n_max, a, b)
             for name, (a, b), weight in zip(STRUCTURE_NAMES, STRUCTURES, weights) if weight}
    cycle_size = sum(weights)
    position = index % cycle_size
    for structure_name, (terms_a, terms_b), weight in zip(STRUCTURE_NAMES, STRUCTURES, weights):
        if position < weight:
            break
        position -= weight
    strata = pools[structure_name]
    cycle = index // cycle_size
    lower, upper, dimensions = strata[cycle % len(strata)]
    family = "axis" if (cycle // len(strata)) % 2 == 0 else "grid"
    settings = dict(ell_min=ell_min, ell_max=ell_max, m_min=m_min, m_max=m_max,
                    n_min=n_min, n_max=n_max, connected_only=connected_only,
                    k_max=k_max, structure_weights=list(weights))
    material = {"version": SAMPLER_VERSION, "index": index, "seed": seed,
                "settings": settings}
    digest = hashlib.sha256(json.dumps(material, sort_keys=True,
                                      separators=(",", ":")).encode()).hexdigest()
    candidate_seed = int(digest[:16], 16)
    rng = random.Random(candidate_seed)
    ell, m = rng.choice(dimensions)
    if family == "axis":
        support_pool = [(a, 0) for a in range(ell)] + [(0, b) for b in range(1, m)]
    else:
        support_pool = [(a, b) for a in range(ell) for b in range(m)]
    A, B = sorted(rng.sample(support_pool, terms_a)), sorted(rng.sample(support_pool, terms_b))
    row = {
        "id": f"bb-odd-{index:09d}-{digest[:12]}",
        "candidate_index": index, "raw_attempt": index + 1,
        "candidate_seed": candidate_seed, "sampler_version": SAMPLER_VERSION,
        "family": "CSS", "structure_family": structure_name,
        "sampling_family": family, "sampling_mode": "stratified",
        "length_stratum": f"n{lower}-{upper}", "ell": ell, "m": m,
        "A": [list(pair) for pair in A], "B": [list(pair) for pair in B],
        "C": [], "D": [], "support_sizes": [terms_a, terms_b],
        "dedup_scope": DEDUP_SCOPE,
        "sampling_policy": {
            "global_seed": seed, "settings": settings,
            "structure_names": list(STRUCTURE_NAMES),
            "structure_orientation": "one representative per unordered A/B support-size pair",
            "length_sampling": "cycle over nonempty fixed length strata before structural rejection",
            "dimension_sampling": "uniform_ordered_ell_m_pair_within_selected_stratum",
            "eligible_dimension_pairs_in_selected_stratum": len(dimensions),
            "support_sampling": "independent_uniform_distinct_terms_per_polynomial",
            "proposal_balance_only": True,
            "proposal_distance_searches": 0,
            "odd_true_distance_guaranteed": False,
            "distance_lower_bound_certified": False,
        },
    }
    row.update(structural_metadata(ell, m, A, B))
    row["canonical_key"] = canonical_key(row)
    row["group_id"] = row["canonical_key"]
    reason = None
    if row["k"] <= 0:
        reason = "no_logical_qubits"
    elif connected_only and not row["connected"]:
        reason = "disconnected_tanner_graph"
    elif k_max and row["k"] > k_max:
        reason = "logical_dimension_above_cap"
    return {"status": "rejected" if reason else "ok", "reason": reason,
            "candidate": row}
