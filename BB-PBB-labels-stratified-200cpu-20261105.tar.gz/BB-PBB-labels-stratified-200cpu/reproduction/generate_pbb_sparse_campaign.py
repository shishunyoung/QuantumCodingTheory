#!/usr/bin/env python3
"""Independent sparse-PBB campaign; old generators and frozen runs stay unchanged.

Target counts *candidates*, not in-range labels. Every selected code receives
all three 10,000-trial searches. All valid upper bounds remain in labels.jsonl;
labels_2_25.jsonl is a separate, unclipped paper-range view. Prepare-only uses
standard-library construction/audit code and never invokes a distance solver.
"""
from __future__ import annotations

import argparse
from collections import Counter
from concurrent.futures import FIRST_COMPLETED, ProcessPoolExecutor, wait
import hashlib
import math
import multiprocessing
import os
from pathlib import Path
import sys
import time

import generate_pbb_distance_dataset as base
import generate_pbb_distance_campaign as common
import pbb_sparse_candidates as sampler

HERE = Path(__file__).resolve().parent
SCHEMA = 'pbb_sparse_commuting_campaign_v1'
METHODS = base.METHODS
SOURCE_FILES = (*common.SOURCE_FILES, 'pbb_sparse_candidates.py', Path(__file__).name)
DEFAULT_SEED = 2026110502


def sampling_config(args):
    settings = base.sampling_config(args)
    if min(settings['ell_min'], settings['m_min']) < 3 or settings['n_min'] < 18:
        raise ValueError('Paper corpus requires ell,m >=3 and n >=18')
    settings.update(perturbation_patterns=[list(pair) for pair in args.perturbation_patterns],
                    max_base_attempts=args.max_base_attempts,
                    max_matches_per_base=args.max_matches_per_base,
                    require_cross_cancellation=not args.allow_separate_commutation)
    return settings


def scientific_config(args, exclusions):
    if args.trials != 10000:
        raise ValueError('Sparse campaign requires exactly 10000 trials per method')
    return {
        'schema': SCHEMA, 'target_codes': args.target, 'trials_per_method': 10000,
        'methods': list(METHODS), 'seed': args.seed, 'sampling': sampling_config(args),
        'sampler_version': sampler.SAMPLER_VERSION, 'dedup_scope': sampler.DEDUP_SCOPE,
        'source_sha256': {name: base.sha256_file(HERE / name) for name in SOURCE_FILES},
        'backend': base.backend.backend_manifest(), 'exclusions': exclusions,
        'budget_convention': 'exactly 10000 complete trials for EACH of three methods',
        'label_kind': 'verified_heuristic_upper_bound', 'is_exact': False,
        'distance_filter': None, 'paper_label_range': [2, 25],
        'population_kind': 'additional_sparse_commuting_PBB_candidates_excluding_prior_specifications',
        'target_semantics': 'number of selected valid candidates searched; NOT number of labels in 2..25',
        'sampling_scope': 'independent sparse commutation-equation sampler, not the unpublished author distribution',
    }


def validate_candidate(row, config):
    key = base.validate_candidate(row, config)
    settings = config['sampling']
    if (len(row['A']), len(row['B'])) != (settings['terms_a'], settings['terms_b']):
        raise ValueError('A/B support sizes differ from frozen sparse-sampler configuration')
    patterns = {tuple(pair) for pair in settings['perturbation_patterns']}
    if (len(row['C']), len(row['D'])) not in patterns:
        raise ValueError('C/D support sizes differ from frozen sparse-sampler configuration')
    if row.get('sampler_version') != config['sampler_version']:
        raise ValueError('Candidate comes from a different sampler version')
    if settings['require_cross_cancellation'] and not sampler.commutation_signature(
            row['ell'], row['m'], row['A'], row['C']):
        raise ValueError('Frozen sampler requires nonzero joint cross-cancellation')
    return key


def load_candidates(db, config, replay=True):
    # Reuse immutable payload, dimensions and genuine-non-CSS validation, but
    # deliberately do not call the old sampler when replaying this new family.
    rows = base.load_candidates(db, config, replay=False)
    for row in rows:
        validate_candidate(row, config)
        if replay:
            proposal = sampler.candidate_for_index(row['candidate_index'], config['seed'],
                                                   **config['sampling'])
            if proposal['status'] != 'ok' or proposal['candidate'] != row:
                raise ValueError('Frozen candidate differs from deterministic sparse sampler replay')
    return rows


def _proposal_task(request):
    index, seed, settings = request
    proposal = sampler.candidate_for_index(index, seed, **settings)
    return {'index': index, 'status': proposal['status'], 'reason': proposal.get('reason'),
            'candidate': proposal['candidate'] if proposal['status'] == 'ok' else None}


def prepare_population(db, output, config, excluded, max_candidates, workers, batch_size):
    rows = load_candidates(db, config)
    seen = {row['canonical_key'] for row in rows}
    if seen & excluded:
        raise ValueError('Frozen sparse population overlaps prior exclusions')
    index = base._get_metadata(db, 'next_candidate_index', 0)
    count, maximum = db.execute('SELECT COUNT(*),MAX(candidate_index) FROM attempts').fetchone()
    if count != index or (index and maximum != index - 1):
        raise ValueError('Candidate journal does not contain a contiguous consumed prefix')
    if len(rows) < config['target_codes']:
        with ProcessPoolExecutor(max_workers=workers,
                                 mp_context=multiprocessing.get_context('spawn')) as pool:
            while len(rows) < config['target_codes'] and index < max_candidates:
                stop = min(max_candidates, index + batch_size)
                requests = ((i, config['seed'], config['sampling']) for i in range(index, stop))
                proposals = list(pool.map(_proposal_task, requests, chunksize=1))
                additions, new_keys, consumed = [], set(), index
                with db:
                    for proposal in proposals:
                        if proposal['index'] != consumed:
                            raise ValueError('Parallel generation returned an out-of-order index')
                        outcome, reason = proposal['status'], proposal.get('reason')
                        if outcome == 'ok':
                            row = proposal['candidate']
                            if row.get('candidate_index') != consumed:
                                raise ValueError('Proposal identity differs from requested index')
                            key = validate_candidate(row, config)
                            if key in excluded:
                                outcome, reason = 'excluded', 'prior_PBB_candidate'
                            elif key in seen or key in new_keys:
                                outcome, reason = 'duplicate', 'supported_PBB_canonical_symmetry'
                            else:
                                payload = base.json_text(row)
                                db.execute('INSERT INTO candidates VALUES (?,?,?,?,?)',
                                           (row['id'], consumed, key, payload,
                                            base.digest_bytes(payload.encode())))
                                outcome = 'accepted'
                                additions.append(row)
                                new_keys.add(key)
                        elif outcome != 'rejected':
                            raise ValueError('Unknown sparse candidate proposal status')
                        db.execute('INSERT INTO attempts VALUES (?,?,?)', (consumed, outcome, reason))
                        consumed += 1
                        if len(rows) + len(additions) == config['target_codes']:
                            break
                    base._put_metadata(db, 'next_candidate_index', consumed)
                rows.extend(additions)
                seen.update(new_keys)
                index = consumed
                progress = {'schema': SCHEMA, 'state': 'preparing', 'updated_utc': base.utc_now(),
                            'target_candidates': config['target_codes'], 'selected': len(rows),
                            'completed': 0, 'candidate_proposals': index,
                            'excluded_prior_codes': len(excluded),
                            'requested_trials_per_method': config['trials_per_method']}
                base.write_json(Path(output) / 'summary.json', progress)
                print(base.json_text({'event': 'population_progress', **progress}), flush=True)
    common.write_jsonl_stream(Path(output) / 'candidates.jsonl', rows)
    if len(rows) != config['target_codes']:
        raise RuntimeError(f"Only {len(rows)} / {config['target_codes']} candidates after {index} proposals; raise --max-candidates to resume")
    with db:
        base._put_metadata(db, 'population_complete', True)
    return rows


class Progress(common.Progress):
    def __init__(self, *args, **kwargs):
        self.exported_paper_labels = 0
        super().__init__(*args, **kwargs)

    def paper_labels(self):
        return [row for row in self.labels.values() if 2 <= row['d_upper'] <= 25]

    def summary(self, state='running'):
        result = super().summary(state)
        paper = self.paper_labels()
        result.update(schema=SCHEMA, target_semantics=self.config['target_semantics'],
                      target_candidates=self.config['target_codes'],
                      paper_label_range=[2, 25], paper_range_completed_codes=len(paper),
                      out_of_paper_range_completed_codes=len(self.labels) - len(paper),
                      full_export_paper_range_codes=self.exported_paper_labels,
                      selected_support_sizes=dict(Counter('-'.join(str(len(row[p])) for p in 'ABCD')
                                                          for row in self.candidates)),
                      completed_support_sizes=dict(Counter('-'.join(str(len(row[p])) for p in 'ABCD')
                                                           for row in self.labels.values())),
                      paper_range_histogram=dict(sorted(Counter(row['d_upper'] for row in paper).items())))
        return result

    def export(self, output, state='running'):
        common.write_jsonl_stream(Path(output) / 'labels_2_25.jsonl',
                                  (self.labels[row['id']] for row in self.candidates
                                   if row['id'] in self.labels
                                   and 2 <= self.labels[row['id']]['d_upper'] <= 25))
        self.exported_paper_labels = len(self.paper_labels())
        return super().export(output, state)


def run_pending(db, output, config, candidates, workers, timeout, export_interval, runner=None):
    results = base.load_results(db, candidates, config, revalidate=True)
    progress = Progress(db, candidates, config, results)
    tasks = [(row, method) for row in candidates for method in METHODS
             if (row['id'], method) not in results]
    runner = runner or base._run_method_task
    progress.export(output, 'running')
    last_export, failed, submitted = time.monotonic(), False, 0
    if tasks:
        with ProcessPoolExecutor(max_workers=workers,
                                 mp_context=multiprocessing.get_context('spawn')) as pool:
            active = {}
            while submitted < len(tasks) or active:
                while not failed and submitted < len(tasks) and len(active) < workers:
                    candidate, method = tasks[submitted]
                    seed = base.result_seed(config['seed'], candidate['id'], method)
                    future = pool.submit(runner, candidate, method,
                                         config['trials_per_method'], seed, timeout)
                    active[future] = (candidate, method)
                    submitted += 1
                if not active:
                    break
                done, _ = wait(active, return_when=FIRST_COMPLETED)
                for future in done:
                    candidate, method = active.pop(future)
                    try:
                        checked = base.commit_result(db, candidate, method, future.result(), config)
                        if not checked['validated']:
                            failed = True
                            progress.failed(candidate['id'], method)
                        else:
                            progress.add(checked)
                    except Exception as error:
                        failed = True
                        base.record_error(db, candidate['id'], method,
                                          {'error': f'{type(error).__name__}: {error}',
                                           'completed_budget_claimed': False})
                        progress.failed(candidate['id'], method)
                    state = 'failed_partial' if failed else 'running'
                    if time.monotonic() - last_export >= export_interval:
                        summary = progress.export(output, state)
                        last_export = time.monotonic()
                    else:
                        summary = progress.save_summary(output, state)
                    print(base.json_text({'event': 'progress', 'completed': summary['completed'],
                                          'target_candidates': config['target_codes'],
                                          'paper_range_completed_codes': summary['paper_range_completed_codes'],
                                          'saved_method_results': summary['saved_method_results'],
                                          'actual_trials': summary['recorded_actual_trials']}), flush=True)
    progress.export(output, 'failed_partial' if failed else 'complete_pending_audit')
    return not failed


def independent_completion_audit(db, output, config):
    output = Path(output)
    if {name: base.sha256_file(HERE / name) for name in SOURCE_FILES} != config['source_sha256']:
        raise ValueError('Sparse campaign or dependency source files changed')
    if base.backend.backend_manifest() != config['backend']:
        raise ValueError('Frozen backend manifest changed')
    excluded = common.verify_exclusions(output, config['exclusions'])
    candidates = load_candidates(db, config, replay=True)
    if {row['canonical_key'] for row in candidates} & excluded:
        raise ValueError('Sparse campaign population overlaps prior PBB candidates')
    results = base.load_results(db, candidates, config, revalidate=True)
    if len(candidates) != config['target_codes'] or len(results) != len(METHODS) * config['target_codes']:
        raise ValueError('Completion requires all candidates and all three full method budgets')
    expected = hashlib.sha256()
    for row in candidates:
        expected.update((base.json_text(row) + '\n').encode())
    if base.sha256_file(output / 'candidates.jsonl') != expected.hexdigest():
        raise ValueError('Published candidates differ from the frozen journal')
    progress = Progress(db, candidates, config, results)
    if progress.unresolved:
        raise ValueError('Completion has unresolved method failures')
    summary = progress.export(output, 'complete')
    receipt = {'schema': SCHEMA, 'state': 'complete_verified', 'checked_utc': base.utc_now(),
               'candidate_codes': len(candidates), 'codes': len(candidates),
               'paper_range_codes': summary['paper_range_completed_codes'],
               'target_semantics': config['target_semantics'],
               'methods': len(results), 'actual_trials': summary['recorded_actual_trials'],
               'trials_per_method': config['trials_per_method'], 'excluded_prior_codes': len(excluded),
               'all_candidates_genuinely_non_css': True, 'all_witnesses_verified': True,
               'canonical_duplicates': 0, 'is_exact': False,
               'configuration_sha256': summary['configuration_sha256'],
               'output_sha256': {name: base.sha256_file(output / name) for name in
                    ('candidates.jsonl', 'labels.jsonl', 'labels_2_25.jsonl', 'methods.jsonl', 'summary.json')}}
    base.write_json(output / 'completion_verified.json', receipt)
    return receipt


def pattern_argument(value):
    try:
        pair = tuple(int(part) for part in value.split(':'))
    except ValueError:
        raise argparse.ArgumentTypeError('Use a sparse C:D support-size pair, e.g. 2:2')
    if len(pair) != 2 or any(term not in (1, 2) for term in pair):
        raise argparse.ArgumentTypeError('C/D support sizes must each be 1 or 2')
    return pair


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--target', type=int, default=100)
    parser.add_argument('--trials', type=int, default=10000)
    parser.add_argument('--workers', type=int, default=1)
    parser.add_argument('--prepare-workers', type=int)
    parser.add_argument('--prepare-batch-size', type=int, default=8)
    parser.add_argument('--export-interval-seconds', type=float, default=300)
    parser.add_argument('--seed', type=int, default=DEFAULT_SEED)
    parser.add_argument('--skip-codes', type=Path, action='append', default=[])
    parser.add_argument('--max-candidates', type=int, default=10000)
    parser.add_argument('--method-timeout-seconds', type=float)
    parser.add_argument('--perturbation-patterns', nargs='+', type=pattern_argument,
                        default=[(2, 2), (1, 2), (2, 1)])
    parser.add_argument('--max-base-attempts', type=int, default=64)
    parser.add_argument('--max-matches-per-base', type=int, default=8)
    parser.add_argument('--allow-separate-commutation', action='store_true')
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--prepare-only', action='store_true')
    mode.add_argument('--export-only', action='store_true')
    for name, default in (('ell_min', 3), ('ell_max', 30), ('m_min', 3), ('m_max', 30),
                          ('n_min', 18), ('n_max', 360), ('terms_a', 3), ('terms_b', 3)):
        parser.add_argument('--' + name.replace('_', '-'), type=int, default=default)
    args = parser.parse_args(argv)
    args.prepare_workers = args.workers if args.prepare_workers is None else args.prepare_workers
    if min(args.target, args.workers, args.prepare_workers, args.prepare_batch_size,
           args.max_candidates, args.max_base_attempts, args.max_matches_per_base) < 1 or args.seed < 0:
        parser.error('All counts must be positive; seed must be nonnegative')
    if args.trials != 10000:
        parser.error('This campaign requires exactly 10000 trials per method')
    if not math.isfinite(args.export_interval_seconds) or args.export_interval_seconds <= 0:
        parser.error('Export interval must be positive and finite')
    if args.method_timeout_seconds is not None and (not math.isfinite(args.method_timeout_seconds)
                                                    or args.method_timeout_seconds <= 0):
        parser.error('Method timeout must be positive and finite')
    if len(set(args.perturbation_patterns)) != len(args.perturbation_patterns):
        parser.error('Repeated perturbation patterns are not permitted')
    try:
        sampling_config(args)
    except ValueError as error:
        parser.error(str(error))
    allocated = os.environ.get('SLURM_CPUS_PER_TASK')
    if allocated and max(args.workers, args.prepare_workers) > int(allocated):
        parser.error('Workers cannot exceed the Slurm CPU allocation')
    return args


def main(argv=None):
    args = parse_args(argv)
    output = args.output_dir.expanduser().resolve()
    with base.run_lock(output):
        if args.export_only and not (output / 'state.sqlite3').exists():
            raise ValueError('--export-only requires an existing journal')
        exclusions, excluded = common.freeze_exclusions(output, args.skip_codes)
        config = scientific_config(args, exclusions)
        db = base.open_database(output / 'state.sqlite3', config)
        try:
            base.write_json(output / 'configuration.json', config)
            if args.export_only:
                candidates = load_candidates(db, config)
                if {row['canonical_key'] for row in candidates} & excluded:
                    raise ValueError('Stored candidate overlaps prior exclusions')
            else:
                candidates = prepare_population(db, output, config, excluded, args.max_candidates,
                                                args.prepare_workers, args.prepare_batch_size)
            if args.prepare_only or args.export_only:
                results = base.load_results(db, candidates, config, revalidate=True)
                progress = Progress(db, candidates, config, results)
                summary = progress.export(output, 'prepared' if args.prepare_only else 'exported_partial')
                complete = len(progress.labels) == config['target_codes']
            else:
                if not run_pending(db, output, config, candidates, args.workers,
                                   args.method_timeout_seconds, args.export_interval_seconds):
                    return 1
                complete = True
            if complete:
                print(base.json_text(independent_completion_audit(db, output, config)), flush=True)
            else:
                print(base.json_text(summary), flush=True)
            return 0
        finally:
            db.close()


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(130)
    except Exception as error:
        print(f'PBB sparse campaign failed: {type(error).__name__}: {error}', file=sys.stderr, flush=True)
        raise SystemExit(1)
