#!/usr/bin/env python3
"""Generate NEW heuristic BB labels in disjoint U<=14 and 15<=U<=30 quotas.

Every admitted code completes BP-OSD, QDistRnd and QDistEvol, 10,000 trials each.
This is our explicit per-method budget convention (30,000 per code). The
corpus is restricted to n = 2*ell*m <= 360 with ell,m <= 30.
U is a witnessed upper bound, never an exact distance or a lower bound. Frozen
method implementations and child-per-method process isolation are reused.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import multiprocessing
import os
import sqlite3
import sys
import time
from collections import Counter
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import bb_distance_backend as backend
import run_bb_distance_isolated as isolation
from bb_distance_candidates import candidate_for_index, canonical_key, SAMPLER_VERSION, DEDUP_SCOPE
from generate_bb_distance_dataset import (METHODS, RunLock, json_text, result_seed,
    sha256_file, utc_now, write_json, write_jsonl)

HERE = Path(__file__).resolve().parent
DEFAULT_TRIALS = 10_000
MAX_N = 360
MAX_DIMENSION = 30
BUDGET_CONVENTION = "Our explicit setting: 10000 trials per method per code; 30000 total across three methods"
DEPENDENCIES = ("generate_bb_distance_10000_trials.py", "generate_bb_distance_dataset.py",
    "bb_distance_backend.py", "bb_distance_candidates.py", "bb_code_algebra.py",
    "run_bb_distance_isolated.py", "requirements-bb-distance.txt")


def _object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def _nonfinite(value):
    raise ValueError(f"Nonfinite JSON value: {value}")


def read_json(data):
    return json.loads(data, object_pairs_hook=_object, parse_constant=_nonfinite)


def validate_corpus_bounds(row):
    """Reject an actual search candidate outside the pinned corpus limits.

    Exclusion sources may describe larger codes, but no proposed, resumed,
    executed or admitted code may exceed these bounds. Identity construction
    and monomial validation remain the job of structural_key/backend.
    """
    if not isinstance(row, dict):
        raise ValueError("Candidate must be a JSON object")
    for field in ("ell", "m"):
        value = row.get(field)
        if type(value) is not int or not 1 <= value <= MAX_DIMENSION:
            raise ValueError(f"Corpus restriction requires integer {field} in 1..{MAX_DIMENSION}")
    n = 2 * row["ell"] * row["m"]
    if n > MAX_N:
        raise ValueError(f"Corpus restriction requires n=2*ell*m <= {MAX_N}; got {n}")
    if "n" in row and (type(row["n"]) is not int or row["n"] != n):
        raise ValueError("Candidate n disagrees with n=2*ell*m")
    return n


def validate_sampling_bounds(sampling):
    """Check both endpoints before the sampler constructs any lattice."""
    for prefix, maximum in (("ell", MAX_DIMENSION), ("m", MAX_DIMENSION), ("n", MAX_N)):
        low, high = sampling.get(prefix + "_min"), sampling.get(prefix + "_max")
        if type(low) is not int or type(high) is not int or not 1 <= low <= high <= maximum:
            raise ValueError(f"Corpus restriction requires 1 <= {prefix}_min <= {prefix}_max <= {maximum}")
    return sampling


def structural_key(row):
    """Compute the key from the construction, without needing a distance label."""
    if not isinstance(row, dict) or row.get("family", "CSS") != "CSS":
        raise ValueError("Exclusion/candidate must be an ordinary CSS BB record")
    key = canonical_key(row)  # Strict integer dimensions and exponent pairs.
    n = 2 * row["ell"] * row["m"]
    if "n" in row and (type(row["n"]) is not int or row["n"] != n):
        raise ValueError("Candidate n disagrees with its construction")
    return key


def initialize_exclusions(output, paths):
    """Read each previous searched population once; freeze exact source bytes."""
    output = Path(output)
    directory = output / "exclusions"
    manifest_path = directory / "manifest.json"
    supplied = [str(Path(p).expanduser().resolve()) for p in paths]
    if manifest_path.is_file():
        manifest = read_json(manifest_path.read_bytes())
        if supplied and supplied != manifest["source_paths"]:
            raise ValueError("Exclusion paths changed; use the frozen campaign exclusions")
        key_path = directory / "canonical_keys.json"
        if sha256_file(key_path) != manifest["keys_sha256"]:
            raise ValueError("Frozen exclusion keys hash mismatch")
        keys = read_json(key_path.read_bytes())
        if not isinstance(keys, list) or keys != sorted(set(keys)) or len(keys) != manifest["distinct_groups"]:
            raise ValueError("Frozen exclusion keys are inconsistent")
        for source in manifest["sources"]:
            if sha256_file(directory / source["snapshot_name"]) != source["sha256"]:
                raise ValueError("Frozen exclusion source hash mismatch")
        return keys, manifest
    if not paths:
        raise ValueError("Initial run requires --exclude containing ALL previously searched candidates")
    if (output / "state.sqlite3").exists():
        raise ValueError("Journal exists without a complete frozen exclusion manifest")
    keys, sources, frozen = set(), [], []
    for index, path in enumerate(supplied):
        data = Path(path).read_bytes()
        records = 0
        for line_number, line in enumerate(data.splitlines(), 1):
            if not line.strip():
                continue
            try:
                keys.add(structural_key(read_json(line)))
            except Exception as error:
                raise ValueError(f"Invalid exclusion {path}:{line_number}: {error}") from error
            records += 1
        if not records:
            raise ValueError(f"Exclusion population is empty: {path}")
        name = f"source-{index:03d}.jsonl"
        sources.append({"path": path, "snapshot_name": name, "records": records,
                        "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
        frozen.append((name, data))
    directory.mkdir(parents=True, exist_ok=True)
    for name, data in frozen:
        temporary = directory / (name + ".tmp")
        temporary.write_bytes(data)
        temporary.replace(directory / name)
    write_json(directory / "canonical_keys.json", sorted(keys))
    manifest = {"created_utc": utc_now(), "source_paths": supplied, "sources": sources,
        "source_records": sum(s["records"] for s in sources), "distinct_groups": len(keys),
        "keys_sha256": sha256_file(directory / "canonical_keys.json"),
        "key_rule": "Recomputed from ell,m,A,B; previous witness/label not required",
        "dedup_scope": DEDUP_SCOPE}
    write_json(manifest_path, manifest)
    return sorted(keys), manifest


def open_database(path, config, excluded_keys):
    db = sqlite3.connect(path)
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("PRAGMA synchronous=FULL")
    db.execute("PRAGMA foreign_keys=ON")
    db.executescript("""
      CREATE TABLE IF NOT EXISTS metadata(key TEXT PRIMARY KEY,value TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS excluded(canonical_key TEXT PRIMARY KEY);
      CREATE TABLE IF NOT EXISTS candidates(id TEXT PRIMARY KEY,candidate_index INTEGER UNIQUE NOT NULL,
        canonical_key TEXT UNIQUE NOT NULL,payload TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS attempts(attempt_index INTEGER PRIMARY KEY,outcome TEXT NOT NULL,
        candidate_id TEXT,reason TEXT);
      CREATE TABLE IF NOT EXISTS results(candidate_id TEXT NOT NULL REFERENCES candidates(id),
        method TEXT NOT NULL,payload TEXT NOT NULL,validated INTEGER NOT NULL,validation_error TEXT,
        actual_trials INTEGER,cpu_seconds REAL,wall_seconds REAL,PRIMARY KEY(candidate_id,method));
      CREATE TABLE IF NOT EXISTS admissions(candidate_id TEXT PRIMARY KEY REFERENCES candidates(id),
        candidate_index INTEGER UNIQUE NOT NULL,outcome TEXT NOT NULL,payload TEXT NOT NULL);
    """)
    existing = db.execute("SELECT value FROM metadata WHERE key='config'").fetchone()
    if existing and read_json(existing[0]) != config:
        db.close()
        raise ValueError("Run configuration/source changed; use a new output directory")
    with db:
        if not existing:
            db.execute("INSERT INTO metadata VALUES ('config',?)", (json_text(config),))
            db.executemany("INSERT INTO excluded VALUES (?)", ((key,) for key in excluded_keys))
    actual = [key for (key,) in db.execute("SELECT canonical_key FROM excluded ORDER BY canonical_key")]
    if actual != sorted(excluded_keys):
        db.close()
        raise ValueError("Journal exclusions disagree with frozen exclusion snapshot")
    return db


def strict_validate_result(row, result, trials, seed, prepared=None):
    """Replay budget, pinned method settings and BOTH forms of witness evidence."""
    validate_corpus_bounds(row)
    method = result.get("method")
    if method not in METHODS or result.get("id") != row["id"]:
        raise ValueError("Method result identity differs from its candidate")
    if type(trials) is not int or trials != DEFAULT_TRIALS:
        raise ValueError(f"This campaign requires exactly {DEFAULT_TRIALS} trials per method")
    for name in ("requested_trials", "returned_trials"):
        if type(result.get(name)) is not int or result[name] != trials:
            raise ValueError("Incomplete or changed method trial budget")
    if (result.get("status") != "ok" or result.get("budget_completed") is not True
            or result.get("valid_upper_bound") is not True or result.get("is_exact") is not False
            or result.get("seed_argument") != result_seed(seed, row, method)):
        raise ValueError("Method failed, changed seed, or claimed exactness")
    if result.get("source_commit") != backend.SOURCE_COMMIT or result.get("backend_method") != backend.METHOD_IDS[method]:
        raise ValueError("Method backend/source differs from pinned implementation")
    params = backend.method_params(method, trials)
    if result.get("requested_params") != params:
        raise ValueError("Requested method settings differ from frozen parameters")
    effective = result.get("effective_params", {})
    for name in ("iterCount", "nThreads", "LOCheck", "maxErr"):
        if effective.get(name) != params[name]:
            raise ValueError(f"Effective budget/search setting changed: {name}")
    if method != "BP-OSD" and effective.get("genCount") != params["genCount"]:
        raise ValueError("Effective QDist generation count changed")
    overlay = result.get("execution_overlay", {})
    if (overlay.get("execution_policy") != isolation.POLICY
            or overlay.get("launcher_sha256") != sha256_file(HERE / "run_bb_distance_isolated.py")
            or overlay.get("child_returncode") != 0
            or type(overlay.get("child_pid")) is not int
            or overlay["child_pid"] != result.get("pid")
            or overlay["child_pid"] == overlay.get("outer_worker_pid")):
        raise ValueError("Result lacks verified fresh-child execution provenance")
    prepared = prepared or backend.prepare_code(row)
    if result.get("structure") != prepared["structure"]:
        raise ValueError("Result structure differs from reconstructed CSS model")
    bits = result.get("returned_witness_bits")
    if not isinstance(bits, list) or any(type(bit) is not int or bit not in (0, 1) for bit in bits):
        raise ValueError("Raw witness must contain integer binary bits")
    checked = backend.verify_result(prepared, {"L": bits, "T": result["returned_trials"],
        "d": result.get("returned_distance")}, trials)
    if (type(result.get("d_upper")) is not int or result["d_upper"] != checked["d_upper"]
            or result.get("witness") != checked["witness"]
            or result.get("reported_distance_matches_weight") != checked["reported_distance_matches_weight"]):
        raise ValueError("Exported witness/upper bound differs from independently validated raw evidence")
    return checked


def store_result(db, row, result, config):
    error = None
    try:
        strict_validate_result(row, result, config["trials"], config["seed"])
    except Exception as exception:
        error = f"{type(exception).__name__}: {exception}"
    if result.get("id") != row["id"] or result.get("method") not in METHODS:
        raise ValueError("Cannot journal result under a different candidate or method")
    def finite(name):
        value = result.get(name)
        return value if type(value) in (int, float) and math.isfinite(value) and value >= 0 else None
    with db:
        db.execute("INSERT INTO results VALUES (?,?,?,?,?,?,?,?)", (row["id"], result["method"],
            json_text(result), int(error is None), error,
            result.get("returned_trials") if type(result.get("returned_trials")) is int else None,
            finite("algorithm_cpu_seconds"), finite("algorithm_wall_seconds")))
    return error


def label_for(row, records, config):
    validate_corpus_bounds(row)
    if len(records) != 3 or {r["method"] for r in records} != set(METHODS):
        raise ValueError("Admission requires all three methods")
    prepared = backend.prepare_code(row)
    for result in records:
        strict_validate_result(row, result, config["trials"], config["seed"], prepared)
    by_method = {r["method"]: r for r in records}
    best = min((by_method[m] for m in METHODS), key=lambda r: r["d_upper"])
    label = {key: value for key, value in row.items() if key not in ("d_lower", "d_exact", "is_exact", "d_upper")}
    label.update(d_upper=best["d_upper"], d_exact=None, is_exact=False,
        label_kind="heuristic_upper_bound", selected_method=best["method"], trials_per_method=config["trials"],
        total_trials_per_code=config["trials"] * len(METHODS), budget_convention=BUDGET_CONVENTION,
        label_rule=f"Minimum validated physical witness weight after all three complete {config['trials']}-trial calls",
        witness_type="Z", witness_format="qubit_indices_0_based", witness=best["witness"]["Z"],
        methods={m: {key: by_method[m].get(key) for key in ("d_upper", "returned_distance",
            "reported_distance_matches_weight", "requested_trials", "returned_trials", "seed_argument",
            "algorithm_cpu_seconds", "algorithm_wall_seconds")} for m in METHODS},
        certification="Validated logical witness only; no optimality or lower-bound claim")
    return label


def _outcome(label, counts, config):
    upper = label["d_upper"]
    if upper > 30:
        return "above_30"
    bucket = "le14" if upper <= 14 else "15_30"
    return ("accepted_" if counts["accepted_" + bucket] < config["target_" + bucket] else "surplus_") + bucket


def sampling_phase(config, low_count):
    sampling = dict(config["sampling"])
    validate_sampling_bounds(sampling)
    high_min = config.get("high_phase_n_min", 0)
    if high_min and low_count >= config["target_le14"]:
        sampling["n_min"] = max(sampling["n_min"], high_min)
        validate_sampling_bounds(sampling)
        return "high_quota_after_low_complete", sampling
    return "initial_full_range", sampling


def finalize_admissions(db, config):
    counts = Counter(dict(db.execute("SELECT outcome,count(*) FROM admissions GROUP BY outcome")))
    pending = list(db.execute("""SELECT c.id,c.candidate_index,c.payload FROM candidates c
        LEFT JOIN admissions a ON a.candidate_id=c.id WHERE a.candidate_id IS NULL ORDER BY c.candidate_index"""))
    finalized = 0
    for identifier, index, payload in pending:
        records = list(db.execute("SELECT payload,validated,validation_error FROM results WHERE candidate_id=?", (identifier,)))
        if any(not valid for _, valid, _ in records):
            raise ValueError(f"Invalid saved method result for {identifier}; no admission allowed")
        if len(records) < 3:
            break  # Strict index frontier; completion order cannot bias quota membership.
        label = label_for(read_json(payload), [read_json(r[0]) for r in records], config)
        outcome = _outcome(label, counts, config)
        label["quota_outcome"] = outcome
        with db:
            db.execute("INSERT INTO admissions VALUES (?,?,?,?)", (identifier, index, outcome, json_text(label)))
        counts[outcome] += 1
        finalized += 1
    return finalized


def audit_journal(db, config):
    """One complete replay per resume; batches only inspect new results."""
    validate_sampling_bounds(config["sampling"])
    counts, frontier = Counter(), False
    batch_start, phase, sampling = None, None, None
    for identifier, index, key, payload in db.execute("SELECT * FROM candidates ORDER BY candidate_index"):
        row = read_json(payload)
        validate_corpus_bounds(row)
        if "proposal_batch_start" in row:
            if row["proposal_batch_start"] != batch_start:
                if frontier:
                    raise ValueError("A later proposal batch crosses unfinished prior work")
                if batch_start is not None and row["proposal_batch_start"] <= batch_start:
                    raise ValueError("Candidate proposal batches are out of order")
                batch_start = row["proposal_batch_start"]
                phase, sampling = sampling_phase(config, counts["accepted_le14"])
            if row.get("sampling_phase") != phase or row.get("effective_sampling") != sampling:
                raise ValueError("Candidate sampling phase differs from durable quota ordering")
        elif "phase_policy" in config:
            raise ValueError("Candidate lacks its pinned sampling phase provenance")
        if structural_key(row) != key or row.get("canonical_key") != key or row.get("group_id") != key:
            raise ValueError("Journal candidate canonical identity changed")
        if row.get("candidate_index") != index or row.get("id") != identifier:
            raise ValueError("Journal candidate index/id changed")
        if db.execute("SELECT 1 FROM excluded WHERE canonical_key=?", (key,)).fetchone():
            raise ValueError("Journal contains a previously excluded candidate")
        records = list(db.execute("SELECT method,payload,validated FROM results WHERE candidate_id=?", (identifier,)))
        prepared = backend.prepare_code(row)
        for method, raw, valid in records:
            result = read_json(raw)
            if not valid or result.get("method") != method:
                raise ValueError("Saved method error requires investigation before resuming")
            strict_validate_result(row, result, config["trials"], config["seed"], prepared)
        admission = db.execute("SELECT candidate_index,outcome,payload FROM admissions WHERE candidate_id=?", (identifier,)).fetchone()
        if len(records) < 3 or not admission:
            frontier = True
        if admission:
            if frontier or admission[0] != index:
                raise ValueError("Admission crosses the unfinished candidate-index frontier")
            label = label_for(row, [read_json(r[1]) for r in records], config)
            outcome = _outcome(label, counts, config)
            label["quota_outcome"] = outcome
            if admission[1] != outcome or read_json(admission[2]) != label:
                raise ValueError("Saved admission differs from replayed methods/quota ordering")
            counts[outcome] += 1


def fill_batch(db, config, size):
    validate_sampling_bounds(config["sampling"])
    pending = [read_json(payload) for (payload,) in db.execute("""SELECT c.payload FROM candidates c
        LEFT JOIN admissions a ON a.candidate_id=c.id WHERE a.candidate_id IS NULL
        ORDER BY c.candidate_index LIMIT ?""", (size,))]
    if pending:
        for row in pending:
            validate_corpus_bounds(row)
        return pending  # Finish frozen work before proposing new candidates.
    distinct = db.execute("SELECT count(*) FROM candidates").fetchone()[0]
    index = db.execute("SELECT COALESCE(max(attempt_index)+1,0) FROM attempts").fetchone()[0]
    batch_start = index
    low_count = db.execute("SELECT count(*) FROM admissions WHERE outcome='accepted_le14'").fetchone()[0]
    phase, sampling = sampling_phase(config, low_count)
    validate_sampling_bounds(sampling)
    with db:
        while len(pending) < size and distinct < config["max_candidates"] and index < config["max_attempts"]:
            proposal = candidate_for_index(index, config["seed"], **sampling)
            row = proposal["candidate"]
            validate_corpus_bounds(row)
            row.update(sampling_phase=phase,effective_sampling=sampling,proposal_batch_start=batch_start)
            key = structural_key(row)
            if row.get("canonical_key") != key or row.get("group_id") != key:
                raise ValueError("Sampler returned an inconsistent canonical key")
            outcome, reason, cid = "structural_rejection", proposal["reason"], None
            if proposal["status"] == "ok":
                if db.execute("SELECT 1 FROM excluded WHERE canonical_key=?", (key,)).fetchone():
                    outcome, reason = "previously_searched", DEDUP_SCOPE
                else:
                    previous = db.execute("SELECT id FROM candidates WHERE canonical_key=?", (key,)).fetchone()
                    if previous:
                        outcome, reason, cid = "duplicate", DEDUP_SCOPE, previous[0]
                    else:
                        db.execute("INSERT INTO candidates VALUES (?,?,?,?)", (row["id"], index, key, json_text(row)))
                        pending.append(row)
                        distinct += 1
                        outcome, reason, cid = "scheduled", None, row["id"]
            db.execute("INSERT INTO attempts VALUES (?,?,?,?)", (index, outcome, cid, reason))
            index += 1
    return pending


def execute_batch(db, rows, config, executor):
    if type(config["trials"]) is not int or config["trials"] != DEFAULT_TRIALS:
        raise ValueError(f"This campaign requires exactly {DEFAULT_TRIALS} trials per method")
    for row in rows:
        validate_corpus_bounds(row)
    futures = {}
    for row in rows:
        saved = {method for (method,) in db.execute("SELECT method FROM results WHERE candidate_id=?", (row["id"],))}
        for method in METHODS:
            if method not in saved:
                future = executor.submit(isolation.run_method_isolated, row, method, config["trials"],
                                         result_seed(config["seed"], row, method))
                futures[future] = row, method
    errors = []
    for future in as_completed(futures):
        row, method = futures[future]
        try:
            result = future.result()
            if result.get("method") != method:
                raise ValueError("Returned method differs from scheduled task")
            error = store_result(db, row, result, config)
            if error:
                errors.append(error)
            print(json_text({"event": "method_finished", "id": row["id"], "method": method,
                "d_upper": result.get("d_upper"), "validation_error": error}), flush=True)
        except Exception as error:
            errors.append(f"{row['id']} {method}: {type(error).__name__}: {error}")
            print(json_text({"event": "method_uncommitted", "id": row["id"], "method": method,
                            "error": errors[-1]}), flush=True)
    return errors


def snapshot(db, config, output, state="running", include_audit=False, extra=None):
    output = Path(output)
    counts = Counter(dict(db.execute("SELECT outcome,count(*) FROM admissions GROUP BY outcome")))
    admitted = [read_json(raw) for (raw,) in db.execute(
        "SELECT payload FROM admissions WHERE outcome IN ('accepted_le14','accepted_15_30') ORDER BY candidate_index")]
    for bucket in ("le14", "15_30"):
        if counts["accepted_" + bucket] > config["target_" + bucket]:
            raise ValueError("Quota overshoot in saved admissions")
        write_jsonl(output / f"accepted_{bucket}.jsonl", [r for r in admitted if r["quota_outcome"] == "accepted_" + bucket])
    write_jsonl(output / "accepted.jsonl", admitted)
    write_jsonl(output / "surplus.jsonl", (read_json(raw) for (raw,) in db.execute(
        "SELECT payload FROM admissions WHERE outcome LIKE 'surplus_%' ORDER BY candidate_index")))
    trials, cpu, wall = db.execute("SELECT COALESCE(sum(actual_trials),0),COALESCE(sum(cpu_seconds),0),COALESCE(sum(wall_seconds),0) FROM results").fetchone()
    proposals = dict(db.execute("SELECT outcome,count(*) FROM attempts GROUP BY outcome"))
    stats = {"updated_utc": utc_now(), "state": state, "accepted": len(admitted),
        "accepted_le14": counts["accepted_le14"], "accepted_15_30": counts["accepted_15_30"],
        "target_le14": config["target_le14"], "target_15_30": config["target_15_30"],
        "target": config["target_le14"] + config["target_15_30"],
        "target_reached": all(counts["accepted_" + b] == config["target_" + b] for b in ("le14", "15_30")),
        "requested_trials_per_method": config["trials"],
        "requested_total_trials_per_code": config["trials"] * len(METHODS),
        "budget_convention": BUDGET_CONVENTION, "corpus_limits": {"n_max": MAX_N, "ell_max": MAX_DIMENSION, "m_max": MAX_DIMENSION},
        "exactly_certified_count": 0,
        "distinct_candidates_searched_or_pending": db.execute("SELECT count(*) FROM candidates").fetchone()[0],
        "excluded_prior_groups": db.execute("SELECT count(*) FROM excluded").fetchone()[0],
        "candidate_outcomes": dict(counts), "proposal_outcomes": proposals,
        "candidate_proposals": sum(proposals.values()), "saved_method_results": db.execute("SELECT count(*) FROM results").fetchone()[0],
        "validated_method_results": db.execute("SELECT count(*) FROM results WHERE validated=1").fetchone()[0],
        "method_errors": db.execute("SELECT count(*) FROM results WHERE validated=0").fetchone()[0],
        "recorded_actual_trials": trials, "algorithm_cpu_seconds": cpu, "sum_algorithm_wall_seconds": wall,
        "accepted_upper_histogram": dict(sorted(Counter(r["d_upper"] for r in admitted).items())),
        "accepted_length_strata": dict(Counter(r.get("length_stratum", "unspecified") for r in admitted)),
        "admission_order": "candidate_index, after all three complete validated budgets",
        "range_interpretation": "15..30 constrains the observed upper bound U, not the unknown true distance",
        "dedup_scope": DEDUP_SCOPE, "execution_policy": isolation.POLICY,
        "sampling_warning": "Quota and upper-bound filtering change the distribution; not the paper's unreleased dataset"}
    stats["next_sampling_phase"], stats["next_effective_sampling"] = sampling_phase(config,counts["accepted_le14"])
    if extra:
        stats.update(extra)
    write_json(output / "summary.json", stats)
    if include_audit:
        write_jsonl(output / "candidates.jsonl", (read_json(raw) for (raw,) in db.execute("SELECT payload FROM candidates ORDER BY candidate_index")))
        write_jsonl(output / "methods.jsonl", (dict(read_json(raw), parent_validation_passed=bool(valid), parent_validation_error=error)
            for raw, valid, error in db.execute("SELECT payload,validated,validation_error FROM results ORDER BY candidate_id,method")))
        write_jsonl(output / "attempts.jsonl", (dict(attempt_index=i,outcome=o,candidate_id=c,reason=r)
            for i,o,c,r in db.execute("SELECT * FROM attempts ORDER BY attempt_index")))
        write_jsonl(output / "above_30.jsonl", (read_json(raw) for (raw,) in db.execute(
            "SELECT payload FROM admissions WHERE outcome='above_30' ORDER BY candidate_index")))
    return stats


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--exclude", type=Path, action="append", default=[])
    for name, default in (("target-le14",5000),("target-15-30",15000),("trials",DEFAULT_TRIALS),
            ("workers",8),("batch-size",0),("seed",20261029),("max-candidates",200000),
            ("max-attempts",20000000),("n-min",18),("n-max",360),("ell-min",3),
            ("ell-max",30),("m-min",3),("m-max",30),("terms-a",3),("terms-b",3)):
        parser.add_argument("--"+name, type=int, default=default)
    parser.add_argument("--high-phase-n-min",type=int,default=145,
                        help="After low quota fills, raise sampler n-min; 0 disables this phase")
    parser.add_argument("--wall-seconds", type=float, default=82800)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--export-only", action="store_true")
    args = parser.parse_args(argv)
    if args.trials != DEFAULT_TRIALS:
        parser.error(f"This campaign requires exactly --trials {DEFAULT_TRIALS} for each of the three methods")
    if min(args.target_le14,args.target_15_30,args.seed,args.batch_size) < 0 or args.target_le14+args.target_15_30 < 1:
        parser.error("Quotas/seed/batch-size must be nonnegative and total target positive")
    if min(args.workers,args.max_candidates,args.max_attempts) < 1:
        parser.error("Workers and search caps must be positive")
    if min(args.max_candidates,args.max_attempts) < args.target_le14+args.target_15_30:
        parser.error("Search caps must be at least the combined label target")
    if not math.isfinite(args.wall_seconds) or args.wall_seconds <= 0:
        parser.error("wall-seconds must be positive and finite")
    if args.high_phase_n_min < 0 or args.high_phase_n_min > args.n_max:
        parser.error("high-phase-n-min must be 0 or at most n-max")
    if args.dry_run and args.export_only:
        parser.error("dry-run and export-only are mutually exclusive")
    try:
        validate_sampling_bounds({name: getattr(args, name) for name in (
            "ell_min", "ell_max", "m_min", "m_max", "n_min", "n_max")})
    except ValueError as error:
        parser.error(str(error))
    return args


def main(argv=None):
    args = parse_args(argv)
    sampling = {name:getattr(args,name) for name in ("ell_min","ell_max","m_min","m_max","n_min","n_max","terms_a","terms_b")}
    candidate_for_index(0,args.seed,**sampling)
    if args.high_phase_n_min:
        candidate_for_index(0,args.seed,**dict(sampling,n_min=max(sampling["n_min"],args.high_phase_n_min)))
    if args.dry_run:
        print(json_text({"mode":"dry_run_no_distance_search","quotas":{"le14":args.target_le14,"15_30":args.target_15_30},
            "sampling":sampling,"trials_per_method":args.trials,"total_trials_per_code":args.trials * len(METHODS),
            "budget_convention":BUDGET_CONVENTION,"methods":METHODS,
            "effective_method_params":{m:backend.method_params(m,args.trials) for m in METHODS},
            "example":candidate_for_index(0,args.seed,**sampling)}))
        return 0
    output = args.output_dir.expanduser().resolve()
    if args.export_only and not (output / "state.sqlite3").exists():
        raise ValueError("export-only requires an existing journal")
    output.mkdir(parents=True,exist_ok=True)
    started = time.monotonic()
    with RunLock(output / ".run.lock"):
        keys, exclusions = initialize_exclusions(output,args.exclude)
        config = {"schema_version":2,"target_le14":args.target_le14,"target_15_30":args.target_15_30,
            "trials":args.trials,"budget_convention":BUDGET_CONVENTION,
            "corpus_limits":{"n_max":MAX_N,"ell_max":MAX_DIMENSION,"m_max":MAX_DIMENSION},"seed":args.seed,"sampling":sampling,"sampler_version":SAMPLER_VERSION,
            "max_candidates":args.max_candidates,"max_attempts":args.max_attempts,"methods":list(METHODS),
            "batch_size":args.batch_size or args.workers,"high_phase_n_min":args.high_phase_n_min,
            "phase_policy":"At a new batch only: original range until low quota complete, then raise n-min; preserve axis/grid sampler",
            "exclusion_keys_sha256":exclusions["keys_sha256"],"exclusion_manifest_sha256":sha256_file(output/"exclusions/manifest.json"),
            "source":backend.backend_manifest(),"execution_policy":isolation.POLICY,
            "effective_method_params":{m:backend.method_params(m,args.trials) for m in METHODS},
            "source_defaults_note":"source records the unchanged backend's defaults; effective_method_params and trials are the enforced campaign settings",
            "source_hashes":{name:sha256_file(HERE/name) for name in DEPENDENCIES}}
        db = open_database(output/"state.sqlite3",config,keys)
        state, errors, audit_ok = "interrupted", [], False
        previous_audit = os.environ.get(isolation.AUDIT_ENV)
        audit_path = output/f"execution-isolated-{time.time_ns()}-{os.getpid()}.jsonl"
        os.environ[isolation.AUDIT_ENV] = str(audit_path)
        try:
            manifest = {"created_utc":utc_now(),"config":config,"exclusions":exclusions,
                "effective_method_params":config["effective_method_params"],
                "source_defaults_note":config["source_defaults_note"],
                "label_rule":f"Three complete {config['trials']}-trial methods, minimum witnessed upper, separate disjoint quotas",
                "resume_rule":"Reuse committed methods; rerun only interrupted uncommitted calls",
                "wall_stop_rule":"Stop proposing new batches after wall-seconds; an active batch finishes",
                "surplus_rule":"Save completed valid labels beyond a full quota without counting them toward target"}
            if not (output/"manifest.json").exists():
                write_json(output/"manifest.json",manifest)
            elif read_json((output/"manifest.json").read_bytes())["config"] != config:
                raise ValueError("Manifest and journal configuration disagree")
            print(json_text({"event":"auditing_saved_journal"}),flush=True)
            audit_journal(db,config)
            audit_ok = True
            finalize_admissions(db,config)
            stats = snapshot(db,config,output)
            if args.export_only or stats["target_reached"]:
                state = "complete" if stats["target_reached"] else "exported_incomplete"
                return 0
            isolation._audit({"event":"launcher_started","workers":args.workers,"execution_overlay":isolation.overlay_manifest(),
                "driver":"generate_bb_distance_10000_trials.py","source_hashes":config["source_hashes"]})
            with ProcessPoolExecutor(max_workers=args.workers,mp_context=multiprocessing.get_context("spawn"),
                                     initializer=isolation.init_outer_worker) as pool:
                while not stats["target_reached"]:
                    if time.monotonic()-started >= args.wall_seconds:
                        state = "wall_budget_reached"
                        return 2
                    rows = fill_batch(db,config,config["batch_size"])
                    if not rows:
                        state = "candidate_limit_reached"
                        return 2
                    errors = execute_batch(db,rows,config,pool)
                    if errors:
                        state = "method_error"
                        return 1
                    finalize_admissions(db,config)
                    stats = snapshot(db,config,output)
                    print(json_text({"event":"batch_finished","accepted_le14":stats["accepted_le14"],
                        "accepted_15_30":stats["accepted_15_30"],"searched":stats["distinct_candidates_searched_or_pending"]}),flush=True)
            state = "complete"
            return 0
        except BaseException as error:
            errors.append(f"{type(error).__name__}: {error}")
            if not audit_ok:
                state = "audit_failed"
            raise
        finally:
            try:
                extra = {"errors":errors,"invocation_elapsed_seconds":time.monotonic()-started,
                         "execution_audit_path":str(audit_path)}
                if audit_ok:
                    snapshot(db,config,output,state,include_audit=True,extra=extra)
                else:
                    write_json(output/"summary.json",{"state":"audit_failed",**extra,
                        "dataset_exports":"Previous exports left untouched; journal validation failed"})
            finally:
                db.close()
                if previous_audit is None:
                    os.environ.pop(isolation.AUDIT_ENV,None)
                else:
                    os.environ[isolation.AUDIT_ENV] = previous_audit


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(130)
