#!/usr/bin/env python3
"""Fixed-budget, witness-checked adapters for the three paper heuristics.

The parent process can import this file using only Python's standard library.
``init_worker`` imports the pinned codeDistance implementation and dependencies;
it performs NO warm-up searches. ``run_method`` performs one full method call.
Only CSS BB codes are supported. There is no SAT/MILP/enumeration/RIS fallback.
"""
from __future__ import annotations

import contextlib
import hashlib
import importlib.metadata
import io
import json
import numbers
import os
import sys
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path

from bb_code_algebra import (build_css_matrices, commutes, gf2_rank,
                             popcount, validate_witness)


SOURCE_COMMIT = "a4afe9c09bbf5790da9ecc05b65c5b62343979ad"
VENDOR_DIR = Path(__file__).resolve().parent / "vendor" / "codedistance-a4afe9c"
METHODS = ("BP-OSD", "QDistRnd", "QDistEvol")
METHOD_IDS = {"BP-OSD": "decoderDist", "QDistRnd": "QDistRndMW",
              "QDistEvol": "QDistEvol"}
DEFAULT_TRIALS = 1000
THREAD_VARIABLES = ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
                    "NUMBA_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "BLIS_NUM_THREADS")
SEED_LIMITATION = (
    "Pinned codeDistance does not forward its seed to decoderDist, and randomLO "
    "calls NonZeroVecRand without a seed. BP-OSD is not bitwise reproducible. "
    "No random-generator or search-algorithm patches are applied."
)
_WORKER = {}


def _utc_now():
    return datetime.now(timezone.utc).isoformat()


def _sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def method_params(method, trials=DEFAULT_TRIALS):
    if method not in METHODS:
        raise ValueError(f"Unknown method: {method!r}; expected one of {METHODS}")
    if type(trials) is not int or trials < 1:
        raise ValueError("trials must be a positive integer")
    params = {"iterCount": trials, "LOCheck": 0, "nThreads": 1, "maxErr": -1}
    if method in ("QDistRnd", "QDistEvol"):
        params.update({"GF4blockRep": 2, "regroupPerm": 1, "HL": False,
                       "genCount": 1 if method == "QDistRnd" else min(100, trials),
                       "offspring": 10, "pMut": 2.0, "sMut": 1.0,
                       "tabuLength": 0, "swapPivot": 1, "swapBlockorder": 0,
                       "pMutScale": 50})
    else:
        params.update({"decoder": "bposd", "addStabs": 0, "permuteDEM": 1,
                       "randomLO": 1, "bp_method": "product_sum",
                       "bp_max_iter": 100, "bp_schedule": "parallel",
                       "osd_method": "OSD_CS", "osd_order": 1})
    return params


def backend_manifest():
    """Verify the frozen source hashes without importing numerical packages."""
    source = json.loads((VENDOR_DIR / "SOURCE.json").read_text())
    if source.get("commit") != SOURCE_COMMIT:
        raise ValueError("Unexpected vendor commit")
    actual = {}
    for name, metadata in source["files"].items():
        digest = _sha256(VENDOR_DIR / "codedistance" / name)
        if digest != metadata["runtime_sha256"]:
            raise ValueError(f"Pinned vendor hash mismatch: {name}")
        actual[name] = digest
    return {
        "source": source,
        "verified_runtime_sha256": actual,
        "adapter_sha256": _sha256(__file__),
        "construction_helpers_sha256": _sha256(Path(__file__).with_name("bb_code_algebra.py")),
        "method_ids": METHOD_IDS,
        "default_trials_per_method": DEFAULT_TRIALS,
        "default_params": {m: method_params(m) for m in METHODS},
        "search_scope": "CSS Z sector after explicitly checking d_X=d_Z isometry",
        "trial_definition": "upstream returned T; QDistEvol generations partition the total",
        "warmup_searches": 0,
        "early_stop_at_distance_threshold": False,
        "seed_limitation": SEED_LIMITATION,
        "label_kind": "verified_heuristic_upper_bound",
        "exact_distance_certification": False,
        "paper_configuration_note": (
            "Paper names these three methods but has not supplied its complete "
            "label-generation configuration; these explicit pinned-backend settings "
            "must not be described as an exact reconstruction of missing settings."
        ),
    }


def init_worker():
    """Import once per process. JIT, if any, happens inside the real first task."""
    if _WORKER:
        return _WORKER["metadata"]
    for key in THREAD_VARIABLES:
        os.environ[key] = "1"
    backend_manifest()
    sys.path.insert(0, str(VENDOR_DIR))
    started, cpu_started = time.perf_counter(), time.process_time()
    import numpy as np
    import codedistance.distance as cd
    if Path(cd.__file__).resolve() != (VENDOR_DIR / "codedistance" / "distance.py").resolve():
        raise RuntimeError("Imported codeDistance from an unexpected location")
    versions = {}
    for package in ("numpy", "numba", "llvmlite", "scipy", "ldpc", "stim", "sinter",
                    "pymatching"):
        try:
            versions[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            versions[package] = None
    metadata = {
        "pid": os.getpid(), "python": sys.version, "executable": sys.executable,
        "versions": versions, "codedistance_import_file": str(cd.__file__),
        "import_wall_seconds": time.perf_counter() - started,
        "import_cpu_seconds": time.process_time() - cpu_started,
        "thread_environment": {key: os.environ[key] for key in THREAD_VARIABLES},
        "warmup_searches": 0,
    }
    _WORKER.update(np=np, cd=cd, metadata=metadata)
    return metadata


def _permute_bits(vector, permutation):
    result = 0
    while vector:
        low = vector & -vector
        result |= 1 << permutation[low.bit_length() - 1]
        vector ^= low
    return result


def prepare_code(row):
    """Binary construction/rank and sector identity checks only; no distance search."""
    ell, m = row["ell"], row["m"]
    if type(ell) is not int or type(m) is not int or min(ell, m) < 1:
        raise ValueError("ell and m must be positive integers")
    if row.get("C") or row.get("D") or str(row.get("family", "")).upper() == "PBB":
        raise ValueError("This dataset supports ordinary CSS BB codes only")
    n, block = 2 * ell * m, ell * m
    if row.get("n", n) != n:
        raise ValueError("Candidate n is inconsistent with ell,m")
    for name in ("A", "B"):
        support = row[name]
        if not isinstance(support, (tuple, list)) or not support:
            raise ValueError(f"{name} must contain at least one monomial")
        for pair in support:
            if (not isinstance(pair, (tuple, list)) or len(pair) != 2 or
                    any(type(x) is not int for x in pair)):
                raise ValueError(f"{name} exponent pairs must contain exactly two integers")
    hx, hz = build_css_matrices(ell, m, row["A"], row["B"])
    if not commutes(hx, hz):
        raise ValueError("CSS check matrices do not commute")
    rank_x, rank_z = gf2_rank(hx), gf2_rank(hz)
    k = n - rank_x - rank_z
    if k <= 0 or row.get("k", k) != k:
        raise ValueError("Candidate k is nonpositive or inconsistent with GF(2) rank")
    # On a bivariate bicycle lattice, inversion plus block exchange sends both
    # stabilizer and logical spaces to the opposite sector, preserving weight.
    inverse = [((-u) % ell) * m + (-v) % m
               for u in range(ell) for v in range(m)]
    columns = [(1 - b) * block + inverse[g] for b in (0, 1) for g in range(block)]
    if len(set(columns)) != n or any(columns[columns[i]] != i for i in range(n)):
        raise ValueError("Sector exchange is not an involutive qubit permutation")
    for g in range(block):
        if (_permute_bits(hx[g], columns) != hz[inverse[g]] or
                _permute_bits(hz[g], columns) != hx[inverse[g]]):
            raise ValueError("X/Z distance-preserving sector identity failed")
    return {
        "n": n, "k": k, "hx": hx, "hz": hz,
        "structure": {
            "family": "CSS_BB", "commutation_checked": True,
            "rank_hx": rank_x, "rank_hz": rank_z,
            "search_component": "Z", "d_x_equals_d_z_verified": True,
            "sector_exchange_column_map": "(block,u,v) -> (1-block,-u mod ell,-v mod m)",
            "sector_exchange_row_map": "(u,v) -> (-u mod ell,-v mod m)",
            "verified_identities": ["H_X Q = P H_Z", "H_Z Q = P H_X"],
            "verified_row_equalities": 2 * block,
        },
    }


def _exact_int(value, name):
    if isinstance(value, bool) or not isinstance(value, numbers.Real):
        raise ValueError(f"{name} must be an integer")
    integer = int(value)
    if integer != value:
        raise ValueError(f"{name} must be an integer")
    return integer


def _json_safe(value):
    if hasattr(value, "tolist"):
        return _json_safe(value.tolist())
    if isinstance(value, dict):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    return value


def verify_result(prepared, raw, trials):
    """Independently check the returned logical operator and complete trial count."""
    returned_trials = _exact_int(raw.get("T"), "Returned trial count")
    if returned_trials != trials:
        raise ValueError(f"Incomplete trial budget: returned {returned_trials}, required {trials}")
    distance = _exact_int(raw.get("d"), "Returned distance")
    bits = _json_safe(raw.get("L", []))
    if not isinstance(bits, (tuple, list)) or len(bits) != prepared["n"]:
        raise ValueError("Returned witness must be a flat vector of length n")
    if any(isinstance(bit, (list, tuple, dict)) or bit not in (0, 1) for bit in bits):
        raise ValueError("Returned witness must be binary")
    ones = [index for index, bit in enumerate(bits) if bit == 1]
    vector = sum(1 << index for index in ones)
    if vector == 0:
        raise ValueError("Zero vector is not a logical witness")
    if not validate_witness(vector, "Z", prepared["hx"], prepared["hz"], prepared["n"]):
        raise ValueError("Witness has nonzero syndrome or belongs to the Z stabilizer rowspace")
    weight = popcount(vector)
    return {
        "d_upper": weight,
        "witness": {"representation": "Z support in original grid qubit order", "Z": ones},
        "reported_distance_matches_weight": distance == weight,
        "validation": {"zero_syndrome": True, "nonstabilizer": True,
                       "physical_weight_recomputed": True, "complete_trial_budget": True},
    }


class _Capture(io.TextIOBase):
    def __init__(self, limit=6000):
        self.limit, self.retained, self.characters, self.parts = limit, 0, 0, []

    def write(self, value):
        value = str(value)
        self.characters += len(value)
        keep = value[:max(0, self.limit - self.retained)]
        if keep:
            self.parts.append(keep)
        self.retained += len(keep)
        return len(value)

    def flush(self):
        pass

    def result(self):
        return {"text_prefix": "".join(self.parts), "total_characters": self.characters,
                "truncated": self.characters > self.retained}


def run_method(row, method, trials=DEFAULT_TRIALS, seed=0):
    """One full call; failure is recorded and never replaced by another algorithm."""
    params = method_params(method, trials)
    started, cpu_started = time.perf_counter(), time.process_time()
    result = {
        "id": row["id"], "method": method, "backend_method": METHOD_IDS[method],
        "requested_trials": trials, "returned_trials": None, "seed_argument": seed,
        "source_commit": SOURCE_COMMIT, "pid": os.getpid(), "started_utc": _utc_now(),
        "status": "failed", "budget_completed": False, "valid_upper_bound": False,
        "d_upper": None, "witness": None, "returned_distance": None,
        "returned_witness_bits": None, "reported_distance_matches_weight": None,
        "requested_params": dict(params), "effective_params": None,
        "algorithm_wall_seconds": None, "algorithm_cpu_seconds": None,
        "ell": row["ell"], "m": row["m"], "n": 2 * row["ell"] * row["m"],
    }
    capture = _Capture()
    try:
        if not _WORKER:
            init_worker()
        result["worker_metadata"] = _WORKER["metadata"]
        np, cd = _WORKER["np"], _WORKER["cd"]
        prep_start, prep_cpu = time.perf_counter(), time.process_time()
        prepared = prepare_code(row)
        hx = np.asarray([[(r >> i) & 1 for i in range(prepared["n"])]
                         for r in prepared["hx"]], dtype=np.int8)
        hz = np.asarray([[(r >> i) & 1 for i in range(prepared["n"])]
                         for r in prepared["hz"]], dtype=np.int8)
        result.update(k=prepared["k"], structure=prepared["structure"],
                      preparation_wall_seconds=time.perf_counter() - prep_start,
                      preparation_cpu_seconds=time.process_time() - prep_cpu)
        algorithm_start, algorithm_cpu = time.perf_counter(), time.process_time()
        try:
            with contextlib.redirect_stdout(capture), contextlib.redirect_stderr(capture):
                raw = cd.CSScodeDistance(hx, hz, method=METHOD_IDS[method], params=params,
                                         component="Z", seed=seed)
        finally:
            result["algorithm_wall_seconds"] = time.perf_counter() - algorithm_start
            result["algorithm_cpu_seconds"] = time.process_time() - algorithm_cpu
            result["effective_params"] = _json_safe(params)
        # Preserve raw evidence even when a returned witness or budget is invalid.
        result["returned_trials"] = _json_safe(raw.get("T"))
        result["returned_distance"] = _json_safe(raw.get("d"))
        result["returned_witness_bits"] = _json_safe(raw.get("L", []))
        result["R"] = _json_safe(raw.get("R"))
        result["budget_completed"] = (
            _exact_int(result["returned_trials"], "Returned trial count") == trials)
        progress = str(raw.get("progress", ""))
        result["progress"] = {"text_prefix": progress[:12000],
                              "total_characters": len(progress),
                              "sha256": hashlib.sha256(progress.encode()).hexdigest(),
                              "truncated": len(progress) > 12000}
        verify_start, verify_cpu = time.perf_counter(), time.process_time()
        result.update(verify_result(prepared, raw, trials))
        result.update(status="ok", valid_upper_bound=True,
                      label_kind="verified_heuristic_upper_bound", is_exact=False,
                      verification_wall_seconds=time.perf_counter() - verify_start,
                      verification_cpu_seconds=time.process_time() - verify_cpu)
    except Exception as error:
        result["error"] = f"{type(error).__name__}: {error}"
        result["traceback"] = traceback.format_exc(limit=10)
    result["captured_output"] = capture.result()
    result["task_wall_seconds"] = time.perf_counter() - started
    result["task_cpu_seconds"] = time.process_time() - cpu_started
    result["finished_utc"] = _utc_now()
    return result
