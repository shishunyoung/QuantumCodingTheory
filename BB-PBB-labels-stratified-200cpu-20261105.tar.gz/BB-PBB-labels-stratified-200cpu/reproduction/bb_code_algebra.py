#!/usr/bin/env python3
"""Standard-library BB code algebra and logical-witness validation.

These helpers construct matrices, compute GF(2) ranks, normalize supported
symmetries, and check a supplied logical witness.  They perform no distance
search.  Function bodies preserve the established grid and group_id conventions
used by the reproduction's existing data and training code.
"""
from __future__ import annotations

import hashlib
import json


popcount = int.bit_count if hasattr(int, "bit_count") else lambda x: bin(x).count("1")



def row_basis(rows):
    """GF(2)行空间基，键为主元bit位置；每行用非负整数表示。"""
    basis = {}
    for original in rows:
        value = original
        while value:
            pivot = value.bit_length() - 1
            if pivot in basis:
                value ^= basis[pivot]
            else:
                basis[pivot] = value
                break
    return basis


def gf2_rank(rows):
    return len(row_basis(rows))


def in_rowspan(vector, basis):
    while vector:
        pivot = vector.bit_length() - 1
        if pivot not in basis:
            return False
        vector ^= basis[pivot]
    return True


def transpose(rows, n_columns):
    result = [0] * n_columns
    for i, row in enumerate(rows):
        while row:
            low_bit = row & -row
            result[low_bit.bit_length() - 1] |= 1 << i
            row ^= low_bit
    return result


def validated_support(support, ell, m):
    result = tuple(sorted((int(a), int(b)) for a, b in support))
    if not result or len(set(result)) != len(result):
        raise ValueError("多项式支持必须非空且不能有重复项")
    if any(a < 0 or a >= ell or b < 0 or b >= m for a, b in result):
        raise ValueError("指数超出Z_ell×Z_m网格")
    return result


def polynomial_matrix(ell, m, support):
    """第(u,v)行的1位于(u+a,v+b)，所有坐标分别取模。"""
    rows = []
    for u in range(ell):
        for v in range(m):
            row = 0
            for a, b in support:
                column = ((u + a) % ell) * m + (v + b) % m
                row ^= 1 << column
            rows.append(row)
    return rows


def build_css_matrices(ell, m, A, B):
    """返回int位集行：Hx=[A B]，Hz=[B^T A^T]。"""
    if ell < 1 or m < 1:
        raise ValueError("ell,m必须为正数")
    A = validated_support(A, ell, m)
    B = validated_support(B, ell, m)
    block_size = ell * m
    a_rows = polynomial_matrix(ell, m, A)
    b_rows = polynomial_matrix(ell, m, B)
    at_rows = transpose(a_rows, block_size)
    bt_rows = transpose(b_rows, block_size)
    hx_rows = [a | (b << block_size) for a, b in zip(a_rows, b_rows)]
    hz_rows = [b | (a << block_size) for b, a in zip(bt_rows, at_rows)]
    return hx_rows, hz_rows


def commutes(hx_rows, hz_rows):
    """直接计算Hx Hz^T的每个二进制内积。"""
    return all(popcount(x & z) % 2 == 0 for x in hx_rows for z in hz_rows)


def canonical_support(support, ell, m):
    support = validated_support(support, ell, m)
    return min(tuple(sorted(((a - da) % ell, (b - db) % m) for a, b in support))
               for da, db in support)


def canonical_group(ell, m, A, B):
    """group_id覆盖独立循环平移、A/B交换、坐标轴交换生成的等价类。"""
    variants = []
    for axis_swap in (False, True):
        if axis_swap:
            dims = (m, ell)
            a_support = [(b, a) for a, b in A]
            b_support = [(b, a) for a, b in B]
        else:
            dims = (ell, m)
            a_support, b_support = A, B
        a_support = canonical_support(a_support, *dims)
        b_support = canonical_support(b_support, *dims)
        variants.extend([
            (dims[0], dims[1], a_support, b_support),
            (dims[0], dims[1], b_support, a_support),
        ])
    canon_ell, canon_m, canon_a, canon_b = min(variants)
    spec = {"ell": canon_ell, "m": canon_m, "A": canon_a, "B": canon_b}
    serial = json.dumps(spec, sort_keys=True, separators=(",", ":"))
    return "bbcss-" + hashlib.sha256(serial.encode("utf-8")).hexdigest(), spec


def validate_witness(witness, kind, hx_rows, hz_rows, n):
    """独立复查综合与非平凡性；后者用秩增量而非搜索时的span判断。"""
    if kind not in ("X", "Z") or witness <= 0 or witness >> n:
        return False
    checks, stabilizers = (hz_rows, hx_rows) if kind == "X" else (hx_rows, hz_rows)
    if any(popcount(row & witness) % 2 for row in checks):
        return False
    return gf2_rank(list(stabilizers) + [witness]) == gf2_rank(stabilizers) + 1
