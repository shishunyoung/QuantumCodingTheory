#!/usr/bin/env python3
"""Generate a resumable PBB corpus with three fully witnessed upper bounds.

The default pilot selects 100 unique, genuinely non-CSS codes and performs
10,000 complete trials of EACH method for EACH selected code.  A label is
published only after all three full-budget witnesses have passed an independent
parent-side check.  No numerical package is imported by the coordinator.
"""
from __future__ import annotations

import argparse
from collections import Counter
from concurrent.futures import ProcessPoolExecutor, wait, FIRST_COMPLETED
from contextlib import contextmanager
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import multiprocessing
import os
from pathlib import Path
import sqlite3
import sys
import time

import pbb_distance_backend as backend
from pbb_code_algebra import prepare_code
from pbb_distance_candidates import candidate_for_index, canonical_key, SAMPLER_VERSION, DEDUP_SCOPE


HERE = Path(__file__).resolve().parent
METHODS = backend.METHODS
SCHEMA = "pbb_full_pauli_dataset_v1"
DEFAULT_SEED = 2026103102
SOURCE_FILES = (
    "generate_pbb_distance_dataset.py", "pbb_distance_candidates.py",
    "pbb_code_algebra.py", "pbb_distance_backend.py", "run_pbb_distance_isolated.py",
    "bb_distance_candidates.py", "bb_code_algebra.py", "bb_distance_backend.py",
)


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def json_text(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False,
                      separators=(",", ":"))


def _unique_object(pairs):
    result = {}
    for name, value in pairs:
        if name in result:
            raise ValueError(f"Duplicate JSON key: {name}")
        result[name] = value
    return result


def read_json(value):
    def nonfinite(value):
        raise ValueError(f"Nonfinite JSON number: {value}")
    return json.loads(value, object_pairs_hook=_unique_object, parse_constant=nonfinite)


def digest_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha256_file(path):
    return digest_bytes(Path(path).read_bytes())


def atomic_bytes(path, data):
    path = Path(path)
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("wb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def write_json(path, value):
    atomic_bytes(path, (json_text(value) + "\n").encode())


def write_jsonl(path, rows):
    atomic_bytes(path, "".join(json_text(row) + "\n" for row in rows).encode())


@contextmanager
def run_lock(output):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    with (output / ".run.lock").open("a+") as stream:
        try:
            fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise RuntimeError("This PBB run is already locked by another coordinator") from error
        try:
            yield
        finally:
            fcntl.flock(stream.fileno(), fcntl.LOCK_UN)


def default_workers():
    allocated = os.environ.get("SLURM_CPUS_PER_TASK")
    if allocated:
        return max(1, int(allocated))
    try:
        return max(1, len(os.sched_getaffinity(0)))
    except AttributeError:
        return max(1, os.cpu_count() or 1)


def sampling_config(args):
    settings = {name: getattr(args, name) for name in
                ("ell_min", "ell_max", "m_min", "m_max", "n_min", "n_max", "terms_a", "terms_b")}
    for prefix, cap in (("ell", 30), ("m", 30), ("n", 360)):
        lo, hi = settings[prefix + "_min"], settings[prefix + "_max"]
        if not 1 <= lo <= hi <= cap:
            raise ValueError(f"Require 1 <= {prefix}_min <= {prefix}_max <= {cap}")
    if min(settings["terms_a"], settings["terms_b"]) < 2:
        raise ValueError("A and B must each contain at least two terms")
    return settings


def scientific_config(args):
    return {
        "schema": SCHEMA, "target_codes": args.target, "trials_per_method": args.trials,
        "methods": list(METHODS), "seed": args.seed, "sampling": sampling_config(args),
        "sampler_version": SAMPLER_VERSION, "dedup_scope": DEDUP_SCOPE,
        "source_sha256": {name: sha256_file(HERE / name) for name in SOURCE_FILES},
        "backend": backend.backend_manifest(),
        "budget_convention": "full requested trials per method; three methods per code",
        "label_kind": "verified_heuristic_upper_bound", "is_exact": False,
        "distance_filter": None,
    }


def _get_metadata(db, key, default=None):
    row = db.execute("SELECT value FROM metadata WHERE key=?", (key,)).fetchone()
    return default if row is None else read_json(row[0])


def _put_metadata(db, key, value):
    db.execute("INSERT OR REPLACE INTO metadata VALUES (?,?)", (key, json_text(value)))


def open_database(path, config):
    db = sqlite3.connect(path)
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("PRAGMA synchronous=FULL")
    db.execute("PRAGMA foreign_keys=ON")
    db.executescript("""
      CREATE TABLE IF NOT EXISTS metadata(key TEXT PRIMARY KEY,value TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS candidates(
        id TEXT PRIMARY KEY, candidate_index INTEGER UNIQUE NOT NULL,
        canonical_key TEXT UNIQUE NOT NULL, payload TEXT NOT NULL, sha256 TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS attempts(
        candidate_index INTEGER PRIMARY KEY, outcome TEXT NOT NULL, reason TEXT);
      CREATE TABLE IF NOT EXISTS results(
        candidate_id TEXT NOT NULL REFERENCES candidates(id), method TEXT NOT NULL,
        payload TEXT NOT NULL, sha256 TEXT NOT NULL,
        PRIMARY KEY(candidate_id,method));
      CREATE TABLE IF NOT EXISTS errors(
        sequence INTEGER PRIMARY KEY AUTOINCREMENT,candidate_id TEXT NOT NULL,
        method TEXT NOT NULL, recorded_utc TEXT NOT NULL,payload TEXT NOT NULL);
    """)
    existing = _get_metadata(db, "config")
    if existing is not None and existing != config:
        db.close()
        raise ValueError("Frozen PBB scientific configuration or source changed; use a new output directory")
    with db:
        if existing is None:
            _put_metadata(db, "config", config)
            _put_metadata(db, "created_utc", utc_now())
            _put_metadata(db, "next_candidate_index", 0)
            _put_metadata(db, "population_complete", False)
    return db


def validate_candidate(row, config):
    sampling = config["sampling"]
    if row.get("family") != "PBB":
        raise ValueError("Candidate family must be PBB")
    for field in ("ell", "m", "n"):
        value = row.get(field)
        if type(value) is not int or not sampling[field + "_min"] <= value <= sampling[field + "_max"]:
            raise ValueError(f"Candidate {field} is outside frozen corpus bounds")
    if row["n"] != 2 * row["ell"] * row["m"]:
        raise ValueError("Candidate n is not 2*ell*m")
    prepared = prepare_code(row)
    if prepared["k"] <= 0 or not prepared["structure"]["non_css"]:
        raise ValueError("Candidate must encode logical qubits and have a non-CSS rowspace")
    if row.get("k") != prepared["k"]:
        raise ValueError("Candidate k disagrees with independent GF(2) rank")
    key = canonical_key(row)
    if row.get("canonical_key") != key:
        raise ValueError("Candidate canonical key is inconsistent")
    return key


def load_candidates(db, config, replay=True):
    rows, seen = [], set()
    for identifier, index, key, payload, digest in db.execute(
            "SELECT id,candidate_index,canonical_key,payload,sha256 FROM candidates ORDER BY candidate_index"):
        if digest_bytes(payload.encode()) != digest:
            raise ValueError("Candidate payload hash mismatch")
        row = read_json(payload)
        if row.get("id") != identifier or row.get("candidate_index") != index:
            raise ValueError("Candidate journal identity mismatch")
        if validate_candidate(row, config) != key or key in seen:
            raise ValueError("Candidate structural duplicate/key mismatch")
        if replay:
            proposal = candidate_for_index(index, config["seed"], **config["sampling"])
            if proposal["status"] != "ok" or proposal["candidate"] != row:
                raise ValueError("Frozen candidate differs from deterministic sampler replay")
        rows.append(row)
        seen.add(key)
    if len(rows) > config["target_codes"]:
        raise ValueError("Frozen population exceeds target")
    if _get_metadata(db, "population_complete") and len(rows) != config["target_codes"]:
        raise ValueError("Complete population journal has wrong candidate count")
    return rows


def prepare_population(db, output, config, max_candidates):
    rows = load_candidates(db, config)
    seen = {row["canonical_key"] for row in rows}
    index = _get_metadata(db, "next_candidate_index", 0)
    count = db.execute("SELECT COUNT(*) FROM attempts").fetchone()[0]
    maximum = db.execute("SELECT MAX(candidate_index) FROM attempts").fetchone()[0]
    if count != index or (index and maximum != index - 1):
        raise ValueError("Candidate attempt journal has missing or inconsistent indices")
    while len(rows) < config["target_codes"] and index < max_candidates:
        proposal = candidate_for_index(index, config["seed"], **config["sampling"])
        row = proposal["candidate"]
        outcome, reason = proposal["status"], proposal.get("reason")
        if outcome == "ok":
            key = validate_candidate(row, config)
            if key in seen:
                outcome, reason = "duplicate", "supported_PBB_canonical_symmetry"
            else:
                payload = json_text(row)
                outcome = "accepted"
        with db:
            db.execute("INSERT INTO attempts VALUES (?,?,?)", (index, outcome, reason))
            if outcome == "accepted":
                db.execute("INSERT INTO candidates VALUES (?,?,?,?,?)",
                           (row["id"], index, key, payload, digest_bytes(payload.encode())))
            _put_metadata(db, "next_candidate_index", index + 1)
        if outcome == "accepted":
            rows.append(row)
            seen.add(key)
        index += 1
        if index % 1000 == 0 or len(rows) == config["target_codes"]:
            print(json_text({"event": "population_progress", "proposals": index,
                             "selected": len(rows), "target": config["target_codes"]}), flush=True)
    if len(rows) != config["target_codes"]:
        raise RuntimeError(f"Only {len(rows)} / {config['target_codes']} candidates selected after {index} proposals; raise --max-candidates to resume")
    with db:
        _put_metadata(db, "population_complete", True)
    output = Path(output)
    write_jsonl(output / "candidates.jsonl", rows)
    return rows


def result_seed(seed, identifier, method):
    material = json_text({"seed": seed, "id": identifier, "method": method})
    return int(hashlib.sha256(material.encode()).hexdigest()[:8], 16)


def load_results(db, candidates, config, revalidate=False):
    population = {row["id"]: row for row in candidates}
    result = {}
    for identifier, method, payload, digest in db.execute(
            "SELECT candidate_id,method,payload,sha256 FROM results"):
        if digest_bytes(payload.encode()) != digest:
            raise ValueError("Method-result payload hash mismatch")
        row = read_json(payload)
        if identifier not in population or method not in METHODS:
            raise ValueError("Unknown candidate or method in result journal")
        if row.get("id") != identifier or row.get("method") != method or row.get("validated") is not True:
            raise ValueError("Result identity/validation flag disagrees with journal")
        if row.get("seed_argument") != result_seed(config["seed"], identifier, method):
            raise ValueError("Result seed differs from frozen deterministic seed argument")
        if revalidate:
            checked = backend.validate_method_result(population[identifier], method, row,
                                                      config["trials_per_method"])
            if not checked["validated"]:
                raise ValueError(f"Stored result fails independent validation: {checked['validation_error']}")
        result[(identifier, method)] = row
    return result


def commit_result(db, candidate, method, result, config):
    checked = backend.validate_method_result(candidate, method, result, config["trials_per_method"])
    if result.get("seed_argument") != result_seed(config["seed"], candidate["id"], method):
        checked.update(validated=False, validation_error="Result seed differs from frozen request")
    if not checked["validated"]:
        record_error(db, candidate["id"], method, checked)
        return checked
    payload = json_text(checked)
    with db:
        db.execute("INSERT INTO results VALUES (?,?,?,?)",
                   (candidate["id"], method, payload, digest_bytes(payload.encode())))
    return checked


def record_error(db, identifier, method, payload):
    with db:
        db.execute("INSERT INTO errors(candidate_id,method,recorded_utc,payload) VALUES (?,?,?,?)",
                   (identifier, method, utc_now(), json_text(payload)))


def make_label(candidate, method_rows, trials):
    if set(method_rows) != set(METHODS):
        return None
    for method, row in method_rows.items():
        if (row.get("validated") is not True or row.get("method") != method or
                row.get("id") != candidate["id"] or any(row.get(field) != trials for field in
                    ("trials", "requested_trials", "returned_trials"))):
            raise ValueError("A label needs all three validated, complete method budgets")
    best_method = min(METHODS, key=lambda method: method_rows[method]["upper_bound"])
    chosen = method_rows[best_method]
    return {**candidate, "label_kind": "verified_heuristic_upper_bound", "is_exact": False,
            "distance_upper_bound": chosen["upper_bound"], "d_upper": chosen["upper_bound"],
            "best_method": best_method, "witness": chosen["witness"],
            "trials_per_method": trials, "total_trials": 3 * trials,
            "methods": {method: {field: method_rows[method][field] for field in
                         ("upper_bound", "witness", "raw_distance", "weight_mismatch",
                          "requested_trials", "returned_trials", "seed_argument",
                          "elapsed_seconds", "cpu_seconds")} for method in METHODS},
            "validation": "all three returned witnesses independently checked against original PBB stabilizer"}


def export_snapshot(db, output, config, candidates, state=None):
    output = Path(output)
    results = load_results(db, candidates, config)
    labels = []
    for candidate in candidates:
        methods = {method: results[(candidate["id"], method)] for method in METHODS
                   if (candidate["id"], method) in results}
        label = make_label(candidate, methods, config["trials_per_method"])
        if label:
            labels.append(label)
    error_rows = [(identifier, method, read_json(payload)) for identifier, method, payload
                  in db.execute("SELECT candidate_id,method,payload FROM errors ORDER BY sequence")]
    unresolved = {(identifier, method) for identifier, method, _ in error_rows
                  if (identifier, method) not in results}
    complete = len(labels) == config["target_codes"]
    summary = {
        "schema": SCHEMA, "updated_utc": utc_now(),
        "state": "complete" if complete else (state or "running"),
        "created_utc": _get_metadata(db, "created_utc"),
        "target_codes": config["target_codes"], "selected": len(candidates),
        "completed": len(labels), "remaining": config["target_codes"] - len(labels),
        "saved_method_results": len(results), "expected_method_results": 3 * config["target_codes"],
        "requested_trials_per_method": config["trials_per_method"],
        "requested_total_trials_per_code": 3 * config["trials_per_method"],
        "recorded_actual_trials": sum(row["returned_trials"] for row in results.values()),
        "completed_methods": dict(Counter(method for _, method in results)),
        "candidate_proposals": _get_metadata(db, "next_candidate_index", 0),
        "candidate_outcomes": dict(db.execute("SELECT outcome,COUNT(*) FROM attempts GROUP BY outcome")),
        "selected_length_strata": dict(Counter(str(row.get("length_stratum")) for row in candidates)),
        "upper_bound_histogram": dict(sorted(Counter(row["d_upper"] for row in labels).items())),
        "raw_distance_weight_mismatches": sum(bool(row.get("weight_mismatch")) for row in results.values()),
        "algorithm_cpu_seconds": sum(row.get("algorithm_cpu_seconds") or 0 for row in results.values()),
        "method_cpu_seconds": sum(row.get("cpu_seconds") or 0 for row in results.values()),
        "method_wall_seconds": sum(row.get("elapsed_seconds") or 0 for row in results.values()),
        "historical_method_failures": len(error_rows), "unresolved_method_failures": len(unresolved),
        "unresolved_errors": [{"id": identifier, "method": method} for identifier, method in sorted(unresolved)],
        "label_kind": "verified_heuristic_upper_bound", "is_exact": False,
        "sampler_version": SAMPLER_VERSION, "dedup_scope": DEDUP_SCOPE,
        "configuration_sha256": digest_bytes(json_text(config).encode()),
    }
    write_jsonl(output / "labels.jsonl", labels)
    ordered_results = [results[(candidate["id"], method)] for candidate in candidates
                       for method in METHODS if (candidate["id"], method) in results]
    write_jsonl(output / "methods.jsonl", ordered_results)
    write_json(output / "summary.json", summary)
    return summary


def independent_completion_audit(db, output, config):
    """Replay structures and validate every original witness before a receipt."""
    candidates = load_candidates(db, config, replay=True)
    results = load_results(db, candidates, config, revalidate=True)
    if len(candidates) != config["target_codes"] or len(results) != 3 * config["target_codes"]:
        raise ValueError("Cannot certify completion with missing candidates or method results")
    if {name: sha256_file(HERE / name) for name in SOURCE_FILES} != config["source_sha256"]:
        raise ValueError("Source files changed during the run")
    if backend.backend_manifest() != config["backend"]:
        raise ValueError("Backend manifest changed during the run")
    summary = export_snapshot(db, output, config, candidates)
    if summary["state"] != "complete" or summary["unresolved_method_failures"]:
        raise ValueError("Completion audit found unresolved results")
    output = Path(output)
    expected_candidates = "".join(json_text(row) + "\n" for row in candidates).encode()
    if (output / "candidates.jsonl").read_bytes() != expected_candidates:
        raise ValueError("Published candidate population differs from frozen journal")
    receipt = {"schema": SCHEMA, "state": "complete_verified", "checked_utc": utc_now(),
               "codes": len(candidates), "methods": len(results),
               "actual_trials": summary["recorded_actual_trials"],
               "trials_per_method": config["trials_per_method"],
               "all_candidates_genuinely_non_css": True, "all_witnesses_verified": True,
               "canonical_duplicates": 0, "is_exact": False,
               "configuration_sha256": summary["configuration_sha256"],
               "output_sha256": {name: sha256_file(output / name) for name in
                    ("candidates.jsonl", "labels.jsonl", "methods.jsonl", "summary.json")}}
    write_json(output / "completion_verified.json", receipt)
    return receipt


def _run_method_task(candidate, method, trials, seed, timeout):
    from run_pbb_distance_isolated import run_isolated
    return run_isolated(candidate, method, trials, seed, timeout_seconds=timeout)


def run_pending(db, output, config, candidates, workers, timeout, runner=None):
    """Bounded in-flight queue; stop adding work after a failed call, save survivors.

    A crashed or invalid method is written to errors, never results. Restarting
    this command retries only methods with no validated saved result.
    """
    results = load_results(db, candidates, config, revalidate=True)
    tasks = [(candidate, method) for candidate in candidates for method in METHODS
             if (candidate["id"], method) not in results]
    runner = runner or _run_method_task
    if not tasks:
        return True
    failed, submitted = False, 0
    with ProcessPoolExecutor(max_workers=workers,
                             mp_context=multiprocessing.get_context("spawn")) as pool:
        active = {}
        while submitted < len(tasks) or active:
            while not failed and submitted < len(tasks) and len(active) < workers:
                candidate, method = tasks[submitted]
                seed = result_seed(config["seed"], candidate["id"], method)
                future = pool.submit(runner, candidate, method, config["trials_per_method"], seed, timeout)
                active[future] = (candidate, method)
                submitted += 1
            if not active:
                break
            done, _ = wait(active, return_when=FIRST_COMPLETED)
            for future in done:
                candidate, method = active.pop(future)
                try:
                    checked = commit_result(db, candidate, method, future.result(), config)
                    if not checked["validated"]:
                        failed = True
                        print(json_text({"event": "method_invalid", "id": candidate["id"],
                                         "method": method, "error": checked["validation_error"]}), flush=True)
                except Exception as error:
                    failed = True
                    record_error(db, candidate["id"], method,
                                 {"error": f"{type(error).__name__}: {error}",
                                  "completed_budget_claimed": False})
                    print(json_text({"event": "method_failed", "id": candidate["id"],
                                     "method": method, "error": str(error)}), flush=True)
                summary = export_snapshot(db, output, config, candidates,
                                          state="failed_partial" if failed else "running")
                print(json_text({"event": "progress", "completed": summary["completed"],
                                 "target": config["target_codes"],
                                 "saved_method_results": summary["saved_method_results"],
                                 "actual_trials": summary["recorded_actual_trials"],
                                 "unresolved_method_failures": summary["unresolved_method_failures"]}), flush=True)
    return not failed


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--target", type=int, default=100)
    parser.add_argument("--trials", type=int, default=10000)
    parser.add_argument("--workers", type=int, default=default_workers())
    parser.add_argument("--seed", type=int, default=DEFAULT_SEED)
    parser.add_argument("--max-candidates", type=int, default=2000000)
    parser.add_argument("--method-timeout-seconds", type=float, default=None)
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument("--prepare-only", action="store_true")
    modes.add_argument("--export-only", action="store_true")
    for name, default in (("ell_min", 3), ("ell_max", 30), ("m_min", 3), ("m_max", 30),
                          ("n_min", 18), ("n_max", 360), ("terms_a", 3), ("terms_b", 3)):
        parser.add_argument("--" + name.replace("_", "-"), type=int, default=default)
    args = parser.parse_args(argv)
    if min(args.target, args.trials, args.workers, args.max_candidates) < 1 or args.seed < 0:
        parser.error("target, trials, workers and max-candidates must be positive; seed must be nonnegative")
    if args.method_timeout_seconds is not None and args.method_timeout_seconds <= 0:
        parser.error("method timeout must be positive")
    allocated = os.environ.get("SLURM_CPUS_PER_TASK")
    if allocated and args.workers > int(allocated):
        parser.error("workers cannot exceed the Slurm CPU allocation")
    return args


def main(argv=None):
    args = parse_args(argv)
    output = args.output_dir.expanduser().resolve()
    config = scientific_config(args)
    with run_lock(output):
        if args.export_only and not (output / "state.sqlite3").is_file():
            raise ValueError("--export-only requires an existing run journal")
        db = open_database(output / "state.sqlite3", config)
        try:
            write_json(output / "configuration.json", config)
            if args.export_only:
                candidates = load_candidates(db, config)
                load_results(db, candidates, config, revalidate=True)
            else:
                candidates = prepare_population(db, output, config, args.max_candidates)
            summary = export_snapshot(db, output, config, candidates,
                                      "prepared" if args.prepare_only else "running")
            if not args.prepare_only and not args.export_only:
                ok = run_pending(db, output, config, candidates, args.workers,
                                 args.method_timeout_seconds)
                if not ok:
                    return 1
                summary = export_snapshot(db, output, config, candidates)
            if summary["state"] == "complete":
                print(json_text(independent_completion_audit(db, output, config)), flush=True)
            else:
                print(json_text(summary), flush=True)
            return 0
        finally:
            db.close()


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(130)
    except Exception as error:
        print(f"PBB dataset failed: {type(error).__name__}: {error}", file=sys.stderr, flush=True)
        raise SystemExit(1)
