#!/usr/bin/env python3
"""Deterministic, auditable PBB candidate sampler; no distance search.

This is an explicit subfamily, not a reproduction of an unpublished sampling
distribution. Starting from a CSS BB code with A,B, choose self-reciprocal
cyclic polynomials F,G and set C=A*F, D=B*G over GF(2). The symmetric block
matrix diag(F,G) defines a diagonal Clifford transformation of the base code.
At least one nonzero shift is required, so sampling is not restricted to
single-qubit phase gates. Every accepted stabilizer rowspace is checked to be
non-CSS, and the Clifford transformation is allowed to change code distance.
"""
from __future__ import annotations

import hashlib
import json
import random

from bb_distance_candidates import candidate_for_index as css_candidate_for_index
from bb_distance_candidates import SAMPLER_VERSION as CSS_SAMPLER_VERSION
from pbb_code_algebra import (
    DEDUP_SCOPE, _integer, canonical_key, is_self_reciprocal,
    multiply_support, prepare_code,
)


SAMPLER_VERSION = "pbb_nonlocal_diagonal_clifford_stratified_v1"
CONSTRUCTION_FAMILY = "css_bb_symmetric_cyclic_diagonal_clifford"


def _perturbation(rng, ell, m, nonlocal_required=False):
    modes = ("inverse_pair", "identity_plus_inverse_pair")
    if not nonlocal_required:
        modes += ("identity",)
    mode = rng.choice(modes)
    if mode == "identity":
        return ((0, 0),), mode
    shifts = [(a, b) for a in range(ell) for b in range(m) if a or b]
    if not shifts:
        raise ValueError("Nonlocal perturbation requires a lattice with at least two sites")
    a, b = rng.choice(shifts)
    # A self-inverse shift occurs once in the support, not twice modulo two.
    terms = {(a, b), ((-a) % ell, (-b) % m)}
    if mode == "identity_plus_inverse_pair":
        terms.add((0, 0))
    return tuple(sorted(terms)), mode


def candidate_for_index(index, seed, ell_min=3, ell_max=30, m_min=3, m_max=30,
                        n_min=18, n_max=360, terms_a=3, terms_b=3):
    """Return one deterministic proposal with structural rejection reasons.

    Indices rotate through the existing CSS sampler's length strata. Failed
    candidates retain supports, construction seeds and provenance. An ``ok``
    result promises k>0, commutation, and a truly non-CSS stabilizer rowspace;
    it promises neither a particular distance nor dataset uniqueness.
    """
    _integer(index, "index")
    _integer(seed, "seed")
    settings = dict(ell_min=ell_min, ell_max=ell_max, m_min=m_min, m_max=m_max,
                    n_min=n_min, n_max=n_max, terms_a=terms_a, terms_b=terms_b)
    for name, value in settings.items():
        _integer(value, name, 1)
    if ell_max > 30 or m_max > 30 or n_max > 360:
        raise ValueError("This PBB corpus requires ell,m<=30 and n=2*ell*m<=360")
    if min(terms_a, terms_b) < 2:
        raise ValueError("A and B need at least two monomials each")
    material = {"version": SAMPLER_VERSION, "index": index, "seed": seed, "settings": settings}
    digest = hashlib.sha256(json.dumps(material, sort_keys=True,
                                      separators=(",", ":")).encode()).hexdigest()
    candidate_seed = int(digest[:16], 16)
    base = css_candidate_for_index(index, candidate_seed, **settings)["candidate"]
    rng = random.Random(candidate_seed)
    ell, m, A, B = base["ell"], base["m"], base["A"], base["B"]
    required_side = rng.randrange(2)
    F, f_mode = _perturbation(rng, ell, m, required_side == 0)
    G, g_mode = _perturbation(rng, ell, m, required_side == 1)
    assert is_self_reciprocal(F, ell, m) and is_self_reciprocal(G, ell, m)
    C, D = multiply_support(A, F, ell, m), multiply_support(B, G, ell, m)
    row = {
        "id": f"pbb-{index:09d}-{digest[:12]}",
        "candidate_index": index, "raw_attempt": index + 1,
        "candidate_seed": candidate_seed, "sampler_seed": seed,
        "sampler_version": SAMPLER_VERSION,
        "family": "PBB", "sampling_family": base["sampling_family"],
        "construction_family": CONSTRUCTION_FAMILY,
        "length_stratum": base["length_stratum"],
        "ell": ell, "m": m, "n": base["n"],
        "A": A, "B": B, "C": [list(t) for t in C], "D": [list(t) for t in D],
        "support_sizes": [len(A), len(B), len(C), len(D)],
        "dedup_scope": DEDUP_SCOPE,
        "provenance": {
            "distribution": "explicit_sampler_subfamily_not_author_dataset",
            "settings": settings, "seed_material": material,
            "seed_sha256": digest,
            "base_css_sampler": CSS_SAMPLER_VERSION,
            "base_css_id": base["id"], "base_css_seed": base["candidate_seed"],
            "base_css_canonical_key": base["canonical_key"], "base_css_k": base["k"],
            "F": [list(t) for t in F], "G": [list(t) for t in G],
            "F_mode": f_mode, "G_mode": g_mode,
            "self_reciprocal_checked": True,
            "nonlocal_perturbation": any(a or b for a, b in F + G),
            "construction": "C=A*F,D=B*G in GF(2)[Z_ell x Z_m]",
        },
    }
    if not C or not D:
        return {"status": "rejected", "reason": "empty_perturbation_support", "candidate": row}
    prepared = prepare_code(row)
    row.update(prepared["structure"])
    # A symmetric diagonal Clifford is invertible; losing encoded qubits
    # would indicate a construction or binary rank implementation error.
    if row["k"] != base["k"]:
        raise AssertionError("Symmetric diagonal Clifford changed k")
    row["canonical_key"] = canonical_key(row)
    row["group_id"] = row["canonical_key"]
    if row["k"] <= 0:
        return {"status": "rejected", "reason": "no_logical_qubits", "candidate": row}
    if not row["non_css"]:
        return {"status": "rejected", "reason": "css_stabilizer_rowspace", "candidate": row}
    return {"status": "ok", "reason": None, "candidate": row}
