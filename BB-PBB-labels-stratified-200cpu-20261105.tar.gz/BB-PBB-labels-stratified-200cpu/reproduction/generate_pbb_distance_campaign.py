#!/usr/bin/env python3
"""Scalable, resumable PBB upper-bound campaign, preserving the pilot algorithms.

Scientific code remains in the frozen pilot modules. This coordinator adds
immutable exclusion snapshots, deterministic batched parallel preparation,
individual method commits, and periodic streaming exports. Live summary.json
may be ahead of labels.jsonl/methods.jsonl; export counts are reported explicitly.
"""
from __future__ import annotations

import argparse
from collections import Counter
from concurrent.futures import ProcessPoolExecutor, wait, FIRST_COMPLETED
import hashlib
import multiprocessing
import os
from pathlib import Path
import sys
import time

import generate_pbb_distance_dataset as base
from pbb_distance_candidates import candidate_for_index, canonical_key

HERE = Path(__file__).resolve().parent
SCHEMA = "pbb_full_pauli_campaign_v1"
METHODS = base.METHODS
SOURCE_FILES = (*base.SOURCE_FILES, Path(__file__).name)
DEFAULT_SEED = 2026110101


def _rows_from_bytes(data):
    return [base.read_json(line) for line in data.decode("utf-8").splitlines() if line.strip()]


def _exclusion_keys(rows):
    keys = set()
    for row in rows:
        if row.get("family") != "PBB":
            raise ValueError("Exclusion file must contain PBB specifications")
        prepared = base.prepare_code(row)
        if prepared["k"] <= 0 or not prepared["structure"]["non_css"]:
            raise ValueError("Exclusion specification is not a positive-k non-CSS PBB code")
        key = canonical_key(row)
        if row.get("canonical_key", key) != key:
            raise ValueError("Exclusion canonical key is inconsistent")
        keys.add(key)
    return keys


def freeze_exclusions(output, sources):
    """Copy exact source bytes once; resume verifies both snapshot and source."""
    output = Path(output)
    inputs = output / "inputs"
    inputs.mkdir(exist_ok=True)
    paths = [str(Path(path).expanduser().resolve()) for path in sources]
    if len(paths) != len(set(paths)):
        raise ValueError("Duplicate exclusion source path")
    destination = inputs / "exclusions.json"
    if destination.exists():
        manifest = base.read_json(destination.read_text())
        if [record["source"] for record in manifest["sources"]] != paths:
            raise ValueError("Exclusion sources differ from frozen configuration")
    else:
        if (output / "state.sqlite3").exists():
            raise ValueError("Existing campaign journal has no exclusion snapshot manifest")
        entries, keys = [], set()
        for index, path in enumerate(paths):
            data = Path(path).read_bytes()
            rows = _rows_from_bytes(data)
            row_keys = _exclusion_keys(rows)
            relative = f"inputs/exclusion-{index:03d}.jsonl"
            snapshot = output / relative
            if snapshot.exists() and snapshot.read_bytes() != data:
                raise ValueError("Incomplete exclusion snapshot differs from source")
            if not snapshot.exists():
                base.atomic_bytes(snapshot, data)
            entries.append({"source": path, "snapshot": relative,
                            "sha256": base.digest_bytes(data), "rows": len(rows),
                            "unique_canonical_codes": len(row_keys)})
            keys.update(row_keys)
        manifest = {"schema": "pbb_frozen_exclusions_v1", "sources": entries,
                    "unique_canonical_codes": len(keys),
                    "canonical_keys_sha256": base.digest_bytes(base.json_text(sorted(keys)).encode())}
        base.write_json(destination, manifest)
    return manifest, verify_exclusions(output, manifest)


def verify_exclusions(output, manifest, verify_sources=True):
    keys = set()
    for entry in manifest["sources"]:
        snapshot = Path(output) / entry["snapshot"]
        data = snapshot.read_bytes()
        if base.digest_bytes(data) != entry["sha256"]:
            raise ValueError("Frozen exclusion snapshot hash mismatch")
        if verify_sources and base.sha256_file(entry["source"]) != entry["sha256"]:
            raise ValueError("Original exclusion source changed after freezing")
        rows = _rows_from_bytes(data)
        row_keys = _exclusion_keys(rows)
        if len(rows) != entry["rows"] or len(row_keys) != entry["unique_canonical_codes"]:
            raise ValueError("Frozen exclusion counts differ")
        keys.update(row_keys)
    if (len(keys) != manifest["unique_canonical_codes"] or
            base.digest_bytes(base.json_text(sorted(keys)).encode()) != manifest["canonical_keys_sha256"]):
        raise ValueError("Frozen exclusion key manifest differs")
    return keys


def scientific_config(args, exclusions):
    config = base.scientific_config(args)
    config.update(schema=SCHEMA, exclusions=exclusions,
                  source_sha256={name: base.sha256_file(HERE / name) for name in SOURCE_FILES},
                  population_kind="additional_codes_excluding_all_prior_candidate_specifications")
    return config


def write_jsonl_stream(path, rows):
    """Bounded-memory atomic export; never construct a full JSONL byte string."""
    path = Path(path)
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("w", encoding="utf-8") as stream:
        for row in rows:
            stream.write(base.json_text(row) + "\n")
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def _proposal_task(request):
    index, seed, settings = request
    proposal = candidate_for_index(index, seed, **settings)
    # Rejected structures are deterministically regenerable; only their reason
    # is journaled, avoiding large rejected payload transfers between workers.
    return {"index": index, "status": proposal["status"], "reason": proposal.get("reason"),
            "candidate": proposal["candidate"] if proposal["status"] == "ok" else None}


def prepare_population(db, output, config, excluded, max_candidates, workers, batch_size):
    rows = base.load_candidates(db, config, replay=True)
    seen = {row["canonical_key"] for row in rows}
    if seen & excluded:
        raise ValueError("Frozen campaign population overlaps prior PBB exclusions")
    index = base._get_metadata(db, "next_candidate_index", 0)
    count, maximum = db.execute("SELECT COUNT(*),MAX(candidate_index) FROM attempts").fetchone()
    if count != index or (index and maximum != index - 1):
        raise ValueError("Candidate journal does not contain a contiguous consumed prefix")
    if len(rows) < config["target_codes"]:
        with ProcessPoolExecutor(max_workers=workers,
                                 mp_context=multiprocessing.get_context("spawn")) as pool:
            while len(rows) < config["target_codes"] and index < max_candidates:
                stop = min(max_candidates, index + batch_size)
                requests = ((i, config["seed"], config["sampling"]) for i in range(index, stop))
                proposals = list(pool.map(_proposal_task, requests, chunksize=4))
                additions, new_keys, consumed = [], set(), index
                with db:
                    for proposal in proposals:
                        if proposal["index"] != consumed:
                            raise ValueError("Parallel generation returned an out-of-order index")
                        outcome, reason = proposal["status"], proposal.get("reason")
                        if outcome == "ok":
                            row = proposal["candidate"]
                            if row.get("candidate_index") != consumed:
                                raise ValueError("Proposal identity does not match requested index")
                            key = base.validate_candidate(row, config)
                            if key in excluded:
                                outcome, reason = "excluded", "prior_PBB_candidate"
                            elif key in seen or key in new_keys:
                                outcome, reason = "duplicate", "supported_PBB_canonical_symmetry"
                            else:
                                payload = base.json_text(row)
                                db.execute("INSERT INTO candidates VALUES (?,?,?,?,?)",
                                           (row["id"], consumed, key, payload,
                                            base.digest_bytes(payload.encode())))
                                outcome = "accepted"
                                additions.append(row)
                                new_keys.add(key)
                        elif outcome != "rejected":
                            raise ValueError("Unknown candidate proposal status")
                        db.execute("INSERT INTO attempts VALUES (?,?,?)", (consumed, outcome, reason))
                        consumed += 1
                        if len(rows) + len(additions) == config["target_codes"]:
                            break
                    base._put_metadata(db, "next_candidate_index", consumed)
                # Update in-memory state only after the complete consumed prefix
                # commits. Extra proposals beyond the target are not admitted.
                rows.extend(additions)
                seen.update(new_keys)
                index = consumed
                progress = {"schema": SCHEMA, "state": "preparing", "updated_utc": base.utc_now(),
                            "target_codes": config["target_codes"], "selected": len(rows),
                            "completed": 0, "candidate_proposals": index,
                            "excluded_prior_codes": len(excluded),
                            "requested_trials_per_method": config["trials_per_method"]}
                base.write_json(Path(output) / "summary.json", progress)
                print(base.json_text({"event": "population_progress", **progress}), flush=True)
    if len(rows) != config["target_codes"]:
        raise RuntimeError(f"Only {len(rows)} / {config['target_codes']} candidates after {index} proposals; raise --max-candidates to resume")
    with db:
        base._put_metadata(db, "population_complete", True)
    write_jsonl_stream(Path(output) / "candidates.jsonl", rows)
    return rows


class Progress:
    """Cached validated results; each successful method updates counters once."""
    def __init__(self, db, candidates, config, results):
        self.candidates, self.config = candidates, config
        self.by_id = {row["id"]: row for row in candidates}
        self.results, self.methods, self.labels = {}, {}, {}
        self.method_counts, self.histogram = Counter(), Counter()
        self.actual_trials = self.mismatches = 0
        self.algorithm_cpu = self.method_cpu = self.method_wall = 0.0
        self.created = base._get_metadata(db, "created_utc")
        self.proposals = base._get_metadata(db, "next_candidate_index", 0)
        self.outcomes = dict(db.execute("SELECT outcome,COUNT(*) FROM attempts GROUP BY outcome"))
        self.strata = dict(Counter(str(row.get("length_stratum")) for row in candidates))
        errors = list(db.execute("SELECT candidate_id,method FROM errors"))
        self.error_count, self.unresolved = len(errors), set(errors)
        self.exported_methods = self.exported_labels = 0
        self.last_export_utc = None
        self.config_sha = base.digest_bytes(base.json_text(config).encode())
        for row in results.values():
            self.add(row)

    def add(self, row):
        key = (row["id"], row["method"])
        if key in self.results:
            raise ValueError("A saved method must not be counted twice")
        self.results[key] = row
        methods = self.methods.setdefault(row["id"], {})
        methods[row["method"]] = row
        self.method_counts[row["method"]] += 1
        self.actual_trials += row["returned_trials"]
        self.mismatches += bool(row.get("weight_mismatch"))
        self.algorithm_cpu += row.get("algorithm_cpu_seconds") or 0
        self.method_cpu += row.get("cpu_seconds") or 0
        self.method_wall += row.get("elapsed_seconds") or 0
        self.unresolved.discard(key)
        if len(methods) == len(METHODS):
            label = base.make_label(self.by_id[row["id"]], methods, self.config["trials_per_method"])
            self.labels[row["id"]] = label
            self.histogram[label["d_upper"]] += 1

    def failed(self, candidate_id, method):
        self.error_count += 1
        self.unresolved.add((candidate_id, method))

    def summary(self, state="running"):
        return {"schema": SCHEMA, "updated_utc": base.utc_now(), "state": state,
                "created_utc": self.created, "target_codes": self.config["target_codes"],
                "selected": len(self.candidates), "completed": len(self.labels),
                "remaining": self.config["target_codes"] - len(self.labels),
                "saved_method_results": len(self.results),
                "expected_method_results": len(METHODS) * self.config["target_codes"],
                "requested_trials_per_method": self.config["trials_per_method"],
                "requested_total_trials_per_code": len(METHODS) * self.config["trials_per_method"],
                "recorded_actual_trials": self.actual_trials,
                "completed_methods": dict(self.method_counts),
                "candidate_proposals": self.proposals, "candidate_outcomes": self.outcomes,
                "selected_length_strata": self.strata,
                "excluded_prior_codes": self.config["exclusions"]["unique_canonical_codes"],
                "upper_bound_histogram": dict(sorted(self.histogram.items())),
                "raw_distance_weight_mismatches": self.mismatches,
                "algorithm_cpu_seconds": self.algorithm_cpu, "method_cpu_seconds": self.method_cpu,
                "method_wall_seconds": self.method_wall,
                "historical_method_failures": self.error_count,
                "unresolved_method_failures": len(self.unresolved),
                "unresolved_errors": [{"id": identifier, "method": method}
                                      for identifier, method in sorted(self.unresolved)],
                "configuration_sha256": self.config_sha,
                "label_kind": "verified_heuristic_upper_bound", "is_exact": False,
                "sampler_version": self.config["sampler_version"],
                "dedup_scope": self.config["dedup_scope"],
                "full_export_updated_utc": self.last_export_utc,
                "full_export_saved_method_results": self.exported_methods,
                "full_export_completed_codes": self.exported_labels,
                "live_summary_note": "SQLite commits and this summary may be ahead of periodic JSONL exports"}

    def save_summary(self, output, state="running"):
        summary = self.summary(state)
        base.write_json(Path(output) / "summary.json", summary)
        return summary

    def export(self, output, state="running"):
        output = Path(output)
        write_jsonl_stream(output / "labels.jsonl", (self.labels[row["id"]]
                          for row in self.candidates if row["id"] in self.labels))
        write_jsonl_stream(output / "methods.jsonl", (self.results[(row["id"], method)]
                          for row in self.candidates for method in METHODS
                          if (row["id"], method) in self.results))
        self.exported_labels, self.exported_methods = len(self.labels), len(self.results)
        self.last_export_utc = base.utc_now()
        return self.save_summary(output, state)


def run_pending(db, output, config, candidates, workers, timeout, export_interval, runner=None):
    results = base.load_results(db, candidates, config, revalidate=True)
    progress = Progress(db, candidates, config, results)
    tasks = [(row, method) for row in candidates for method in METHODS
             if (row["id"], method) not in results]
    runner = runner or base._run_method_task
    progress.export(output, "running")
    last_export, failed, submitted = time.monotonic(), False, 0
    if tasks:
        with ProcessPoolExecutor(max_workers=workers,
                                 mp_context=multiprocessing.get_context("spawn")) as pool:
            active = {}
            while submitted < len(tasks) or active:
                while not failed and submitted < len(tasks) and len(active) < workers:
                    candidate, method = tasks[submitted]
                    seed = base.result_seed(config["seed"], candidate["id"], method)
                    future = pool.submit(runner, candidate, method,
                                         config["trials_per_method"], seed, timeout)
                    active[future] = (candidate, method)
                    submitted += 1
                if not active:
                    break
                done, _ = wait(active, return_when=FIRST_COMPLETED)
                for future in done:
                    candidate, method = active.pop(future)
                    try:
                        checked = base.commit_result(db, candidate, method, future.result(), config)
                        if not checked["validated"]:
                            failed = True
                            progress.failed(candidate["id"], method)
                            print(base.json_text({"event": "method_invalid", "id": candidate["id"],
                                                  "method": method,
                                                  "error": checked["validation_error"]}), flush=True)
                        else:
                            progress.add(checked)
                    except Exception as error:
                        failed = True
                        base.record_error(db, candidate["id"], method,
                                          {"error": f"{type(error).__name__}: {error}",
                                           "completed_budget_claimed": False})
                        progress.failed(candidate["id"], method)
                        print(base.json_text({"event": "method_failed", "id": candidate["id"],
                                              "method": method, "error": str(error)}), flush=True)
                    state = "failed_partial" if failed else "running"
                    if time.monotonic() - last_export >= export_interval:
                        summary = progress.export(output, state)
                        last_export = time.monotonic()
                    else:
                        summary = progress.save_summary(output, state)
                    print(base.json_text({"event": "progress", "completed": summary["completed"],
                                          "target": config["target_codes"],
                                          "saved_method_results": summary["saved_method_results"],
                                          "actual_trials": summary["recorded_actual_trials"],
                                          "unresolved_method_failures": summary["unresolved_method_failures"]}), flush=True)
    progress.export(output, "failed_partial" if failed else "complete_pending_audit")
    return not failed


def independent_completion_audit(db, output, config):
    """Rebuild/replay all structures and revalidate all raw witness evidence."""
    output = Path(output)
    if {name: base.sha256_file(HERE / name) for name in SOURCE_FILES} != config["source_sha256"]:
        raise ValueError("Campaign or scientific source files changed")
    if base.backend.backend_manifest() != config["backend"]:
        raise ValueError("Frozen backend manifest changed")
    excluded = verify_exclusions(output, config["exclusions"])
    candidates = base.load_candidates(db, config, replay=True)
    keys = {row["canonical_key"] for row in candidates}
    if keys & excluded:
        raise ValueError("Campaign population overlaps prior PBB candidates")
    results = base.load_results(db, candidates, config, revalidate=True)
    if len(candidates) != config["target_codes"] or len(results) != len(METHODS) * config["target_codes"]:
        raise ValueError("Completion requires all candidates and full method budgets")
    expected = hashlib.sha256()
    for row in candidates:
        expected.update((base.json_text(row) + "\n").encode())
    if base.sha256_file(output / "candidates.jsonl") != expected.hexdigest():
        raise ValueError("Published candidate population differs from frozen journal")
    progress = Progress(db, candidates, config, results)
    if progress.unresolved:
        raise ValueError("Completion has unresolved method failures")
    summary = progress.export(output, "complete")
    receipt = {"schema": SCHEMA, "state": "complete_verified", "checked_utc": base.utc_now(),
               "codes": len(candidates), "new_codes": len(candidates), "methods": len(results),
               "actual_trials": summary["recorded_actual_trials"],
               "trials_per_method": config["trials_per_method"],
               "excluded_prior_codes": len(excluded), "prior_candidate_overlap": 0,
               "total_distinct_candidates_including_prior": len(keys | excluded),
               "all_candidates_genuinely_non_css": True, "all_witnesses_verified": True,
               "canonical_duplicates": 0, "is_exact": False,
               "configuration_sha256": summary["configuration_sha256"],
               "output_sha256": {name: base.sha256_file(output / name) for name in
                                  ("candidates.jsonl", "labels.jsonl", "methods.jsonl", "summary.json")}}
    base.write_json(output / "completion_verified.json", receipt)
    return receipt


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--target", type=int, default=10000)
    parser.add_argument("--trials", type=int, default=10000)
    parser.add_argument("--workers", type=int, default=base.default_workers())
    parser.add_argument("--prepare-workers", type=int)
    parser.add_argument("--prepare-batch-size", type=int, default=832)
    parser.add_argument("--export-interval-seconds", type=float, default=300)
    parser.add_argument("--seed", type=int, default=DEFAULT_SEED)
    parser.add_argument("--skip-codes", type=Path, action="append", required=True)
    parser.add_argument("--max-candidates", type=int, default=2000000)
    parser.add_argument("--method-timeout-seconds", type=float)
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument("--prepare-only", action="store_true")
    modes.add_argument("--export-only", action="store_true")
    for name, default in (("ell_min", 3), ("ell_max", 30), ("m_min", 3), ("m_max", 30),
                          ("n_min", 18), ("n_max", 360), ("terms_a", 3), ("terms_b", 3)):
        parser.add_argument("--" + name.replace("_", "-"), type=int, default=default)
    args = parser.parse_args(argv)
    args.prepare_workers = args.workers if args.prepare_workers is None else args.prepare_workers
    if min(args.target, args.trials, args.workers, args.prepare_workers,
           args.prepare_batch_size, args.max_candidates, args.export_interval_seconds) <= 0 or args.seed < 0:
        parser.error("Counts, workers, batch size and export interval must be positive; seed nonnegative")
    if args.method_timeout_seconds is not None and args.method_timeout_seconds <= 0:
        parser.error("Method timeout must be positive")
    allocated = os.environ.get("SLURM_CPUS_PER_TASK")
    if allocated and max(args.workers, args.prepare_workers) > int(allocated):
        parser.error("Workers cannot exceed the Slurm CPU allocation")
    return args


def main(argv=None):
    args = parse_args(argv)
    output = args.output_dir.expanduser().resolve()
    with base.run_lock(output):
        if args.export_only and not (output / "state.sqlite3").exists():
            raise ValueError("--export-only requires an existing journal")
        exclusions, excluded = freeze_exclusions(output, args.skip_codes)
        config = scientific_config(args, exclusions)
        db = base.open_database(output / "state.sqlite3", config)
        try:
            base.write_json(output / "configuration.json", config)
            if args.export_only:
                candidates = base.load_candidates(db, config, replay=True)
                if {row["canonical_key"] for row in candidates} & excluded:
                    raise ValueError("Stored candidate overlaps prior exclusions")
            else:
                candidates = prepare_population(db, output, config, excluded,
                                                args.max_candidates, args.prepare_workers,
                                                args.prepare_batch_size)
            if args.prepare_only or args.export_only:
                results = base.load_results(db, candidates, config, revalidate=True)
                progress = Progress(db, candidates, config, results)
                state = "prepared" if args.prepare_only else "exported_partial"
                summary = progress.export(output, state)
                complete = len(progress.labels) == config["target_codes"]
            else:
                if not run_pending(db, output, config, candidates, args.workers,
                                   args.method_timeout_seconds, args.export_interval_seconds):
                    return 1
                complete = True
            if complete:
                print(base.json_text(independent_completion_audit(db, output, config)), flush=True)
            else:
                print(base.json_text(summary), flush=True)
            return 0
        finally:
            db.close()


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(130)
    except Exception as error:
        print(f"PBB campaign failed: {type(error).__name__}: {error}", file=sys.stderr, flush=True)
        raise SystemExit(1)
