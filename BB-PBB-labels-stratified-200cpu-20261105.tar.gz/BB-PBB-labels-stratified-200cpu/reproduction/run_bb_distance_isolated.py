#!/usr/bin/env python3
"""Resume the frozen heuristic driver with one fresh child per method call.

Usage: python run_bb_distance_isolated.py [original driver arguments]

The persistent outer workers use only the standard library. Each starts one
child, waits for its entire original run_method call, and waits for process exit
before returning the result. No trials are split and no solver settings change.
This reclaims process memory BETWEEN calls; it does not bound one call's peak.
Imports/JIT compilation repeat for every call and can reduce throughput.

Original source files, manifest and journal compatibility are preserved. This
execution overlay is explicitly recorded in each new result and in an append-
only execution sidecar. A child crash raises, leaving that method uncommitted
so the original resume policy reruns its whole interrupted budget.
"""
from __future__ import annotations

import fcntl
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import tempfile
import time
import traceback
from datetime import datetime, timezone


HERE = Path(__file__).resolve().parent
AUDIT_ENV = "BB_DISTANCE_ISOLATION_AUDIT_PATH"
POLICY = "fresh_python_child_per_complete_method_v1"
THREAD_VARIABLES = ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
                    "NUMBA_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "BLIS_NUM_THREADS")


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def overlay_manifest():
    return {
        "execution_policy": POLICY,
        "launcher_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "python_executable": sys.executable,
        "python_version": platform.python_version(),
        "trial_budgets_and_seeds": "passed unchanged to original run_method",
        "memory_scope": "OS reclaims child memory after each complete method call",
        "single_call_memory_limit": "scheduler job limit; no per-call memory cap",
        "import_and_jit_scope": "repeated in each child",
        "slurm_job_id": os.environ.get("SLURM_JOB_ID"),
    }


def _audit(event):
    destination = os.environ.get(AUDIT_ENV)
    if not destination:
        return
    record = json.dumps({"recorded_utc": utc_now(), **event}, sort_keys=True,
                        ensure_ascii=False, allow_nan=False)
    with open(destination, "a", encoding="utf-8") as stream:
        fcntl.flock(stream.fileno(), fcntl.LOCK_EX)
        stream.write(record + "\n")
        stream.flush()
        os.fsync(stream.fileno())
        fcntl.flock(stream.fileno(), fcntl.LOCK_UN)


def init_outer_worker():
    """Keep persistent workers free of NumPy, Numba, ldpc and solver state."""
    for variable in THREAD_VARIABLES:
        os.environ[variable] = "1"


def child_main(request_path, response_path):
    request = json.loads(Path(request_path).read_text(encoding="utf-8"))
    init_outer_worker()
    # This is a separate interpreter; it imports the ORIGINAL, unpatched module.
    import bb_distance_backend as backend
    result = backend.run_method(request["row"], request["method"],
                                request["trials"], request["seed"])
    response = {"result": result, "child_pid": os.getpid(),
                "launcher_sha256": overlay_manifest()["launcher_sha256"]}
    temporary = Path(str(response_path) + ".tmp")
    temporary.write_text(json.dumps(response, ensure_ascii=False, allow_nan=False),
                         encoding="utf-8")
    temporary.replace(response_path)
    return 0


def _tail(path, limit=16000):
    with open(path, "rb") as stream:
        stream.seek(0, os.SEEK_END)
        stream.seek(max(0, stream.tell() - limit))
        return stream.read().decode("utf-8", errors="replace")


def _isolated_call(row, method, trials, seed, *, child_command=None):
    """child_command is an internal test seam; the CLI always uses this file."""
    started = time.perf_counter()
    profile = {**overlay_manifest(), "outer_worker_pid": os.getpid(),
               "started_utc": utc_now()}
    identity = {"id": row["id"], "method": method,
                "requested_trials": trials, "seed_argument": seed}
    _audit({"event": "child_call_started", **identity, "execution_overlay": profile})
    try:
        with tempfile.TemporaryDirectory(prefix="bb-distance-method-") as temporary:
            directory = Path(temporary)
            request_path, response_path = directory / "request.json", directory / "response.json"
            request_path.write_text(json.dumps({"row": row, "method": method,
                                                "trials": trials, "seed": seed},
                                               allow_nan=False), encoding="utf-8")
            command = (list(child_command) if child_command is not None else
                       [sys.executable, str(Path(__file__).resolve()), "--isolated-child"])
            environment = os.environ.copy()
            for variable in THREAD_VARIABLES:
                environment[variable] = "1"
            log_path = directory / "child.log"
            with log_path.open("wb") as log:
                completed = subprocess.run(command + [str(request_path), str(response_path)],
                                           stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                                           env=environment, check=False)
            profile["child_returncode"] = completed.returncode
            if completed.returncode != 0:
                raise RuntimeError(f"Child exited with code {completed.returncode}; "
                                   f"log tail: {_tail(log_path)}")
            if not response_path.is_file():
                raise RuntimeError(f"Child produced no response; log tail: {_tail(log_path)}")
            envelope = json.loads(response_path.read_text(encoding="utf-8"))
            if envelope.get("launcher_sha256") != profile["launcher_sha256"]:
                raise RuntimeError("Child/parent execution launcher hashes differ")
            result = envelope["result"]
            if not isinstance(result, dict) or any(result.get(key) != value
                                                   for key, value in identity.items()):
                raise RuntimeError("Child result identity, trial request or seed differs from request")
            child_pid = envelope.get("child_pid")
            if type(child_pid) is not int or child_pid <= 0 or child_pid == os.getpid():
                raise RuntimeError("Child response has no valid separate-process identity")
            if result.get("pid") != child_pid:
                raise RuntimeError("Backend PID differs from child process identity")
            profile.update(child_pid=child_pid, finished_utc=utc_now(),
                           child_lifetime_wall_seconds=time.perf_counter() - started)
            result["execution_overlay"] = profile
            _audit({"event": "child_call_finished", **identity,
                    "status": result.get("status"), "execution_overlay": profile})
            return result
    except Exception as error:
        profile.update(finished_utc=utc_now(),
                       child_lifetime_wall_seconds=time.perf_counter() - started)
        _audit({"event": "child_call_failed_uncommitted", **identity,
                "error": f"{type(error).__name__}: {error}", "execution_overlay": profile})
        raise RuntimeError(f"Isolated {method} call for {row['id']} failed; "
                           "no completed budget may be committed") from error


def run_method_isolated(row, method, trials=1000, seed=0):
    return _isolated_call(row, method, trials, seed)


def main(argv=None):
    import bb_distance_backend as backend
    import generate_bb_distance_dataset as driver
    args = driver.parse_args(argv)
    if not args.dry_run:
        output = args.output_dir.expanduser().resolve()
        output.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        audit_path = output / f"execution-isolated-{stamp}-{os.getpid()}.jsonl"
        os.environ[AUDIT_ENV] = str(audit_path)
        _audit({"event": "launcher_started", "arguments": list(sys.argv[1:] if argv is None else argv),
                "workers": args.workers, "execution_overlay": overlay_manifest()})
    original_initializer, original_runner = backend.init_worker, backend.run_method
    # main() imports these attributes at call time; on-disk pinned files stay intact.
    backend.init_worker, backend.run_method = init_outer_worker, run_method_isolated
    try:
        return driver.main(argv)
    finally:
        backend.init_worker, backend.run_method = original_initializer, original_runner


if __name__ == "__main__":
    if len(sys.argv) == 4 and sys.argv[1] == "--isolated-child":
        try:
            raise SystemExit(child_main(sys.argv[2], sys.argv[3]))
        except Exception:
            traceback.print_exc()
            raise SystemExit(1)
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(130)
