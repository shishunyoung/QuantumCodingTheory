#!/usr/bin/env python3
"""Collect witnessed odd CSS BB upper bounds and even structural controls.

Pilot mode searches a fixed number of unique structurally valid candidates;
campaign mode fills explicitly configured label quotas. Every searched code
receives all three complete 10,000-trial calls. Odd refers to the minimum
validated upper bound U, not a proof that the unknown true distance is odd.
Admissions follow candidate-index order and SQLite is authoritative.
"""
from __future__ import annotations

import argparse
from collections import Counter
from concurrent.futures import FIRST_COMPLETED, ProcessPoolExecutor, wait
import hashlib
import math
import multiprocessing
import os
from pathlib import Path
import signal
import sys
import time

import generate_bb_distance_10000_trials as base
from bb_odd_bound_candidates import candidate_for_index, SAMPLER_VERSION, DEDUP_SCOPE, STRUCTURES

HERE = Path(__file__).resolve().parent
SCHEMA = "css_bb_odd_bound_quota_campaign_v1"
METHODS = base.METHODS
ODD_BUCKETS = (("odd_3_5", 3, 5), ("odd_7_13", 7, 13),
               ("odd_15_21", 15, 21), ("odd_23_25", 23, 25))
BUCKETS = (*ODD_BUCKETS, ("control_even", 2, 28))
SOURCE_FILES = (*base.DEPENDENCIES, "bb_odd_bound_candidates.py", Path(__file__).name)
SAMPLING_FIELDS = ("ell_min", "ell_max", "m_min", "m_max", "n_min", "n_max",
                   "connected_only", "k_max", "structure_weights")
STOP_REQUESTED = False


def request_stop(signum, frame):
    global STOP_REQUESTED
    STOP_REQUESTED = True


def atomic_jsonl(path, records):
    path = Path(path)
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("w", encoding="utf-8") as stream:
        for row in records:
            stream.write(base.json_text(row) + "\n")
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def scientific_config(args, output, exclusions):
    """Execution resources/search caps may change on resume; science may not."""
    sampling = {name: getattr(args, name) for name in SAMPLING_FIELDS}
    # JSON round-trips tuples as lists; keep the frozen representation stable
    # for both CLI and programmatic callers.
    sampling["structure_weights"] = list(sampling["structure_weights"])
    return {
        "schema": SCHEMA, "trials": args.trials, "seed": args.seed,
        "mode": args.mode, "pilot_count": args.pilot_count,
        "quotas": {name: getattr(args, "target_" + name) for name, _, _ in BUCKETS},
        "sampling": sampling,
        "sampler_version": SAMPLER_VERSION, "dedup_scope": DEDUP_SCOPE,
        "budget_convention": base.BUDGET_CONVENTION,
        "methods": list(METHODS), "source": base.backend.backend_manifest(),
        "source_hashes": {name: base.sha256_file(HERE / name) for name in SOURCE_FILES},
        "effective_method_params": {m: base.backend.method_params(m, args.trials) for m in METHODS},
        "exclusion_keys_sha256": exclusions["keys_sha256"],
        "exclusion_manifest_sha256": base.sha256_file(Path(output) / "exclusions/manifest.json"),
        "execution_policy": base.isolation.POLICY,
        "corpus_limits": {"n_max": 360, "ell_max": 30, "m_max": 30},
        "admission_order": "ascending candidate_index after three complete validated methods",
        "range_interpretation": "Odd refers to verified heuristic U; true d may be even or smaller",
        "selection_policy": "Pilot completes a fixed candidate count; campaign fills odd/control quotas",
        "grouping_limit": "Dedup scope excludes full Aut or arbitrary code equivalence; group before training",
        "proposal_policy": "structural sampling only; no reduced-budget distance screening",
    }


def open_database(path, config, excluded_keys):
    db = base.open_database(path, config, excluded_keys)
    db.execute("""CREATE TABLE IF NOT EXISTS task_errors (
        error_id INTEGER PRIMARY KEY AUTOINCREMENT, candidate_id TEXT NOT NULL,
        method TEXT NOT NULL, created_utc TEXT NOT NULL, error TEXT NOT NULL)""")
    db.commit()
    return db


def classify(upper, counts, config):
    if type(upper) is not int or upper < 1:
        raise ValueError("Upper bound must be a positive integer")
    if upper % 2 == 0:
        bucket = "control_even" if 2 <= upper <= 28 else None
        outside = "even_outside_range"
    else:
        bucket = next((name for name, low, high in ODD_BUCKETS if low <= upper <= high), None)
        outside = "odd_outside_range"
    if bucket is None:
        return outside
    prefix = "accepted_" if counts["accepted_" + bucket] < config["quotas"][bucket] else "surplus_"
    return prefix + bucket


def validate_candidate(row, config, replay=False):
    base.validate_corpus_bounds(row)
    key = base.structural_key(row)
    if row.get("canonical_key") != key or row.get("group_id") != key:
        raise ValueError("Candidate canonical identity changed")
    sizes = (len(row.get("A", [])), len(row.get("B", [])))
    if tuple(sorted(sizes)) not in STRUCTURES or row.get("C") or row.get("D"):
        raise ValueError("Candidate is not an allowed variable-support CSS BB structure")
    if row.get("support_sizes") != list(sizes):
        raise ValueError("Candidate support_sizes disagrees with its construction")
    if row.get("structure_family") != f"A{min(sizes)}B{max(sizes)}":
        raise ValueError("Candidate structure family disagrees with support sizes")
    if replay:
        proposal = candidate_for_index(row["candidate_index"], config["seed"], **config["sampling"])
        if proposal["status"] != "ok" or proposal["candidate"] != row:
            raise ValueError("Candidate differs from deterministic odd-bound proposal replay")
    return key


def _proposal_task(request):
    index, seed, settings = request
    proposal = candidate_for_index(index, seed, **settings)
    return {"index": index, "status": proposal["status"], "reason": proposal.get("reason"),
            "candidate": proposal["candidate"] if proposal["status"] == "ok" else None}


def pending_rows(db):
    # Admissions are a contiguous prefix in candidate-index order. The indexed
    # range query avoids rescanning the entire completed population per method.
    frontier = db.execute("SELECT COALESCE(MAX(candidate_index),-1) FROM admissions").fetchone()[0]
    return [base.read_json(raw) for (raw,) in db.execute(
        "SELECT payload FROM candidates WHERE candidate_index>? ORDER BY candidate_index", (frontier,))]


def fill_batch(db, config, progress, pool, batch_size, proposal_batch_size,
               max_candidates, max_attempts, deadline, extend_pending=False):
    rows = pending_rows(db)
    if rows and not extend_pending:
        return rows
    if config["mode"] == "pilot":
        max_candidates = min(max_candidates, config["pilot_count"])
    index = db.execute("SELECT COALESCE(MAX(attempt_index)+1,0) FROM attempts").fetchone()[0]
    while len(rows) < batch_size and progress.candidates < max_candidates and index < max_attempts:
        if STOP_REQUESTED or time.monotonic() >= deadline:
            break
        stop = min(index + proposal_batch_size, max_attempts)
        proposals = pool.map(_proposal_task, ((i, config["seed"], config["sampling"])
                             for i in range(index, stop)), chunksize=4)
        # Consume the complete requested map before closing the preparation pool.
        proposals = list(proposals)
        additions, proposal_outcomes = [], Counter()
        with db:
            for proposal in proposals:
                if proposal["index"] != index:
                    raise ValueError("Parallel proposal sequence is not ordered")
                status, reason, identifier = proposal["status"], proposal.get("reason"), None
                outcome = "structural_rejection"
                if status == "ok":
                    row = proposal["candidate"]
                    if row.get("candidate_index") != index:
                        raise ValueError("Proposal index differs from requested index")
                    key = validate_candidate(row, config)
                    if db.execute("SELECT 1 FROM excluded WHERE canonical_key=?", (key,)).fetchone():
                        outcome, reason = "previously_searched", DEDUP_SCOPE
                    elif db.execute("SELECT 1 FROM candidates WHERE canonical_key=?", (key,)).fetchone():
                        outcome, reason = "duplicate", DEDUP_SCOPE
                    else:
                        identifier = row["id"]
                        db.execute("INSERT INTO candidates VALUES (?,?,?,?)",
                                   (identifier, index, key, base.json_text(row)))
                        additions.append(row)
                        outcome, reason = "scheduled", None
                elif status != "rejected":
                    raise ValueError("Unknown structural proposal status")
                db.execute("INSERT INTO attempts VALUES (?,?,?,?)", (index, outcome, identifier, reason))
                proposal_outcomes[outcome] += 1
                index += 1
                if len(rows) + len(additions) >= batch_size or progress.candidates + len(additions) >= max_candidates:
                    break
        rows.extend(additions)
        progress.candidates += len(additions)
        progress.proposals.update(proposal_outcomes)
        print(base.json_text({"event": "prepare_progress", "selected_in_batch": len(rows),
                              "selected_total": progress.candidates, "candidate_proposals": index}), flush=True)
    return rows


class Progress:
    """Read aggregate journal counts once; increment after committed changes."""
    def __init__(self, db, config):
        self.config = config
        self.counts = Counter(dict(db.execute("SELECT outcome,COUNT(*) FROM admissions GROUP BY outcome")))
        self.proposals = Counter(dict(db.execute("SELECT outcome,COUNT(*) FROM attempts GROUP BY outcome")))
        self.candidates = db.execute("SELECT COUNT(*) FROM candidates").fetchone()[0]
        self.methods = Counter(dict(db.execute("SELECT method,COUNT(*) FROM results WHERE validated=1 GROUP BY method")))
        self.saved, self.invalid, self.trials, self.cpu, self.wall = db.execute("""SELECT COUNT(*),
            COALESCE(SUM(1-validated),0),COALESCE(SUM(actual_trials),0),
            COALESCE(SUM(cpu_seconds),0),COALESCE(SUM(wall_seconds),0) FROM results""").fetchone()
        self.histogram = Counter()
        self.all_histogram = Counter()
        self.strata = {"distance": {}, "structure": {}, "n": {}, "length": {}}
        for raw, in db.execute("SELECT payload FROM admissions ORDER BY candidate_index"):
            self._add_label_statistics(base.read_json(raw))
        self.historical_errors = db.execute("SELECT COUNT(*) FROM task_errors").fetchone()[0]
        self.unresolved = set(db.execute("""SELECT DISTINCT e.candidate_id,e.method FROM task_errors e
            LEFT JOIN results r ON r.candidate_id=e.candidate_id AND r.method=e.method
            WHERE r.validated IS NULL OR r.validated=0"""))
        self.excluded = db.execute("SELECT COUNT(*) FROM excluded").fetchone()[0]
        self.exported_labels = self.exported_methods = 0
        self.last_export_utc = None
        self.last_export_monotonic = 0.0
        self.started = time.monotonic()

    @property
    def quotas_reached(self):
        return all(self.counts["accepted_" + b] == self.config["quotas"][b] for b, _, _ in BUCKETS)

    @property
    def target_reached(self):
        if self.config["mode"] == "pilot":
            return sum(self.counts.values()) == self.config["pilot_count"]
        return self.quotas_reached

    def _add_label_statistics(self, label):
        upper = label["d_upper"]
        selected = label["quota_outcome"].startswith("accepted_")
        self.all_histogram[upper] += 1
        if selected:
            self.histogram[upper] += 1
        n = 2 * label["ell"] * label["m"]
        length = next(f"n{lo}-{hi}" for lo, hi in ((18,72),(73,144),(145,216),(217,288),(289,360))
                      if lo <= n <= hi)
        keys = {"distance": str(upper), "structure": label["structure_family"],
                "n": str(n), "length": length}
        for axis, key in keys.items():
            counts = self.strata[axis].setdefault(key, {"searched": 0, "odd": 0, "even": 0, "selected": 0})
            counts["searched"] += 1
            counts["odd" if upper % 2 else "even"] += 1
            counts["selected"] += int(selected)

    def add_method(self, result, valid=True):
        self.saved += 1
        self.invalid += not valid
        self.methods[result["method"]] += bool(valid)
        for attribute, key in (("trials", "returned_trials"), ("cpu", "algorithm_cpu_seconds"),
                               ("wall", "algorithm_wall_seconds")):
            value = result.get(key)
            if type(value) in (int, float) and math.isfinite(value) and value >= 0:
                setattr(self, attribute, getattr(self, attribute) + value)
        if valid:
            self.unresolved.discard((result["id"], result["method"]))

    def add_admission(self, label):
        outcome = label["quota_outcome"]
        self.counts[outcome] += 1
        self._add_label_statistics(label)

    def summary(self, state):
        accepted = {b: self.counts["accepted_" + b] for b, _, _ in BUCKETS}
        odd_target = sum(self.config["quotas"][b] for b, _, _ in ODD_BUCKETS)
        odd_count = sum(accepted[b] for b, _, _ in ODD_BUCKETS)
        mode = self.config["mode"]
        return {"schema": SCHEMA, "state": state, "updated_utc": base.utc_now(),
                "mode": mode, "progress_unit": "completed_candidates" if mode == "pilot" else "selected_labels",
                "pilot_target": self.config["pilot_count"] if mode == "pilot" else None,
                "accepted": sum(accepted.values()), "selected_total": sum(accepted.values()),
                "target": self.config["pilot_count"] if mode == "pilot" else sum(self.config["quotas"].values()),
                "selected_total_target": sum(self.config["quotas"].values()),
                "odd_count": odd_count, "odd_target": odd_target,
                "even_controls_count": accepted["control_even"],
                "even_controls_target": self.config["quotas"]["control_even"],
                "accepted_by_quota": accepted, "target_by_quota": self.config["quotas"],
                "target_reached": self.target_reached, "campaign_quotas_reached": self.quotas_reached,
                "candidate_outcomes": dict(self.counts),
                "all_upper_histogram": dict(sorted(self.all_histogram.items())),
                "all_odd_labels": sum(count for upper, count in self.all_histogram.items() if upper % 2),
                "all_even_labels": sum(count for upper, count in self.all_histogram.items() if upper % 2 == 0),
                "strata": self.strata,
                "sampling_note": "Mixture weights describe proposals before structural rejection; strata need not have equal valid counts",
                "completed_codes": sum(self.counts.values()),
                "distinct_candidates_searched_or_pending": self.candidates,
                "candidate_proposals": sum(self.proposals.values()), "proposal_outcomes": dict(self.proposals),
                "saved_method_results": self.saved, "validated_method_results": sum(self.methods.values()),
                "completed_methods": dict(self.methods), "invalid_method_results": self.invalid,
                "recorded_actual_trials": self.trials, "algorithm_cpu_seconds": self.cpu,
                "sum_algorithm_wall_seconds": self.wall,
                "historical_method_errors": self.historical_errors,
                "unresolved_method_errors": len(self.unresolved),
                "excluded_prior_groups": self.excluded,
                "requested_trials_per_method": self.config["trials"],
                "requested_total_trials_per_code": self.config["trials"] * len(METHODS),
                "accepted_upper_histogram": dict(sorted(self.histogram.items())),
                "label_kind": "heuristic_upper_bound", "is_exact": False,
                "range_interpretation": "Odd U is not certified odd true d; all labels are witnessed upper bounds",
                "budget_convention": base.BUDGET_CONVENTION,
                "corpus_limits": self.config.get("corpus_limits"),
                "sampling": self.config.get("sampling"), "dedup_scope": DEDUP_SCOPE,
                "admission_order": "candidate_index, after three complete validated budgets",
                "full_export_updated_utc": self.last_export_utc,
                "full_export_accepted_labels": self.exported_labels,
                "full_export_saved_methods": self.exported_methods,
                "live_summary_note": "SQLite commits/summary may be ahead of periodic JSONL exports",
                "invocation_elapsed_seconds": time.monotonic() - self.started}

    def save(self, output, state="running"):
        summary = self.summary(state)
        base.write_json(Path(output) / "summary.json", summary)
        return summary


def finalize_admissions(db, config, progress):
    """Only advance the ascending index frontier; incomplete earlier code blocks."""
    count = 0
    for row in pending_rows(db):
        records = list(db.execute("SELECT payload,validated FROM results WHERE candidate_id=?", (row["id"],)))
        if any(not valid for _, valid in records):
            raise ValueError("Invalid saved method prevents label admission")
        if len(records) < len(METHODS):
            break
        label = base.label_for(row, [base.read_json(raw) for raw, _ in records], config)
        label["quota_outcome"] = classify(label["d_upper"], progress.counts, config)
        with db:
            db.execute("INSERT INTO admissions VALUES (?,?,?,?)", (row["id"], row["candidate_index"],
                       label["quota_outcome"], base.json_text(label)))
        progress.add_admission(label)
        count += 1
    return count


def export_snapshot(db, config, progress, output, state="running"):
    output = Path(output)
    selections = {"labels.jsonl": "1=1",
                  "accepted.jsonl": "outcome LIKE 'accepted_%'",
                  "odd.jsonl": "outcome LIKE 'accepted_odd_%'",
                  "even_controls.jsonl": "outcome='accepted_control_even'",
                  "surplus.jsonl": "outcome LIKE 'surplus_%'",
                  "rejected.jsonl": "outcome IN ('odd_outside_range','even_outside_range')"}
    for bucket, _, _ in BUCKETS:
        selections[f"accepted_{bucket}.jsonl"] = f"outcome='accepted_{bucket}'"
    for name, condition in selections.items():
        atomic_jsonl(output / name, (base.read_json(raw) for raw, in db.execute(
            "SELECT payload FROM admissions WHERE " + condition + " ORDER BY candidate_index")))
    atomic_jsonl(output / "candidates.jsonl", (base.read_json(raw) for raw, in db.execute(
        "SELECT payload FROM candidates ORDER BY candidate_index")))
    atomic_jsonl(output / "methods.jsonl", (dict(base.read_json(raw), parent_validation_passed=bool(valid),
        parent_validation_error=error) for raw, valid, error in db.execute(
        "SELECT payload,validated,validation_error FROM results ORDER BY candidate_id,method")))
    atomic_jsonl(output / "errors.jsonl", (dict(error_id=i,candidate_id=c,method=m,created_utc=t,error=e)
        for i,c,m,t,e in db.execute("SELECT * FROM task_errors ORDER BY error_id")))
    progress.exported_labels = sum(progress.counts["accepted_" + b] for b, _, _ in BUCKETS)
    progress.exported_methods = progress.saved
    progress.last_export_utc = base.utc_now()
    progress.last_export_monotonic = time.monotonic()
    return progress.save(output, state)


def record_error(db, progress, row, method, error):
    message = f"{type(error).__name__}: {error}"
    with db:
        db.execute("INSERT INTO task_errors(candidate_id,method,created_utc,error) VALUES (?,?,?,?)",
                   (row["id"], method, base.utc_now(), message))
    progress.historical_errors += 1
    progress.unresolved.add((row["id"], method))
    print(base.json_text({"event": "method_error", "id": row["id"], "method": method,
                         "error": message}), flush=True)


def execute_batch(db, output, config, progress, rows, pool, workers, deadline,
                  export_interval, runner=None):
    runner = runner or base.isolation.run_method_isolated
    tasks = [(row, method) for row in rows for method in METHODS if not db.execute(
        "SELECT 1 FROM results WHERE candidate_id=? AND method=?", (row["id"], method)).fetchone()]
    submitted, active, failed, stopping = 0, {}, False, False
    while submitted < len(tasks) or active:
        stopping = stopping or STOP_REQUESTED or time.monotonic() >= deadline
        while not failed and not stopping and submitted < len(tasks) and len(active) < workers:
            row, method = tasks[submitted]
            future = pool.submit(runner, row, method, config["trials"],
                                 base.result_seed(config["seed"], row, method))
            active[future] = row, method
            submitted += 1
        if not active:
            break
        done, _ = wait(active, timeout=60, return_when=FIRST_COMPLETED)
        for future in done:
            row, method = active.pop(future)
            try:
                result = future.result()
                if result.get("method") != method or result.get("id") != row["id"]:
                    raise ValueError("Returned identity differs from scheduled method")
                error = base.store_result(db, row, result, config)
                progress.add_method(result, valid=error is None)
                if error:
                    raise ValueError(error)
                if not failed:
                    finalize_admissions(db, config, progress)
                print(base.json_text({"event": "method_finished", "id": row["id"], "method": method,
                                     "d_upper": result.get("d_upper"),
                                     "accepted": sum(progress.counts["accepted_" + b] for b, _, _ in BUCKETS),
                                     "saved_method_results": progress.saved}), flush=True)
            except Exception as error:
                failed = True
                record_error(db, progress, row, method, error)
        state = "failed_partial" if failed else "draining_for_resume" if stopping else "running"
        if time.monotonic() - progress.last_export_monotonic >= export_interval:
            export_snapshot(db, config, progress, output, state)
        else:
            progress.save(output, state)
    if failed:
        return "failed_partial"
    finalize_admissions(db, config, progress)
    return "stopped_by_signal" if STOP_REQUESTED else "wall_budget_reached" if stopping else "batch_complete"


def audit_journal(db, config, replay_candidates=True):
    """Revalidate all raw logical witnesses and replay deterministic admissions."""
    attempts, low, high = db.execute("SELECT COUNT(*),MIN(attempt_index),MAX(attempt_index) FROM attempts").fetchone()
    if attempts and (low != 0 or high != attempts - 1):
        raise ValueError("Attempt journal is not a contiguous prefix")
    counts, frontier = Counter(), False
    for identifier, index, key, payload in db.execute("SELECT * FROM candidates ORDER BY candidate_index"):
        row = base.read_json(payload)
        if identifier != row.get("id") or index != row.get("candidate_index") or key != validate_candidate(row, config, replay_candidates):
            raise ValueError("Saved candidate identity differs from journal")
        if db.execute("SELECT 1 FROM excluded WHERE canonical_key=?", (key,)).fetchone():
            raise ValueError("Candidate overlaps frozen prior populations")
        attempt = db.execute("SELECT outcome,candidate_id FROM attempts WHERE attempt_index=?", (index,)).fetchone()
        if attempt != ("scheduled", identifier):
            raise ValueError("Candidate lacks its scheduled proposal record")
        records = list(db.execute("SELECT method,payload,validated FROM results WHERE candidate_id=?", (identifier,)))
        prepared = base.backend.prepare_code(row)
        for method, raw, valid in records:
            result = base.read_json(raw)
            if not valid or method != result.get("method"):
                raise ValueError("Invalid saved method requires investigation before resume")
            base.strict_validate_result(row, result, config["trials"], config["seed"], prepared)
        admission = db.execute("SELECT candidate_index,outcome,payload FROM admissions WHERE candidate_id=?", (identifier,)).fetchone()
        if admission:
            if frontier or len(records) != len(METHODS) or admission[0] != index:
                raise ValueError("Admission crosses unfinished index frontier")
            label = base.label_for(row, [base.read_json(raw) for _, raw, _ in records], config)
            expected = classify(label["d_upper"], counts, config)
            label["quota_outcome"] = expected
            if admission[1] != expected or base.read_json(admission[2]) != label:
                raise ValueError("Admission differs from full-budget witness/quota replay")
            counts[expected] += 1
        else:
            frontier = True
    scheduled = db.execute("SELECT COUNT(*) FROM attempts WHERE outcome='scheduled'").fetchone()[0]
    if scheduled != db.execute("SELECT COUNT(*) FROM candidates").fetchone()[0]:
        raise ValueError("Scheduled attempts and candidate count differ")
    return counts


def independent_completion_audit(db, config, progress, output):
    if {name: base.sha256_file(HERE / name) for name in SOURCE_FILES} != config["source_hashes"]:
        raise ValueError("Frozen scientific source changed")
    if base.backend.backend_manifest() != config["source"]:
        raise ValueError("Frozen backend manifest changed")
    keys, exclusions = base.initialize_exclusions(output, [])
    if exclusions["keys_sha256"] != config["exclusion_keys_sha256"] or base.sha256_file(
            Path(output) / "exclusions/manifest.json") != config["exclusion_manifest_sha256"]:
        raise ValueError("Frozen exclusion manifest changed")
    if sorted(keys) != [key for key, in db.execute("SELECT canonical_key FROM excluded ORDER BY canonical_key")]:
        raise ValueError("Journal exclusions changed")
    audit_journal(db, config)
    fresh = Progress(db, config)
    if not fresh.target_reached or fresh.invalid or fresh.unresolved or pending_rows(db):
        raise ValueError("Completion requires the mode target, all selected method budgets and zero unresolved errors")
    if config["mode"] == "pilot" and fresh.candidates != config["pilot_count"]:
        raise ValueError("Pilot must complete exactly the frozen candidate count")
    if fresh.saved != len(METHODS) * fresh.candidates or fresh.trials != fresh.saved * config["trials"]:
        raise ValueError("Completion method/trial count differs from full budgets")
    state = "pilot_complete" if config["mode"] == "pilot" else "complete"
    export_snapshot(db, config, fresh, output, state)
    atomic_jsonl(Path(output) / "attempts.jsonl", (dict(attempt_index=i,outcome=o,candidate_id=c,reason=r)
        for i,o,c,r in db.execute("SELECT * FROM attempts ORDER BY attempt_index")))
    names = ("labels.jsonl", "accepted.jsonl", "odd.jsonl", "even_controls.jsonl",
             *(f"accepted_{b}.jsonl" for b, _, _ in BUCKETS),
             "surplus.jsonl", "rejected.jsonl", "candidates.jsonl", "methods.jsonl",
             "errors.jsonl", "attempts.jsonl", "summary.json")
    receipt = {"schema": SCHEMA, "mode": config["mode"],
               "state": "pilot_complete_verified" if config["mode"] == "pilot" else "complete_verified",
               "checked_utc": base.utc_now(),
               "new_labels": sum(fresh.counts.values()),
               "selected_odd_labels": sum(fresh.counts["accepted_"+b] for b, _, _ in ODD_BUCKETS),
               "selected_even_controls": fresh.counts["accepted_control_even"],
               "quotas": config["quotas"], "campaign_quotas_reached": fresh.quotas_reached,
               "searched_codes": fresh.candidates, "method_results": fresh.saved,
               "actual_trials": fresh.trials, "trials_per_method": config["trials"],
               "prior_candidate_overlap": 0, "canonical_duplicates": 0,
               "all_witnesses_verified": True, "is_exact": False,
               "configuration_sha256": hashlib.sha256(base.json_text(config).encode()).hexdigest(),
               "output_sha256": {name: base.sha256_file(Path(output) / name) for name in names}}
    base.write_json(Path(output) / "completion_verified.json", receipt)
    return receipt


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--exclude", action="append", default=[], type=Path)
    parser.add_argument("--mode", choices=("pilot", "campaign"), default="pilot")
    for name, default in (("target_odd_3_5",2000), ("target_odd_7_13",1000),
                          ("target_odd_15_21",800), ("target_odd_23_25",200),
                          ("pilot_count",500), ("trials",10000), ("seed",2026110401),
                          ("workers",4), ("max_candidates",500000), ("max_attempts",50000000),
                          ("ell_min",3), ("ell_max",30), ("m_min",3), ("m_max",30),
                          ("n_min",18), ("n_max",360), ("k_max",0)):
        parser.add_argument("--" + name.replace("_", "-"), type=int, default=default)
    parser.add_argument("--target-control-even", "--target-even", dest="target_control_even", type=int, default=2000)
    parser.add_argument("--structure-weights", type=int, nargs=5, default=[4,2,2,1,1],
                        metavar="W", help="Proposal weights for A4B4 A2B3 A3B4 A4B5 A2B4")
    parser.add_argument("--prepare-workers", type=int)
    parser.add_argument("--batch-size", type=int)
    parser.add_argument("--proposal-batch-size", type=int)
    parser.add_argument("--wall-seconds", type=float, default=580000)
    parser.add_argument("--export-interval-seconds", type=float, default=300)
    parser.add_argument("--allow-disconnected", dest="connected_only", action="store_false", default=True)
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument("--dry-run", action="store_true")
    modes.add_argument("--prepare-only", action="store_true")
    modes.add_argument("--export-only", action="store_true")
    args = parser.parse_args(argv)
    args.prepare_workers = args.workers if args.prepare_workers is None else args.prepare_workers
    args.batch_size = args.workers * 2 if args.batch_size is None else args.batch_size
    args.proposal_batch_size = args.prepare_workers * 8 if args.proposal_batch_size is None else args.proposal_batch_size
    quotas = [getattr(args, "target_" + b) for b, _, _ in BUCKETS]
    if min(quotas) < 0 or (args.mode == "campaign" and sum(quotas) < 1):
        parser.error("Quotas must be nonnegative; campaign requires a positive total")
    if args.trials != 10000:
        parser.error("Exactly 10000 trials per method are required")
    if min(args.pilot_count,args.workers,args.prepare_workers,args.batch_size,args.proposal_batch_size,
           args.max_candidates,args.max_attempts) < 1:
        parser.error("Candidate counts, workers, batches and search caps must be positive")
    required = args.pilot_count if args.mode == "pilot" else sum(quotas)
    if min(args.max_candidates,args.max_attempts) < required:
        parser.error("Search caps must be at least the mode's target")
    if any(not math.isfinite(value) or value <= 0 for value in (args.wall_seconds,args.export_interval_seconds)):
        parser.error("Wall/export intervals must be positive finite numbers")
    allocated = os.environ.get("SLURM_CPUS_PER_TASK")
    if allocated and max(args.workers,args.prepare_workers) > int(allocated):
        parser.error("Workers cannot exceed Slurm allocated CPUs")
    try:
        candidate_for_index(0,args.seed,**{name:getattr(args,name) for name in SAMPLING_FIELDS})
    except ValueError as error:
        parser.error(str(error))
    return args


def main(argv=None):
    global STOP_REQUESTED
    STOP_REQUESTED = False
    args = parse_args(argv)
    if args.dry_run:
        print(base.json_text({"action": "dry_run_no_search", "mode": args.mode, "pilot_count": args.pilot_count, "quotas": {b:getattr(args,"target_"+b) for b,_,_ in BUCKETS},
              "trials_per_method":args.trials,"sampling":{name:getattr(args,name) for name in SAMPLING_FIELDS}}))
        return 0
    output = args.output_dir.expanduser().resolve()
    output.mkdir(parents=True, exist_ok=True)
    if args.export_only and not (output / "state.sqlite3").exists():
        raise ValueError("Export-only requires an existing journal")
    deadline = time.monotonic() + args.wall_seconds
    prior_handlers = {sig: signal.getsignal(sig) for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGUSR1)}
    for sig in prior_handlers:
        signal.signal(sig, request_stop)
    previous_audit = os.environ.get(base.isolation.AUDIT_ENV)
    os.environ[base.isolation.AUDIT_ENV] = str(output / f"execution-isolated-{time.time_ns()}-{os.getpid()}.jsonl")
    try:
        with base.RunLock(output / ".run.lock"):
            keys, exclusions = base.initialize_exclusions(output,args.exclude)
            config = scientific_config(args,output,exclusions)
            db = open_database(output / "state.sqlite3",config,keys)
            progress, state, audit_ok = None, "interrupted", False
            try:
                base.write_json(output / "configuration.json",config)
                print(base.json_text({"event":"audit_saved_journal"}),flush=True)
                audit_journal(db,config)
                audit_ok = True
                progress = Progress(db,config)
                finalize_admissions(db,config,progress)
                export_snapshot(db,config,progress,output)
                if args.prepare_only:
                    if args.mode == "pilot":
                        cap = min(args.max_candidates,args.pilot_count)
                        batch = cap
                    else:
                        extra = 0 if progress.target_reached else max(0,args.batch_size-len(pending_rows(db)))
                        cap = min(args.max_candidates,progress.candidates+extra)
                        batch = args.batch_size
                    # Resume partial preparation, without running heuristic methods.
                    if progress.candidates < cap:
                        with ProcessPoolExecutor(max_workers=args.prepare_workers,
                                mp_context=multiprocessing.get_context("spawn")) as prep_pool:
                            fill_batch(db,config,progress,prep_pool,batch,args.proposal_batch_size,
                                       cap,args.max_attempts,deadline,extend_pending=True)
                    state = ("prepared" if progress.candidates >= cap else
                             "stopped_by_signal" if STOP_REQUESTED else
                             "wall_budget_reached" if time.monotonic() >= deadline else "candidate_limit_reached")
                    export_snapshot(db,config,progress,output,state)
                    return 0 if state == "prepared" else 2
                if args.export_only:
                    state = "exported_incomplete"
                else:
                    with ProcessPoolExecutor(max_workers=args.workers,mp_context=multiprocessing.get_context("spawn"),
                                             initializer=base.isolation.init_outer_worker) as methods_pool:
                        while not progress.target_reached or pending_rows(db):
                            if STOP_REQUESTED or time.monotonic() >= deadline:
                                state = "stopped_by_signal" if STOP_REQUESTED else "wall_budget_reached"
                                break
                            if pending_rows(db):
                                rows = pending_rows(db)
                            else:
                                with ProcessPoolExecutor(max_workers=args.prepare_workers,
                                        mp_context=multiprocessing.get_context("spawn")) as prep_pool:
                                    rows = fill_batch(db,config,progress,prep_pool,args.batch_size,args.proposal_batch_size,
                                                      args.max_candidates,args.max_attempts,deadline)
                            progress.save(output,"running")
                            if not rows:
                                state = ("stopped_by_signal" if STOP_REQUESTED else "wall_budget_reached"
                                         if time.monotonic() >= deadline else "candidate_limit_reached")
                                break
                            state = execute_batch(db,output,config,progress,rows,methods_pool,args.workers,
                                                  deadline,args.export_interval_seconds)
                            if time.monotonic() - progress.last_export_monotonic >= args.export_interval_seconds:
                                export_snapshot(db,config,progress,output,state)
                            else:
                                progress.save(output,"running" if state == "batch_complete" else state)
                            if state != "batch_complete":
                                break
                if progress.target_reached and not pending_rows(db) and not progress.invalid and not progress.unresolved:
                    print(base.json_text(independent_completion_audit(db,config,progress,output)),flush=True)
                    state = "pilot_complete" if config["mode"] == "pilot" else "complete"
                    return 0
                if args.export_only:
                    return 0
                return 1 if state == "failed_partial" else 2
            except BaseException:
                state = "audit_failed" if not audit_ok else "interrupted"
                raise
            finally:
                if audit_ok and progress is not None and state not in ("complete","pilot_complete"):
                    export_snapshot(db,config,progress,output,state)
                db.close()
    finally:
        for sig, handler in prior_handlers.items():
            signal.signal(sig,handler)
        if previous_audit is None:
            os.environ.pop(base.isolation.AUDIT_ENV,None)
        else:
            os.environ[base.isolation.AUDIT_ENV] = previous_audit


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(130)
    except Exception as error:
        print(f"Odd BB campaign failed: {type(error).__name__}: {error}",file=sys.stderr,flush=True)
        raise SystemExit(1)
