#!/usr/bin/env python3
"""Build exact, label-free full-automorphism identities for CSS BB and PBB.

The identity input contains both code specifications and any CSS parent codes
that the dataset preparer wishes to connect. This tool computes identities;
the preparer performs family unions for splitting. Parent membership does NOT
make parent/child distance labels interchangeable. No arbitrary code-isomorphism
claim is made. Numerical Python packages and network access are not needed.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from functools import lru_cache
import hashlib
import itertools
import json
from pathlib import Path
import random
import shutil
import subprocess
import tempfile
import time


HERE = Path(__file__).resolve().parent
SCHEMA = 'bbnet_paper_full_aut_identity_map_v1'
VERSION = 'bb-pbb-exact-full-aut-variable-support-v2'
SCOPE = {'CSS': 'All Aut(Z_ell x Z_m), independent A/B translations, A/B swap, coordinate swap',
         'PBB': 'All Aut(Z_ell x Z_m), common A/B/C/D translation, paired (A,B,C,D)->(B,A,D,C) swap, coordinate swap',
         'limitation': 'Exact declared symmetry orbit; not arbitrary stabilizer-code equivalence. CSS parents are separate inputs and are linked by the dataset preparer, not used to transfer labels.'}


def encode(row):
    return json.dumps(row, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def validate_row(row):
    required = {'canonical_key', 'family', 'ell', 'm', 'A', 'B', 'C', 'D'}
    if not isinstance(row, dict) or set(row) != required:
        raise ValueError('Identity rows must contain exactly canonical_key,family,ell,m,A,B,C,D; no labels')
    if not isinstance(row['canonical_key'], str) or not row['canonical_key']:
        raise ValueError('Nonempty canonical_key required')
    if row['family'] not in ('CSS', 'PBB'):
        raise ValueError('Family must be CSS or PBB')
    ell, m = row['ell'], row['m']
    if (type(ell) is not int or type(m) is not int or not 1 <= ell <= 30
            or not 1 <= m <= 30 or 2 * ell * m > 360):
        raise ValueError('Corpus requires positive integer ell,m <=30 and n<=360')
    for name in 'ABCD':
        value = row[name]
        if not isinstance(value, list) or (name in 'AB' and not value):
            raise ValueError('A/B must be nonempty and all supports must be lists')
        seen = set()
        for point in value:
            if (not isinstance(point, (list, tuple)) or len(point) != 2
                    or any(type(v) is not int for v in point)
                    or not 0 <= point[0] < ell or not 0 <= point[1] < m):
                raise ValueError('Support exponent outside cyclic grid')
            if tuple(point) in seen:
                raise ValueError('Repeated monomials must be reduced modulo two before orbit identification')
            seen.add(tuple(point))
    if (row['family'] == 'PBB') != bool(row['C'] or row['D']):
        raise ValueError('Family differs from perturbation supports')
    return row


def input_line(index, row):
    values = [index, int(row['family'] == 'PBB'), row['ell'], row['m']]
    for name in 'ABCD':
        values.append(len(row[name]))
        values.extend(v for point in row[name] for v in point)
    return ' '.join(map(str, values)) + '\n'


def compile_helper(directory, cxx='clang++'):
    executable = shutil.which(cxx)
    if executable is None:
        raise ValueError(f'C++17 compiler not found: {cxx}')
    binary = Path(directory) / 'orbit_identity'
    command = [executable, '-O3', '-std=c++17', str(HERE / 'orbit_identity.cpp'), '-o', str(binary)]
    subprocess.run(command, check=True, text=True, capture_output=True, timeout=120)
    return binary, command


def calculate_keys(binary, rows):
    output = subprocess.run([str(binary)], input=''.join(input_line(i, row) for i, row in enumerate(rows)),
                            text=True, capture_output=True, check=True)
    result = {}
    for line in output.stdout.splitlines():
        fields = line.split()
        if len(fields) != 5:
            raise ValueError('Malformed C++ identity output')
        index, ell, m, family = map(int, fields[:4])
        if not 0 <= index < len(rows) or index in result:
            raise ValueError('Unexpected or duplicated C++ output index')
        row = rows[index]
        if (ell, m) != tuple(sorted((row['ell'], row['m']))) or family != int(row['family'] == 'PBB'):
            raise ValueError('C++ identity dimensions/family changed')
        key = tuple(map(int, fields[4].split(',')))
        result[index] = (ell, m, family, key)
    if len(result) != len(rows):
        raise ValueError('C++ output does not cover the complete input')
    return [result[index] for index in range(len(rows))]


@lru_cache(maxsize=32)
def reference_maps(ell, m):
    """Independent reference uses explicit bijection, not the C++ GCD test."""
    grid = tuple(itertools.product(range(ell), range(m)))
    maps = []
    for a, b, c, d in itertools.product(range(ell), range(ell), range(m), range(m)):
        if (m * b) % ell or (ell * c) % m:
            continue
        image = tuple(((a*x+b*y) % ell, (c*x+d*y) % m) for x, y in grid)
        if len(set(image)) == ell * m:
            maps.append(dict(zip(grid, image)))
    return maps


def reference_key(row):
    """Small-grid exhaustive reference enumerates EVERY translation."""
    ell, m = row['ell'], row['m']
    supports = [list(map(tuple, row[name])) for name in 'ABCD']
    if ell > m:
        ell, m = m, ell
        supports = [[(y, x) for x, y in support] for support in supports]
    translations = tuple(itertools.product(range(ell), range(m)))
    def translated(support, du, dv):
        return tuple(sorted(((x-du) % ell) * m + ((y-dv) % m) for x, y in support))
    def serial(polys):
        return tuple(v for p in polys for v in (len(p), *p))
    best = None
    for transform in reference_maps(ell, m):
        polys = [[transform[p] for p in support] for support in supports]
        if row['family'] == 'CSS':
            aa, bb = [min(translated(poly, u, v) for u, v in translations) for poly in polys[:2]]
            candidates = (serial((aa, bb, (), ())), serial((bb, aa, (), ())))
        else:
            candidates = []
            for order in ((0, 1, 2, 3), (1, 0, 3, 2)):
                candidates.extend(serial([translated(polys[j], u, v) for j in order])
                                  for u, v in translations)
        value = min(candidates)
        best = value if best is None else min(best, value)
    return ell, m, int(row['family'] == 'PBB'), best


def validation_rows():
    # Pure geometry fixtures, not claimed to be commuting quantum codes.
    rng = random.Random(2026110501)
    rows = []
    cases = [(3, 3, (2, 3, 0, 0)), (3, 4, (4, 4, 0, 0)),
             (4, 3, (3, 4, 0, 0)), (4, 4, (4, 5, 0, 0)),
             (3, 3, (2, 3, 1, 2)), (3, 4, (4, 4, 0, 3)),
             (4, 3, (3, 4, 3, 0)), (4, 4, (4, 5, 5, 4))]
    for index, (ell, m, sizes) in enumerate(cases):
        grid = list(itertools.product(range(ell), range(m)))
        rows.append({'canonical_key': f'reference-fixture-{index}',
                     'family': 'PBB' if any(sizes[2:]) else 'CSS', 'ell': ell, 'm': m,
                     **{name: [list(p) for p in rng.sample(grid, size)] for name, size in zip('ABCD', sizes)}})
    return rows


def validate_reference(binary):
    rows = validation_rows()
    observed = calculate_keys(binary, rows)
    for i, (row, value) in enumerate(zip(rows, observed)):
        expected = reference_key(row)
        if value != expected:
            raise ValueError(f'C++ exact orbit differs from exhaustive reference fixture {i}')
    return {'passed': True, 'exhaustive_cases': len(rows),
            'reference': 'Explicit bijectivity on every lattice site; all group translations, including non-anchor translations; CSS variable supports and one-/two-sided PBB perturbations'}


def orbit_id(key):
    ell, m, family, canonical = key
    # Length-prefixed supports distinguish all variable-size tuples exactly.
    payload = encode([VERSION, ell, m, family, canonical])
    return ('pbbaut-v2-' if family else 'bbaut-v2-') + hashlib.sha256(payload.encode()).hexdigest()


def build(input_path, output_path, *, workers=1, batch_size=1024, cxx='clang++'):
    if type(workers) is not int or workers < 1 or type(batch_size) is not int or batch_size < 1:
        raise ValueError('Positive integer workers and batch_size required')
    started = time.monotonic()
    input_path, output_path = Path(input_path).resolve(), Path(output_path).resolve()
    manifest_path = Path(str(output_path) + '.manifest.json')
    if input_path in (output_path, manifest_path):
        raise ValueError('Derived output must not overwrite the identity input')
    if output_path.exists() or manifest_path.exists():
        raise ValueError('Identity output or manifest already exists; choose a new output path')
    source_hashes = {name: sha(HERE / name) for name in ('orbit_identity.cpp', 'build_orbit_map.py')}
    raw = input_path.read_bytes()
    rows, seen = [], set()
    for number, line in enumerate(raw.splitlines(), 1):
        if not line.strip():
            continue
        row = validate_row(json.loads(line))
        if row['canonical_key'] in seen:
            raise ValueError(f'Duplicate canonical_key at input line {number}')
        seen.add(row['canonical_key'])
        rows.append(row)
    rows.sort(key=lambda row: row['canonical_key'])
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='bb-paper-orbits-') as directory:
        binary, command = compile_helper(directory, cxx)
        reference = validate_reference(binary)
        tasks = [rows[i:i+batch_size] for i in range(0, len(rows), batch_size)]
        output, completed = [], 0
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {pool.submit(calculate_keys, binary, batch): batch for batch in tasks}
            for future in as_completed(futures):
                batch = futures[future]
                keys = future.result()
                output.extend({'canonical_key': row['canonical_key'], 'family': row['family'],
                               'orbit_id': orbit_id(key)} for row, key in zip(batch, keys))
                completed += len(batch)
                print(encode({'event': 'orbit_progress', 'completed': completed, 'total': len(rows)}), flush=True)
        binary_hash = sha(binary)
    if sha(input_path) != hashlib.sha256(raw).hexdigest():
        raise ValueError('Identity input changed during computation')
    if source_hashes != {name: sha(HERE / name) for name in source_hashes}:
        raise ValueError('Helper source changed during computation')
    output.sort(key=lambda row: row['canonical_key'])
    data = ''.join(encode(row) + '\n' for row in output).encode()
    temporary = output_path.with_name(output_path.name + '.tmp')
    temporary.write_bytes(data)
    temporary.replace(output_path)
    manifest = {'schema': SCHEMA, 'identity_version': VERSION,
                'input_sha256': hashlib.sha256(raw).hexdigest(),
                'output_sha256': hashlib.sha256(data).hexdigest(), 'output_count': len(output),
                'scope': SCOPE, 'validation_passed': True, 'reference_validation': reference,
                'helper_source_hashes': source_hashes, 'compiled_binary_sha256': binary_hash,
                'compiler': command[0], 'compiler_flags': ['-O3', '-std=c++17'],
                'workers': workers, 'elapsed_seconds': time.monotonic() - started,
                'old_fixed_three_term_orbit_ids_compatible': False,
                'compatibility_note': 'v2 length-prefixed identities; recompute all inputs including historical reserves.'}
    temporary = manifest_path.with_name(manifest_path.name + '.tmp')
    temporary.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + '\n')
    temporary.replace(manifest_path)
    return manifest


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--workers', type=int, default=1)
    parser.add_argument('--batch-size', type=int, default=1024)
    parser.add_argument('--cxx', default='clang++')
    args = parser.parse_args(argv)
    print(encode(build(args.input, args.output, workers=args.workers,
                       batch_size=args.batch_size, cxx=args.cxx)), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
