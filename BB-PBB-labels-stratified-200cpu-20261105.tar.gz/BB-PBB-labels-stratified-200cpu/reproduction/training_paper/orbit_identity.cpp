// Exact, variable-support orbit identities for CSS BB and PBB specifications.
// CSS: full Aut(Z_l x Z_m), independent A/B shifts, A/B swap, axis swap.
// PBB: full Aut, common A/B/C/D shift, (A,B,C,D)->(B,A,D,C), axis swap.
// This is NOT arbitrary stabilizer-code equivalence, and does not use labels.
// Input: index family(0=CSS,1=PBB) l m, then for each A/B/C/D: size x0 y0 ...
// Output: index normalized_l normalized_m family comma-separated canonical key.
#include <algorithm>
#include <array>
#include <iostream>
#include <map>
#include <numeric>
#include <set>
#include <stdexcept>
#include <vector>

using Polynomial = std::vector<int>;
using Supports = std::array<Polynomial, 4>;
struct Row { long long index; int family; Supports supports; };

Polynomial shifted(const Polynomial& support, int anchor,
                   const std::vector<int>& minus, int n) {
    Polynomial result;
    result.reserve(support.size());
    for (int p : support) result.push_back(minus[p * n + anchor]);
    std::sort(result.begin(), result.end());
    return result;
}

Polynomial translated_minimum(const Polynomial& support,
                             const std::vector<int>& minus, int n) {
    Polynomial best;
    bool first = true;
    // The lexicographically minimal nonempty translation contains the origin.
    for (int anchor : support) {
        auto candidate = shifted(support, anchor, minus, n);
        if (first || candidate < best) { best = std::move(candidate); first = false; }
    }
    return best;
}

Polynomial serialize(const Supports& supports) {
    Polynomial result;
    for (const auto& p : supports) {
        result.push_back(static_cast<int>(p.size()));
        result.insert(result.end(), p.begin(), p.end());
    }
    return result;
}

int main() {
    try {
        std::map<std::pair<int,int>, std::vector<Row>> groups;
        std::set<long long> indices;
        long long index;
        int family, l, m;
        while (std::cin >> index) {
            if (!(std::cin >> family >> l >> m)) throw std::runtime_error("incomplete header");
            if (index < 0 || !indices.insert(index).second) throw std::runtime_error("invalid/duplicate index");
            if ((family != 0 && family != 1) || l < 1 || m < 1 || l > 30 || m > 30 || 2*l*m > 360)
                throw std::runtime_error("unsupported family or lattice");
            Row row{index, family, {}};
            bool swap_axes = l > m;
            for (int j = 0; j < 4; ++j) {
                int count;
                if (!(std::cin >> count) || count < 0 || count > l*m || (j < 2 && count == 0))
                    throw std::runtime_error("invalid support length");
                for (int q = 0; q < count; ++q) {
                    int x, y;
                    if (!(std::cin >> x >> y) || x < 0 || x >= l || y < 0 || y >= m)
                        throw std::runtime_error("invalid exponent");
                    row.supports[j].push_back(swap_axes ? y*l+x : x*m+y);
                }
                auto& p = row.supports[j];
                std::sort(p.begin(), p.end());
                if (std::adjacent_find(p.begin(), p.end()) != p.end())
                    throw std::runtime_error("unreduced repeated support monomial");
            }
            bool perturbed = !row.supports[2].empty() || !row.supports[3].empty();
            if ((family == 1) != perturbed) throw std::runtime_error("family/support mismatch");
            if (swap_axes) std::swap(l,m);
            groups[{l,m}].push_back(std::move(row));
        }
        if (!std::cin.eof()) throw std::runtime_error("unparsed input");
        for (const auto& group : groups) {
            const int l = group.first.first, m = group.first.second, n = l*m, g = std::gcd(l,m);
            std::vector<int> minus(n*n);
            for (int p=0;p<n;++p) for (int q=0;q<n;++q)
                minus[p*n+q] = ((p/m-q/m+l)%l)*m + (p%m-q%m+m)%m;
            std::vector<std::vector<int>> maps;
            for (int a=0;a<l;++a) for (int b=0;b<l;b+=l/g)
            for (int c=0;c<m;c+=m/g) for (int d=0;d<m;++d) {
                // GCD of 2x2 minors tests surjectivity of the integer lattice.
                int divisor = std::gcd(a*d-b*c,l*m);
                for (int value : {a*m,b*m,c*l,d*l}) divisor=std::gcd(divisor,value);
                if (divisor != 1) continue;
                std::vector<int> transform(n);
                std::vector<bool> seen(n,false);
                for (int p=0;p<n;++p) {
                    int q=((a*(p/m)+b*(p%m))%l)*m+(c*(p/m)+d*(p%m))%m;
                    if (seen[q]) throw std::runtime_error("automorphism collision");
                    seen[q]=true; transform[p]=q;
                }
                maps.push_back(std::move(transform));
            }
            if (maps.empty()) throw std::runtime_error("missing identity automorphism");
            for (const auto& row : group.second) {
                Polynomial best;
                bool first = true;
                auto consider = [&](const Supports& polys) {
                    auto candidate=serialize(polys);
                    if (first || candidate < best) { best=std::move(candidate); first=false; }
                };
                for (const auto& f : maps) {
                    Supports transformed;
                    for (int j=0;j<4;++j)
                        for (int p : row.supports[j]) transformed[j].push_back(f[p]);
                    if (row.family == 0) {
                        transformed[0]=translated_minimum(transformed[0],minus,n);
                        transformed[1]=translated_minimum(transformed[1],minus,n);
                        consider(transformed);
                        std::swap(transformed[0],transformed[1]);
                        consider(transformed);
                    } else {
                        for (int swap_register=0;swap_register<2;++swap_register) {
                            for (int anchor : transformed[0]) {
                                Supports translated;
                                for (int j=0;j<4;++j) translated[j]=shifted(transformed[j],anchor,minus,n);
                                consider(translated);
                            }
                            std::swap(transformed[0],transformed[1]);
                            std::swap(transformed[2],transformed[3]);
                        }
                    }
                }
                std::cout << row.index << ' ' << l << ' ' << m << ' ' << row.family << ' ';
                for (size_t i=0;i<best.size();++i) {
                    if (i) std::cout << ',';
                    std::cout << best[i];
                }
                std::cout << '\n';
            }
            std::cerr << "lattice " << l << 'x' << m << " records " << group.second.size()
                      << " automorphisms " << maps.size() << '\n';
        }
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "Orbit identity error: " << error.what() << '\n';
        return 1;
    }
}
