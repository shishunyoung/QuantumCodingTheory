# BB 奇数上界分区间配额 + 稀疏 PBB 标签生成包

默认任务：新增 **2,000 条 BB 奇数上界标签（3–25）**，以及 **2,000 条 PBB 上界标签（2–25）**。这是可移植的标签生成包，上传本身不会启动任务。以下命令均在**新服务器的 Linux 终端**执行。

## 1. 任务范围与默认设置

| 设置 | BB | PBB |
|---|---|---|
| 目标 | 2,000 条新增奇数上界，3–25 | 2,000 条新增有效上界，2–25 |
| 结构 | A4B4 | A3B3，C2D2 / C1D2 / C2D1 |
| CPU 分配 | 100 | 100 |
| 同时搜索的进程数 | 98 | 98 |
| 候选准备进程数 | 8 | 8 |
| 每批候选数 | 200 | 200 |
| 方法与预算 | BP-OSD、QDistRnd、QDistEvol **各 10,000 次** | 相同 |
| 码长限制 | n = 2lm ≤ 360，3 ≤ l,m ≤ 30 | 相同 |

- 两任务合计申请 **200 CPU**，不是各 200。搜索进程内的 BLAS、Numba 等线程数限制为 1；子任务继承各自 CPU 亲和性。
- 一项先完成后，另一项仍保持原 100 CPU 分配，不自动扩容；Slurm 的整份资源申请到两项结束才释放。可在安全停止后重新调整两项 CPU 比例再恢复。
- 使用单节点多进程：200 CPU 必须能在**同一个节点**分配。200 个 CPU 分散在多节点时，需要另做分片启动配置。CPU 数按操作系统/Slurm 分配的 CPU 槽位计，不承诺都是独立物理核心。
- 不需要 GPU、CUDA、PyTorch、MILP 商业许可证。需要 Linux、Python 3.12、C++17 编译器和 requirements 中的数值库。
- 安装器优先用已有 Conda 创建本目录 `.env`；无 Conda 时可用已有 Python 3.12 + venv + C++17 编译器。安装需要访问 conda-forge/PyPI；本包不是离线依赖包。
- 默认启动检查按 **196 × 2 + 8 = 400 GiB** 可用内存规划；Slurm 默认申请 **408G**。这是保守、可配置的规划门槛，**不是实测最低需求或内存峰值保证**。内存不足时先减少并行数，或测量实际峰值后再调整门槛。
- 默认最多 1,000 批作为防失控上限。若达到上限仍未凑足，返回非零状态并保留数据；可以调大 `MAX_BATCHES` 后恢复。不会把不足 2,000 条伪报为完成。

## 2. 上传与安装

### 本版 BB 配额

这版把 BB 的 2,000 条合格奇数上界标签分成四档：

| 奇数上界 U | 包含的奇数 | 标签配额 |
|---|---|---:|
| 3–7 | 3、5、7 | 400 |
| 9–13 | 9、11、13 | 600 |
| 15–19 | 15、17、19 | 600 |
| 21–25 | 21、23、25 | 400 |

在首次启动前编辑 `settings.env`：

```bash
BB_TARGET=2000
BB_ODD_QUOTAS="400 600 600 400"
```

四个数是**最终标签数配额**，不是候选采样权重，之和必须等于 `BB_TARGET`。例如四档各 500 条可以改成 `"500 500 500 500"`。设置 `BB_ODD_QUOTAS=none` 可显式关闭分档，仅按原来的奇数上界总数目标收集。PBB 仍为 2,000 条 U=2–25 标签，不受这四档配额影响。

程序先完整运行三种方法各 10,000 次、复核逻辑算符，再对等价码取全部已知有效上界的最小值，最后分档计数。不会保留一个更松的上界来满足配额。例如先得到 U=21，后来同一轨道有 U=19，就按 19 重新计数，并继续补齐高档缺口。

一个区间收满后，继续搜索时产生的同区间标签会保存为富余结果，不能抵扣其他区间。四档全部收满才报告完成；即使低档已经有 2,000 条，高档未满也不会提前停止。高档可能稀少，达到 `MAX_BATCHES` 后仍不足时会明确报告未完成并保留所有结果。

这里保证的是**各区间总数**，不保证同一档内每个具体奇数都有固定数量，也不能保证高上界对应高真实码距。搜索后筛选会改变采样分布，适合当前补缺口实验，但不等于作者原始数据的自然分布；独立测试集需要另行规划。

**本版使用新目录，旧版压缩包保持不变。若旧包已启动，不要覆盖其代码或配置，也不要直接同时启动新旧两个版本。** 当前新版不自动导入旧运行的结果；先保留旧目录，迁移时可以复用已完成的搜索证据。不要直接把旧 `runs/` 复制进新目录绕过配置校验。

上传 `BB-PBB-labels-stratified-200cpu-20261105.tar.gz` 到新服务器的工作目录，然后：

```bash
tar -xzf BB-PBB-labels-stratified-200cpu-20261105.tar.gz
cd BB-PBB-labels-stratified-200cpu
cp scripts/settings.env.example settings.env
bash scripts/install_env.sh
```

如果通过 VS Code 上传了已经解压的整个文件夹，只需进入 `BB-PBB-labels-stratified-200cpu`，跳过 tar 命令。`settings.env` 只在首次配置时复制，恢复任务不要覆盖它。

安装脚本固定使用 requirements 中的版本，检查依赖冲突、后端导入以及 C++ 身份计算。**安装过程不运行码距搜索。** 不要另外 `pip install codedistance`：已打包并校验指定版本的源代码。

管理员配置过 Conda 时，如果 `conda` 未出现在命令路径中，请先按管理员说明加载它，例如 `module load ...` 或激活其已有环境脚本。Conda 的目录环境用法见 [Conda 官方说明](https://docs.conda.io/projects/conda/en/latest/user-guide/tasks/manage-environments.html)。

没有 Conda 但已经有 Python 3.12 和 g++ 时，安装器会创建 venv。若两者都没有，可让管理员提供，或按 [Miniforge 官方安装说明](https://github.com/conda-forge/miniforge#install)安装适合服务器架构的发行版，再运行本包安装器。包不会自动修改系统软件，也不会在你的 Mac 上安装数值库。

## 3. 确认启动方式

先查看环境：

```bash
lscpu
free -h
command -v sbatch || true
```

`sbatch` 存在说明可以继续检查 Slurm；命令不存在不等于允许直接在登录节点跑计算，集群可能需要先加载模块或采用其他调度系统。按服务器管理员规定选择下面**一种**方式，不要同时启动两种。

### A. 使用 Slurm 的服务器

查看分区，再编辑 `settings.env` 中的 `SLURM_PARTITION`，以及管理员要求的 ACCOUNT / QOS / TIME：

```bash
sinfo -o '%P %a %l %D %c %m'
nano settings.env
bash scripts/submit_slurm.sh
squeue -u "$USER"
```

提交脚本会申请 `--nodes=1 --ntasks=1 --cpus-per-task=200 --mem=408G`，不申请 GPU。默认时限 7 天，必须按分区实际上限调整。资源检查在获配的计算节点内进行，不使用登录节点的空闲 CPU 作为授权依据。

`submit_slurm.sh` 返回作业号表示提交成功，**不表示已经运行**：`PD` 是排队，`R` 才是运行。见 [Slurm sbatch 官方说明](https://slurm.schedmd.com/sbatch.html)。

### B. 无调度器、已分配给你的普通 Linux 服务器

```bash
bash scripts/run_local.sh
```

启动前自动检查分配/可见的 CPU、内存、文件完整性和依赖，之后在后台运行。正常 SSH 断开不会停止这个后台任务；若平台会在用户退出时清理整个会话，则需使用平台支持的持久作业方式。实际启动情况以状态和日志为准。

## 4. 查看进度与结果

```bash
.env/bin/python scripts/status.py
tail -n 40 logs/bb.log
tail -n 40 logs/pbb.log
```

也可每 60 秒刷新状态：

```bash
watch -n 60 .env/bin/python scripts/status.py
```

重点字段：

- `selected_labels`：已完成全预算、复核、去重并满足范围的新增标签数；分别以 2,000 为目标。
- `remaining_labels`：还差多少条目标标签。
- `searched_codes_in_completed_batches`：已审计完整批次实际搜索的码数，通常比目标标签数大。
- `active_batch.child_summary`：当前批次的进度。首批尚未完成时，顶层 `selected_labels=0` 不代表没有计算。
- `selected_upper_histogram`：当前选中标签的上界分布。
- `bb_odd_bins`：BB 各区间的目标、已选、剩余、可用及富余数；`bb_odd_quotas_complete` 表示各档是否全部收满。
- `complete_verified`：达到标签目标且完成复核。`max_batches_reached`、`child_failed_partial` 都不代表完成。

最终结果：

| 文件 | 内容 |
|---|---|
| `runs/bb/selected_labels.jsonl` | 2,000 条新增 BB 奇数上界标签 |
| `runs/pbb/selected_labels.jsonl` | 2,000 条新增 PBB 范围内上界标签 |
| `runs/bb/bb_even_labels.jsonl` | BB 搜索中同时得到的偶数上界原始标签 |
| `runs/<family>/all_labels.jsonl` | 所有已完成批次的标签，包括重复、范围外、额外标签 |
| `runs/<family>/selection_audit.jsonl` | 每个标签的选中/排除原因 |
| `runs/<family>/full_aut_rejected_labels.jsonl` | 因既有码、等价码、保留母码等原因未计入目标的记录 |
| `runs/<family>/batches/batch-XXXX/methods.jsonl` | 每个方法的预算、输出逻辑算符和独立验证记录 |
| `runs/<family>/completion_verified.json` | 最终完成证明性记录及各文件校验值；不是数学码距精确性证明 |

训练请优先使用最终 `selected_labels.jsonl`；`all_labels` 和偶数文件是保留的原始集合，不能不去重就全部混入训练。对训练/验证/测试仍须按等价码及 PBB 母码关系分组划分。

## 5. 暂停和恢复

普通 Linux 安全暂停：

```bash
bash scripts/stop_local.sh
```

Slurm 安全暂停，替换实际作业号：

```bash
scancel --signal=USR1 --batch 作业号
```

安全暂停会让两项任务**完成各自当前整批候选后**退出。每批默认 200 个码，可能还需要数小时；发送信号后不会立即释放 CPU。`status.py` 中的 `draining` / `stopping_after_batch` 表示正在收尾。

Slurm 硬时限/管理员强制终止仍可能中断当前方法。已写入的候选和方法结果保存在 SQLite 中；恢复会补做缺失方法，不能保证保留尚未落盘的一次方法调用。提交脚本在时限前一小时发暂停信号是尽力收尾，不能保证一小时内完成当前批次。

确认前一进程/作业已退出后，在同一路径、同一配置下再次运行原启动命令即可恢复：

```bash
# 普通服务器
bash scripts/run_local.sh
# 或 Slurm
bash scripts/submit_slurm.sh
```

运行后不要移动项目路径、修改算法源码、排除文件、随机种子、批量大小、标签目标或分档配额。配置与源码哈希会拒绝不一致的恢复。CPU/准备进程数和 `MAX_BATCHES` 可以在停止后调整。

## 6. 内存或单节点 CPU 不够时

只改 `settings.env`，不要改源代码。例如先以总计 96 CPU 运行：

```bash
TOTAL_CPUS=96
BB_CPUS=48
PBB_CPUS=48
SLURM_MEMORY=200G
```

每项 46 个搜索进程，总内存规划为 `92×2+8=192 GiB`。`BB_CPUS+PBB_CPUS` 必须等于 `TOTAL_CPUS`。先测量实际进程峰值，再决定是否提高并行度；单凭 CPU 数量不能推断内存是否足够。

## 7. 标签含义、复现口径与排除数据

每个码都完整运行三种方法，各 10,000 次。对返回逻辑算符独立验证与稳定子的对易性、非平凡性和物理重量，再取有效上界的最小值。PBB 的 Y 在同一物理位置只计一次重量。保留后端原始数字和经过验证的物理重量，不能把二者混为一谈。

**奇数上界不是已证明的奇数真实码距；上界标签不是 MILP 精确标签。** 进一步搜索仍可能降低上界。相同 full-Aut 轨道的所有已计算标签先取已知最小值，再判断是否落在目标范围；不能因较松上界是奇数就保留它计数。

BB 使用 A4B4 补结构与奇数上界；PBB 通过稀疏交换条件 `AC^T + CA^T = BD^T + DB^T` 匹配 C/D，要求两边非零并重新检查 k>0、对易性和非 CSS 性。C1D2 与 C2D1 属于配对交换的同一无序结构，不单独设配额。这里沿用已固定的 codeDistance 后端与预算口径，**候选采样器是我们实现的扩展，不等于已复现作者未公开的完整采样分布**。

后端仓库：`https://github.com/m-webster/codeDistancePYPI`，commit `a4afe9c09bbf5790da9ecc05b65c5b62343979ad`。依赖固定在 `reproduction/requirements-bb-distance.txt`；vendored 源码、上游版本、许可证和导入兼容补丁见 `reproduction/vendor/codedistance-a4afe9c/`。不改启发式算法/停止规则。种子、方法参数和来源会记录，但上游 BP-OSD 随机性不保证跨平台逐位相同。

历史排除快照采集始于 **2026-11-05 15:49:46（北京时间）**，含已完成和待计算候选：

- 105,748 个 CSS BB 构造，包括旧 A4B4 试跑的全部 500 个；对应 56,298 个声明对称范围下的轨道。
- 10,100 个 PBB 构造；对应 9,928 个轨道。
- 10,338 个保留 CSS 母码轨道，用于隔离既有精确数据及已冻结测试集的相关结构。

去重覆盖群自同构、声明的平移/交换/坐标交换；不声称识别所有稳定子码等价。PBB 的母码只用于分组与排除，不把母码的码距当成子码标签。排除快照之后在其他服务器新增的码仍需在最终合并时再次去重。

## 8. 包的检查范围

包提供文件哈希校验和不依赖数值库的独立检查：

```bash
python3 scripts/test_package_contract.py
python3 scripts/test_portable.py
```

构包时验证了依赖闭包、全量排除构造身份、轨道参考实现、调度脚本、见证/预算拒收回归，以及两类候选准备与续跑入口。未在未知的新服务器上安装环境、运行 10,000 次搜索或实测 200 核性能；新服务器的后端导入和资源检查会在安装/启动时进行。
