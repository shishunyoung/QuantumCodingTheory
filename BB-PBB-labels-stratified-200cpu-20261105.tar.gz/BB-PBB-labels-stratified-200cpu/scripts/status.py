#!/usr/bin/env python3
"""Read concise local journals; never connect, submit, or execute a search."""
import json
from pathlib import Path
from check_environment import package_root

def main():
    root=package_root();report={}
    control=root/'run_control/supervisor_status.json'
    report['supervisor']=json.loads(control.read_text()) if control.exists() else {'state':'not_started_or_preflight_pending'}
    for family in ('bb','pbb'):
        path=root/'runs'/family/'summary.json'
        if not path.exists():report[family]={'state':'not_started'};continue
        source=json.loads(path.read_text())
        keys=('state','updated_utc','family','target_labels','selected_labels','remaining_labels',
              'qualifying_labels','completed_batches','searched_codes_in_completed_batches',
              'even_labels_retained','selected_upper_histogram','bb_odd_quotas',
              'bb_odd_quotas_complete','bb_odd_bins','active_batch','progress_note')
        report[family]={k:source[k] for k in keys if k in source}
        if len(report[family])<2:report[family]=source
    print(json.dumps(report,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
