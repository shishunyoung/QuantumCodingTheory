#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "$0")/common.sh"
[[ -x "$LABEL_PYTHON" ]] || { echo 'Python environment missing; run bash scripts/install_env.sh or set LABEL_PYTHON.' >&2; exit 1; }
[[ -z "${SLURM_JOB_ID:-}" ]] || { echo 'Inside Slurm use the foreground job launcher, not local detached mode.' >&2; exit 1; }
exec "$LABEL_PYTHON" "$SCRIPT_DIR/supervisor.py" --detach
