#!/usr/bin/env python3
"""Independent portable-archive audit; standard library only, no distance search.

Run from an extracted archive: python3 scripts/test_package_contract.py.
The optional --package-root lets the repository copy check a separate archive.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest


ROOT = None


def locate_root():
    if ROOT is not None:
        return ROOT
    here = Path(__file__).resolve().parent
    for candidate in (here.parent, here.parent.parent):
        if (candidate / 'reproduction').is_dir():
            return candidate
    raise RuntimeError('Cannot locate reproduction directory')


class PackageContract(unittest.TestCase):
    def setUp(self):
        self.root = locate_root()
        self.reproduction = self.root / 'reproduction'
        self.manifest_path = self.root / 'package_manifest.json'

    def packaged_manifest(self):
        if not self.manifest_path.exists():
            self.skipTest('Package-only check: source tree has no package_manifest.json')
        manifest = json.loads(self.manifest_path.read_text())
        self.assertIsInstance(manifest.get('files'), dict)
        self.assertTrue(manifest['files'])
        return manifest['files']

    def isolated_python(self, source, *arguments, timeout=120):
        # -I -S and a fresh cwd prohibit site packages, cwd imports and PYTHONPATH.
        # Only this explicitly named archive is inserted into sys.path.
        with tempfile.TemporaryDirectory(prefix='bb-pbb-contract-') as directory:
            result = subprocess.run(
                [sys.executable, '-I', '-S', '-B', '-c', source,
                 str(self.reproduction), *map(str, arguments)],
                cwd=directory, capture_output=True, text=True, timeout=timeout,
            )
        self.assertEqual(result.returncode, 0, result.stdout + '\n' + result.stderr)
        return result.stdout

    def test_closed_dependency_tree_and_frozen_backends(self):
        source = '''
import importlib, json, pathlib, sys
root = pathlib.Path(sys.argv[1]).resolve()
sys.path.insert(0, str(root))
modules = [
    'run_label_extension_targets',
    'generate_bb_odd_bound_campaign', 'generate_bb_distance_10000_trials',
    'generate_bb_distance_dataset', 'bb_odd_bound_candidates',
    'bb_distance_candidates', 'bb_code_algebra', 'bb_distance_backend',
    'run_bb_distance_isolated', 'generate_pbb_sparse_campaign',
    'generate_pbb_distance_campaign', 'generate_pbb_distance_dataset',
    'pbb_sparse_candidates', 'pbb_distance_candidates', 'pbb_code_algebra',
    'pbb_distance_backend', 'run_pbb_distance_isolated',
    'training_paper.build_orbit_map',
]
loaded = {name: importlib.import_module(name) for name in modules}
for name, module in loaded.items():
    assert pathlib.Path(module.__file__).resolve().is_relative_to(root), name
expected = 'a4afe9c09bbf5790da9ecc05b65c5b62343979ad'
assert loaded['bb_distance_backend'].SOURCE_COMMIT == expected
bb = loaded['bb_distance_backend'].backend_manifest()
pbb = loaded['pbb_distance_backend'].backend_manifest()
assert loaded['run_label_extension_targets'].TRIALS == 10000
assert len(loaded['run_label_extension_targets'].METHODS) == 3
assert not {'numpy', 'torch', 'scipy', 'numba'} & sys.modules.keys()
print(json.dumps({'modules': len(loaded), 'commit': expected,
                  'searches_executed': 0, 'backend_manifest_checks': 2}))
'''
        self.isolated_python(source)

    def test_every_manifest_entry_is_safe_and_unchanged(self):
        entries = self.packaged_manifest()
        for name, metadata in entries.items():
            with self.subTest(path=name):
                relative = Path(name)
                self.assertFalse(relative.is_absolute())
                self.assertNotIn('..', relative.parts)
                self.assertNotIn('.ssh', relative.parts)
                self.assertNotIn('.git', relative.parts)
                self.assertNotIn('__pycache__', relative.parts)
                self.assertNotIn('.env', relative.parts)
                self.assertNotIn(relative.suffix, {'.pyc', '.sqlite3', '.pem'})
                source = self.root / relative
                self.assertTrue(source.resolve().is_relative_to(self.root.resolve()))
                self.assertTrue(source.is_file())
                self.assertFalse(source.is_symlink())
                self.assertEqual(source.stat().st_size, metadata['bytes'])
                self.assertEqual(hashlib.sha256(source.read_bytes()).hexdigest(), metadata['sha256'])

    def test_packaged_inventory_includes_all_runtime_and_input_files(self):
        entries = self.packaged_manifest()
        required = {
            'README.zh-CN.md', 'reproduction/requirements-bb-distance.txt',
            'reproduction/run_label_extension_targets.py',
            'reproduction/training_paper/build_orbit_map.py',
            'reproduction/training_paper/orbit_identity.cpp',
            'reproduction/vendor/codedistance-a4afe9c/SOURCE.json',
            'reproduction/vendor/codedistance-a4afe9c/LICENSE',
            'inputs/bb_exclusions.jsonl', 'inputs/pbb_exclusions.jsonl',
            'inputs/prior_bb_orbits.jsonl', 'inputs/prior_pbb_orbits.jsonl',
            'inputs/reserved_parent_orbits.jsonl',
        }
        required.update('scripts/' + name for name in (
            'common.sh', 'install_env.sh', 'check_environment.py', 'supervisor.py',
            'run_local.sh', 'stop_local.sh', 'submit_slurm.sh', 'job.sbatch',
            'settings.env.example', 'status.py', 'test_package_contract.py',
        ))
        self.assertFalse(required - entries.keys(), sorted(required - entries.keys()))
        for folder in ('reproduction', 'inputs', 'scripts'):
            for source in (self.root / folder).rglob('*'):
                if source.is_file() and '__pycache__' not in source.parts:
                    self.assertIn(str(source.relative_to(self.root)), entries)

    def test_version_pins_are_cpu_only_and_complete(self):
        requirements = self.reproduction / 'requirements-bb-distance.txt'
        lines = [line.strip() for line in requirements.read_text().splitlines()
                 if line.strip() and not line.lstrip().startswith('#')]
        expected = {
            'numpy': '2.2.6', 'scipy': '1.16.2', 'numba': '0.62.1',
            'llvmlite': '0.45.1', 'ldpc': '2.3.10', 'stim': '1.16.0',
            'sinter': '1.16.0', 'pymatching': '2.4.0',
        }
        self.assertEqual(dict(line.split('==') for line in lines), expected)

    def test_selection_uses_tightest_known_orbit_bound_before_odd_quota(self):
        # A candidate budget is not a label quota. More subtly, an equivalent
        # code with a known even U=4 must disqualify its older odd U=5 from an
        # odd-only target; selecting the looser value would bias that target.
        source = '''
import sys
sys.path.insert(0, sys.argv[1])
from run_label_extension_targets import select_labels
def selection(family, values, prior=(), reserved=()):
    rows = [dict(id=str(i), canonical_key=str(i), d_upper=value)
            for i, (value, own, parent) in enumerate(values)]
    identities = [dict(id=str(i), canonical_key=str(i), orbit_id=own,
                       parent_css_orbit_id=parent)
                  for i, (value, own, parent) in enumerate(values)]
    return select_labels(dict(family=family, target_labels=2), rows,
                         identities, set(prior), set(reserved))[0]
assert selection('bb', [(5, 'a', 'x'), (4, 'a', 'x')]) == []
assert [r['d_upper'] for r in selection('bb', [(7, 'a', 'x'), (5, 'a', 'x')])] == [5]
assert selection('pbb', [(2, 'a', 'x'), (1, 'a', 'x')]) == []
values = [(3, 'old', 'x'), (5, 'new', 'heldout'), (7, 'fresh', 'free')]
result = selection('bb', values, prior=['old'], reserved=['heldout'])
assert len(result) == 1 and result[0]['d_upper'] == 7
assert selection('bb', [(2, 'a', 'x'), (26, 'b', 'x')]) == []
'''
        self.isolated_python(source)

    def test_bb_strict_bin_quotas_and_tighter_orbit_moves_between_bins(self):
        source = '''
import pathlib, sys, tempfile
sys.path.insert(0, sys.argv[1])
from run_label_extension_targets import select_labels, export_aggregate
config = dict(family='bb', target_labels=4, bb_odd_quotas=[1,1,1,1],
              dedup_scope='synthetic-test-only')
def data(values):
    rows = [dict(id=str(i), canonical_key=str(i), d_upper=value)
            for i, (value, own) in enumerate(values)]
    identities = [dict(id=str(i), canonical_key=str(i), orbit_id=own,
                       parent_css_orbit_id='free-parent')
                  for i, (value, own) in enumerate(values)]
    return rows, identities
def selected(values):
    rows, identities = data(values)
    qualifying, decisions = select_labels(config, rows, identities, set(), set())
    chosen = {d['id'] for d in decisions if d['selection_outcome'] == 'selected'}
    return [r['d_upper'] for r in qualifying if r['id'] in chosen], decisions
# Surplus low-bin labels never replace a missing higher-bin requirement.
values = [(value, str(value)) for value in (3,5,7,9,11,13,15,17,19,21,23,25)]
chosen, decisions = selected(values)
assert chosen == [3,9,15,21], chosen
assert sum(d['selection_outcome'] == 'quota_full' for d in decisions) == 8
# The same code's improved bound changes its bin. Recompute the quota from
# the tightest true representative, allowing a former surplus code to enter.
before = [(3,'low'), (5,'low-surplus'), (9,'mid'), (21,'moving'), (23,'high')]
chosen, _ = selected(before)
assert chosen == [3,9,21], chosen
after = before + [(17,'moving')]
chosen, _ = selected(after)
assert sorted(chosen) == [3,9,17,23], chosen
# A further even bound must retract that orbit from the odd target entirely.
after_even = after + [(16,'moving')]
chosen, _ = selected(after_even)
assert sorted(chosen) == [3,9,23], chosen
for values, complete, count in ((before,False,3), (after,True,4), (after_even,False,3)):
    rows, identities = data(values)
    with tempfile.TemporaryDirectory(prefix='bb-bin-contract-') as directory:
        summary = export_aggregate(pathlib.Path(directory), config, [], rows,
            'fixture', identities=identities, prior=set(), reserved=set())
        assert summary['selected_labels'] == count
        assert summary['target_complete'] is complete
        assert summary['bb_odd_quotas_complete'] is complete
        for key in ('3_7','9_13','15_19','21_25'):
            assert summary['bb_odd_bins'][key]['selected'] <= 1
'''
        self.isolated_python(source)

    def test_frozen_exclusions_cover_completed_a4b4_pilot(self):
        self.packaged_manifest()
        rows = [json.loads(line) for line in (self.root / 'inputs/bb_exclusions.jsonl').read_text().splitlines()
                if line.strip()]
        a4b4 = [row for row in rows if len(row['A']) == len(row['B']) == 4]
        # Job 266 searched 500 candidates, all must remain excluded, not only
        # the 189 eligible odd labels or 214 odd bounds of any size.
        self.assertGreaterEqual(len({row['canonical_key'] for row in a4b4}), 500)
        for filename, prefix in (
            ('prior_bb_orbits.jsonl', 'bbaut-v2-'),
            ('prior_pbb_orbits.jsonl', 'pbbaut-v2-'),
            ('reserved_parent_orbits.jsonl', 'bbaut-v2-'),
        ):
            values = [json.loads(line)['orbit_id'] for line in (self.root / 'inputs' / filename).read_text().splitlines()
                      if line.strip()]
            self.assertTrue(values, filename)
            self.assertTrue(all(value.startswith(prefix) for value in values), filename)

    def test_full_aut_cpp_matches_independent_reference(self):
        compiler = os.environ.get('CXX') or shutil.which('g++') or shutil.which('clang++')
        if not compiler:
            self.skipTest('No C++17 compiler in this audit environment')
        source = '''
import json, pathlib, sys, tempfile
sys.path.insert(0, sys.argv[1])
from training_paper.build_orbit_map import compile_helper, validate_reference
with tempfile.TemporaryDirectory(prefix='bb-pbb-contract-cpp-') as directory:
    binary, command = compile_helper(directory, cxx=sys.argv[2])
    result = validate_reference(binary)
    assert result['passed'] is True
    assert result['exhaustive_cases'] >= 8
    print(json.dumps(result))
'''
        self.isolated_python(source, compiler, timeout=180)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--package-root', type=Path)
    arguments, remaining = parser.parse_known_args()
    ROOT = arguments.package_root.resolve() if arguments.package_root else None
    unittest.main(argv=[sys.argv[0], *remaining])
