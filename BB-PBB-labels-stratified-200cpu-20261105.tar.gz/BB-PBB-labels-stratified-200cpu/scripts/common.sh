#!/usr/bin/env bash
# Shared path/settings resolution. Source only from this package's scripts.
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if [[ -d "$SCRIPT_DIR/../reproduction" ]]; then
    PACKAGE_ROOT="$(cd -- "$SCRIPT_DIR/.." && pwd)"
elif [[ -d "$SCRIPT_DIR/../../reproduction" ]]; then
    PACKAGE_ROOT="$(cd -- "$SCRIPT_DIR/../.." && pwd)"
else
    echo 'Cannot locate package reproduction directory.' >&2
    return 1
fi
if [[ -f "$PACKAGE_ROOT/settings.env" ]]; then
    set -a
    # This is a user-controlled shell configuration file, not downloaded code.
    source "$PACKAGE_ROOT/settings.env"
    set +a
fi
LABEL_PYTHON="${LABEL_PYTHON:-$PACKAGE_ROOT/.env/bin/python}"
export PACKAGE_ROOT LABEL_PYTHON
export PYTHONUNBUFFERED=1 PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export NUMBA_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 BLIS_NUM_THREADS=1
export NUMBA_CACHE_DIR="${NUMBA_CACHE_DIR:-$PACKAGE_ROOT/cache/numba}"
export TMPDIR="${LABEL_TMPDIR:-$PACKAGE_ROOT/tmp}"
mkdir -p "$PACKAGE_ROOT/logs" "$PACKAGE_ROOT/run_control" "$NUMBA_CACHE_DIR" "$TMPDIR"
if [[ -z "${CXX:-}" ]]; then
    CXX="$(command -v g++ || command -v clang++ || true)"
    if [[ -z "$CXX" ]]; then
        for candidate in "$PACKAGE_ROOT/.env/bin/"*-conda-linux-gnu-c++; do
            if [[ -x "$candidate" ]]; then CXX="$candidate"; break; fi
        done
    fi
    export CXX
fi
