"""Launcher checks use mocks/temp directories; never install or launch solvers."""
import hashlib
import json
import os
from pathlib import Path
import signal
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import check_environment as check
import supervisor


class PortableTests(unittest.TestCase):
    def simulate_installer(self, *, python=True, compiler=True, conda=False):
        """Execute shell routing against fake commands, with no real installs."""
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);scripts=root/'scripts';scripts.mkdir();(root/'reproduction').mkdir()
            fake=root/'fakebin';fake.mkdir();log=root/'commands.log'
            for name in ('install_env.sh','common.sh'):
                shutil.copyfile(HERE/name,scripts/name)
            for name in ('dirname','mkdir'):(fake/name).symlink_to(shutil.which(name))
            def executable(name,text):
                path=fake/name;path.write_text('#!/bin/bash\n'+text);path.chmod(0o755);return path
            executable('uname','echo Linux\n')
            runtime=executable('runtime', '''printf 'python %s\\n' "$*" >> "$TEST_INSTALL_LOG"
if [[ "$1" == -m && "$2" == venv ]]; then
    /bin/mkdir -p "$3/bin"
    /bin/cp "$0" "$3/bin/python"
fi
''')
            cxx=executable('compiler','exit 0\n')
            if python:(fake/'python3.12').symlink_to(runtime)
            if compiler:(fake/'g++').symlink_to(cxx)
            if conda:
                executable('conda','''printf 'conda %s\\n' "$*" >> "$TEST_INSTALL_LOG"
operation="$1"
while [[ "$#" -gt 0 ]]; do
    if [[ "$1" == -p ]]; then prefix="$2"; shift; fi
    shift
done
if [[ "$operation" == create ]]; then
    /bin/mkdir -p "$prefix/bin" "$prefix/conda-meta"
    /bin/cp "$TEST_RUNTIME_BIN" "$prefix/bin/python"
else
    /bin/ln -s "$TEST_COMPILER_BIN" "$prefix/bin/x86_64-conda-linux-gnu-c++"
fi
''')
            env={'PATH':str(fake),'TEST_INSTALL_LOG':str(log),
                 'TEST_RUNTIME_BIN':str(runtime),'TEST_COMPILER_BIN':str(cxx)}
            result=subprocess.run(['/bin/bash',str(scripts/'install_env.sh')],env=env,capture_output=True,text=True)
            return result,log.read_text() if log.exists() else '',(root/'.env').exists()

    def test_installer_venv_fallback_without_conda(self):
        result,commands,created=self.simulate_installer()
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertTrue(created)
        self.assertIn('-m venv',commands)
        self.assertIn('-m pip check',commands)
        self.assertNotIn('conda ',commands)

    def test_installer_missing_prerequisites_fail_before_creating_environment(self):
        for options in ({'python':False},{'compiler':False}):
            result,commands,created=self.simulate_installer(**options)
            self.assertNotEqual(result.returncode,0)
            self.assertFalse(created)
            self.assertIn('administrator',result.stderr)
            self.assertNotIn('-m pip install',commands)

    def test_installer_conda_uses_only_conda_forge_and_installs_compiler(self):
        result,commands,created=self.simulate_installer(python=False,compiler=False,conda=True)
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertTrue(created)
        conda_commands=[line for line in commands.splitlines() if line.startswith('conda ')]
        self.assertEqual(len(conda_commands),2)
        for command in conda_commands:
            self.assertIn('--override-channels -c conda-forge --strict-channel-priority',command)
        self.assertIn('cxx-compiler',commands)

    def test_default_cpu_budgets_memory_and_prepare_limit(self):
        with patch.dict(os.environ,{},clear=True):plan=check.resource_plan()
        self.assertEqual(plan['total_cpus'],200)
        self.assertEqual(plan['workers'],{'bb':98,'pbb':98})
        self.assertEqual(plan['planned_memory_gib'],400)
        with patch.dict(os.environ,{'TOTAL_CPUS':'16','BB_CPUS':'8','PBB_CPUS':'8'},clear=True):
            self.assertEqual(check.resource_plan()['workers'],{'bb':6,'pbb':6})
        for settings in ({'TOTAL_CPUS':'199'}, {'WORKER_RESERVE':'100'}, {'MEMORY_GIB_PER_WORKER':'nan'}):
            with patch.dict(os.environ,settings,clear=True),self.assertRaises(ValueError):check.resource_plan()

    def test_resource_failures_do_not_silently_reduce_or_oversubscribe(self):
        with patch.dict(os.environ,{},clear=True):plan=check.resource_plan()
        snapshot={'effective_cpus':200,'available_memory_bytes':420*check.GIB,'disk_free_bytes':20*check.GIB}
        with patch.object(sys,'platform','linux'):check.enforce_resources(plan,snapshot)
        for changed in ({'effective_cpus':199},{'available_memory_bytes':399*check.GIB},{'disk_free_bytes':1}):
            with patch.object(sys,'platform','linux'),self.assertRaises(RuntimeError):
                check.enforce_resources(plan,{**snapshot,**changed})

    def test_package_integrity_detects_tampering(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);data=b'original';(root/'file').write_bytes(data)
            (root/'package_manifest.json').write_text(json.dumps({'files':{'file':{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}}}))
            with patch.object(check,'package_root',return_value=root):
                self.assertEqual(check.verify_package()['state'],'verified')
                (root/'file').write_bytes(b'changed!')
                with self.assertRaises(RuntimeError):check.verify_package()

    def test_children_commands_use_isolated_paths_and_frozen_exclusions(self):
        with tempfile.TemporaryDirectory() as tmp,patch.dict(os.environ,{},clear=True):
            root=Path(tmp);(root/'reproduction').mkdir();(root/'inputs').mkdir()
            (root/'reproduction/run_label_extension_targets.py').write_text('')
            for name in ('bb_exclusions.jsonl','pbb_exclusions.jsonl','prior_bb_orbits.jsonl','prior_pbb_orbits.jsonl','reserved_parent_orbits.jsonl'):
                (root/'inputs'/name).write_text('')
            commands=supervisor.family_commands(root,check.resource_plan())
            for family,command in commands.items():
                self.assertEqual(command[command.index('--workers')+1],'98')
                self.assertEqual(command[command.index('--prepare-workers')+1],'8')
                self.assertEqual(command[command.index('--target')+1],'2000')
                self.assertIn(str(root/'inputs'/f'prior_{family}_orbits.jsonl'),command)
            self.assertNotEqual(commands['bb'],commands['pbb'])
            index=commands['bb'].index('--bb-odd-quotas')
            self.assertEqual(commands['bb'][index+1:index+5],['400','600','600','400'])
            self.assertNotIn('--bb-odd-quotas',commands['pbb'])
            with patch.dict(os.environ,{'BB_ODD_QUOTAS':'none'}):
                without_quota=supervisor.family_commands(root,check.resource_plan())
                self.assertNotIn('--bb-odd-quotas',without_quota['bb'])
            with patch.dict(os.environ,{'BB_TARGET':'2100'}),self.assertRaises(ValueError):
                supervisor.family_commands(root,check.resource_plan())

    def test_bb_quota_validation_accepts_zero_bins_and_rejects_invalid_plans(self):
        with patch.dict(os.environ,{},clear=True):
            self.assertEqual(supervisor.bb_odd_quotas(2000),[400,600,600,400])
        for raw in ('none','NONE',''):
            with patch.dict(os.environ,{'BB_ODD_QUOTAS':raw},clear=True):
                self.assertIsNone(supervisor.bb_odd_quotas(2000))
        with patch.dict(os.environ,{'BB_ODD_QUOTAS':'0 0 0 2000'},clear=True):
            self.assertEqual(supervisor.bb_odd_quotas(2000),[0,0,0,2000])
        for raw in ('400 600 600', '400 600 600 400 0', '-1 601 600 800',
                    '400.0 600 600 400', '400 600 600 401', 'false', 'NaN 600 600 400'):
            with patch.dict(os.environ,{'BB_ODD_QUOTAS':raw},clear=True),self.assertRaises(ValueError):
                supervisor.bb_odd_quotas(2000)

    def test_stop_is_sent_only_to_wrapper_not_process_group(self):
        class Child:
            signals=[]
            def poll(self):return None
            def send_signal(self,s):self.signals.append(s)
        child=Child();supervisor.forward_stop({'bb':child})
        self.assertEqual(child.signals,[signal.SIGUSR1])

    def test_supervisor_lock_rejects_duplicate_start(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            with supervisor.supervisor_lock(root):
                with self.assertRaises(RuntimeError):
                    with supervisor.supervisor_lock(root):pass
            with supervisor.supervisor_lock(root):pass

    def test_shell_syntax_without_running_scripts(self):
        for path in list(HERE.glob('*.sh'))+[HERE/'job.sbatch']:
            subprocess.run(['bash','-n',str(path)],check=True,capture_output=True)

    def test_no_cluster_specific_paths_or_gpu_request(self):
        for path in [HERE/'job.sbatch',HERE/'submit_slurm.sh',HERE/'run_local.sh']:
            text=path.read_text()
            self.assertNotIn('/home/u004',text)
            self.assertNotIn('/opt/slurm',text)
            self.assertNotIn('--gres',text)


if __name__=='__main__':unittest.main()
