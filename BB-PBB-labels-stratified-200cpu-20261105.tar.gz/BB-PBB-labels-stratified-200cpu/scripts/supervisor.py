#!/usr/bin/env python3
"""One locked supervisor for the two CPU-only label tasks; restart is explicit."""
from __future__ import annotations
import argparse
from contextlib import contextmanager
from datetime import datetime,timezone
import fcntl
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

from check_environment import package_root,resource_plan,resource_snapshot,enforce_resources,verify_dependencies,verify_package,positive_env


def now():return datetime.now(timezone.utc).isoformat()

def write_json(path,value):
    temporary=path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n');temporary.replace(path)

@contextmanager
def supervisor_lock(root):
    control=root/'run_control';control.mkdir(parents=True,exist_ok=True)
    with (control/'supervisor.lock').open('a+') as stream:
        try:fcntl.flock(stream,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError as e:raise RuntimeError('This package already has a running supervisor') from e
        try:yield
        finally:fcntl.flock(stream,fcntl.LOCK_UN)

def process_start_token(pid):
    try:
        # The comm field may itself contain spaces/parentheses.
        text=Path(f'/proc/{pid}/stat').read_text();tail=text[text.rfind(')')+2:].split()
        return tail[19]
    except (OSError,IndexError):return None

def bb_odd_quotas(target):
    raw=os.environ.get('BB_ODD_QUOTAS','400 600 600 400').strip()
    if not raw or raw.lower()=='none':return None
    parts=raw.split()
    if len(parts)!=4 or any(not part.isascii() or not part.isdigit() for part in parts):
        raise ValueError('BB_ODD_QUOTAS requires four nonnegative integers for bins 3–7 / 9–13 / 15–19 / 21–25, or "none"')
    quotas=[int(part) for part in parts]
    if sum(quotas)!=target:
        raise ValueError(f'BB_ODD_QUOTAS sum {sum(quotas)} must equal BB_TARGET {target}')
    return quotas

def family_commands(root,plan):
    script=root/'reproduction/run_label_extension_targets.py'
    prepare=positive_env('PREPARE_WORKERS',8,integer=True)
    result={}
    for family in ('bb','pbb'):
        exclusion=root/'inputs'/f'{family}_exclusions.jsonl'
        prior=root/'inputs'/f'prior_{family}_orbits.jsonl'
        parents=root/'inputs/reserved_parent_orbits.jsonl'
        for required in (script,exclusion,prior,parents):
            if not required.is_file():raise RuntimeError('Missing packaged input: '+str(required))
        target=positive_env(family.upper()+'_TARGET',2000,integer=True)
        result[family]=[sys.executable,'-B','-u',str(script),'--family',family,
                       '--target',str(target),'--output-dir',str(root/'runs'/family),
                       '--workers',str(plan['workers'][family]),
                       '--prepare-workers',str(min(prepare,plan['workers'][family])),
                       '--batch-candidates',str(positive_env('BATCH_CANDIDATES',200,integer=True)),
                       '--max-batches',str(positive_env('MAX_BATCHES',1000,integer=True)),
                       '--exclude',str(exclusion),'--prior-orbits',str(prior),
                       '--reserved-parent-orbits',str(parents)]
        if family=='bb':
            quotas=bb_odd_quotas(target)
            if quotas is not None:result[family]+=['--bb-odd-quotas',*map(str,quotas)]
    return result

def forward_stop(children):
    for child in children.values():
        if child.poll() is None:
            # The target wrapper finishes its current complete batch before
            # stopping. Never send USR1 to an older driver or kill a group.
            try:child.send_signal(signal.SIGUSR1)
            except ProcessLookupError:pass

def foreground(root):
    with supervisor_lock(root):
        plan=resource_plan();snapshot=resource_snapshot();enforce_resources(plan,snapshot)
        commands=family_commands(root,plan)
        preflight={'checked_utc':now(),'package':verify_package(),'plan':plan,'resources':snapshot,'backend':verify_dependencies()}
        write_json(root/'run_control/preflight.json',preflight)
        affinity=sorted(os.sched_getaffinity(0));cut=plan['cpu_budgets']['bb']
        masks={'bb':set(affinity[:cut]),'pbb':set(affinity[cut:plan['total_cpus']])}
        children={};logs=[];stop={'requested':False,'reason':None}
        started=now()
        pid_info={'pid':os.getpid(),'process_start_token':process_start_token(os.getpid()),
                  'started_utc':started,'package_root':str(root),'slurm_job_id':os.environ.get('SLURM_JOB_ID')}
        write_json(root/'run_control/supervisor_pid.json',pid_info)
        def request_stop(signum,_frame):
            stop.update(requested=True,reason=signal.Signals(signum).name)
            forward_stop(children)
        previous={s:signal.getsignal(s) for s in (signal.SIGINT,signal.SIGTERM,signal.SIGUSR1)}
        for sig in previous:signal.signal(sig,request_stop)
        exit_codes={}
        try:
            for family,command in commands.items():
                if stop['requested']:break
                stream=(root/'logs'/f'{family}.log').open('a',buffering=1);logs.append(stream)
                stream.write('\n'+json.dumps({'event':'invocation','started_utc':now(),'command':command})+'\n');stream.flush()
                mask=masks[family]
                def set_affinity(mask=mask):os.sched_setaffinity(0,mask)
                children[family]=subprocess.Popen(command,cwd=root,stdout=stream,stderr=subprocess.STDOUT,
                                                 preexec_fn=set_affinity)
            while any(child.poll() is None for child in children.values()):
                for family,child in children.items():
                    code=child.poll()
                    if code is not None:exit_codes[family]=code
                # A real failure or partial-stop stops the peer after its
                # current safe checkpoint. One task completing normally does
                # not interrupt the other or change its CPU assignment.
                if any(code!=0 for code in exit_codes.values()) and not stop['requested']:
                    stop.update(requested=True,reason='peer_nonzero_exit');forward_stop(children)
                write_json(root/'run_control/supervisor_status.json',
                           {**pid_info,'updated_utc':now(),'state':'draining' if stop['requested'] else 'running',
                            'stop_reason':stop['reason'],'children':{f:c.pid for f,c in children.items()},
                            'exit_codes':exit_codes,'plan':plan})
                time.sleep(2)
            exit_codes.update({f:c.wait() for f,c in children.items()})
            completed=len(exit_codes)==2 and all(code==0 for code in exit_codes.values())
            write_json(root/'run_control/supervisor_status.json',
                       {**pid_info,'updated_utc':now(),'state':'completed' if completed else 'stopped_or_failed',
                        'stop_reason':stop['reason'],'exit_codes':exit_codes,'plan':plan})
            return 0 if completed else 75
        except BaseException:
            forward_stop(children)
            for child in children.values():child.wait()
            raise
        finally:
            for sig,handler in previous.items():signal.signal(sig,handler)
            for stream in logs:stream.close()

def request_local_stop(root):
    path=root/'run_control/supervisor_pid.json'
    if not path.exists():raise RuntimeError('No supervisor PID record')
    state=json.loads(path.read_text());pid=state['pid']
    if state.get('slurm_job_id'):
        raise RuntimeError('This supervisor belongs to Slurm; use the scheduler signal/stop commands')
    if (state.get('package_root')!=str(root) or not state.get('process_start_token')
            or process_start_token(pid)!=state['process_start_token']):
        raise RuntimeError('Supervisor is no longer running, or its PID record is stale')
    os.kill(pid,signal.SIGUSR1)
    print('Stop requested. Each family will finish its current batch (up to BATCH_CANDIDATES codes) before exiting; this can take hours. Inspect scripts/status.py until stopped. This command does not force-kill active solvers.')

def detach(root):
    if os.environ.get('SLURM_JOB_ID'):raise RuntimeError('Use foreground mode inside Slurm')
    # Fail before detaching if settings, inputs, packages, or resources are wrong.
    plan=resource_plan();enforce_resources(plan,resource_snapshot());family_commands(root,plan);verify_package();verify_dependencies()
    with supervisor_lock(root):pass
    log=(root/'logs/supervisor.log').open('a')
    child=subprocess.Popen([sys.executable,'-B','-u',str(Path(__file__).resolve()),'--foreground'],
                           cwd=root,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,
                           start_new_session=True,close_fds=True)
    log.close()
    print(f'Background supervisor PID {child.pid}; logs/supervisor.log; run scripts/status.py for actual task state.')
    return 0

def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    mode=parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--foreground',action='store_true');mode.add_argument('--detach',action='store_true');mode.add_argument('--stop',action='store_true')
    args=parser.parse_args(argv);root=package_root()
    for folder in ('logs','run_control'): (root/folder).mkdir(exist_ok=True)
    if args.stop:request_local_stop(root);return 0
    return foreground(root) if args.foreground else detach(root)

if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception as error:print(f'Launcher stopped: {type(error).__name__}: {error}',file=sys.stderr);raise SystemExit(1)
