#!/usr/bin/env python3
"""Read-only Linux resource/dependency preflight; never install or run searches."""
from __future__ import annotations
import argparse
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tempfile

GIB = 1024**3

def package_root():
    here = Path(__file__).resolve().parent
    for candidate in (here.parent, here.parent.parent):
        if (candidate / 'reproduction').is_dir():
            return candidate
    raise RuntimeError('Cannot locate package root')

def positive_env(name, default, *, integer=False):
    raw = os.environ.get(name, str(default))
    value = int(raw) if integer else float(raw)
    if value <= 0 or not math.isfinite(value):
        raise ValueError(name + ' must be positive and finite')
    return value

def resource_plan():
    total = positive_env('TOTAL_CPUS', 200, integer=True)
    bb = positive_env('BB_CPUS', 100, integer=True)
    pbb = positive_env('PBB_CPUS', 100, integer=True)
    reserve = positive_env('WORKER_RESERVE', 2, integer=True)
    if bb+pbb != total or min(bb,pbb) <= reserve:
        raise ValueError('Require BB_CPUS + PBB_CPUS = TOTAL_CPUS, each greater than WORKER_RESERVE')
    workers = {'bb': bb-reserve, 'pbb': pbb-reserve}
    memory = (sum(workers.values()) * positive_env('MEMORY_GIB_PER_WORKER', 2)
              + positive_env('MEMORY_OVERHEAD_GIB', 8))
    return {'total_cpus': total, 'cpu_budgets': {'bb':bb,'pbb':pbb}, 'workers':workers,
            'coordinator_cpu_reserve_per_family':reserve, 'planned_memory_gib':memory,
            'minimum_disk_gib':positive_env('MIN_DISK_GIB',10),
            'memory_note':'Conservative user-configurable planning threshold, not a measured peak or solver guarantee.'}

def integer_file(path):
    try:
        text=Path(path).read_text().strip()
        return None if text=='max' else int(text)
    except (OSError, ValueError):
        return None

def cgroup_paths():
    """Inspect own cgroup and ancestors so limits above the leaf are respected."""
    roots=[]
    try: lines=Path('/proc/self/cgroup').read_text().splitlines()
    except OSError: return []
    for line in lines:
        _, controllers, relative=line.split(':',2)
        if controllers=='': root=Path('/sys/fs/cgroup')
        elif 'memory' in controllers.split(','): root=Path('/sys/fs/cgroup/memory')
        elif 'cpu' in controllers.split(','): root=Path('/sys/fs/cgroup/cpu')
        else: continue
        # Namespace-relative paths containing '..' cannot be trusted to identify
        # a host cgroup; still inspect the visible mount root in that case.
        parts=Path(relative).parts
        leaf=root if '..' in parts else root / relative.lstrip('/')
        for item in [leaf,*leaf.parents]:
            if item==root or root in item.parents:
                roots.append(item)
            if item==root:break
    return list(dict.fromkeys(roots+[Path('/sys/fs/cgroup')]))

def resource_snapshot():
    cpu_limits={}
    if hasattr(os,'sched_getaffinity'):
        cpu_limits['process_affinity']=len(os.sched_getaffinity(0))
    if os.cpu_count(): cpu_limits['visible_os_cpus']=os.cpu_count()
    if os.environ.get('SLURM_CPUS_PER_TASK'):
        cpu_limits['slurm_cpus_per_task']=int(os.environ['SLURM_CPUS_PER_TASK'])
    memory_limits={}
    try:
        mem={key:int(value.split()[0])*1024 for key,value in
             (line.split(':',1) for line in Path('/proc/meminfo').read_text().splitlines())}
        if 'MemAvailable' in mem: memory_limits['host_available_bytes']=mem['MemAvailable']
    except (OSError,ValueError):pass
    for index,path in enumerate(cgroup_paths()):
        cap=integer_file(path/'memory.max')
        used=integer_file(path/'memory.current')
        if cap is None:
            cap=integer_file(path/'memory.limit_in_bytes');used=integer_file(path/'memory.usage_in_bytes')
        if cap is not None and 0<cap<2**60:
            memory_limits[f'cgroup_{index}_remaining_bytes']=max(0,cap-(used or 0))
        try:
            quota,period=(path/'cpu.max').read_text().split()
            if quota!='max':cpu_limits[f'cgroup_{index}_quota']=int(quota)//int(period)
        except (OSError,ValueError):
            quota=integer_file(path/'cpu.cfs_quota_us');period=integer_file(path/'cpu.cfs_period_us')
            if quota is not None and quota>0 and period:
                cpu_limits[f'cgroup_{index}_quota']=quota//period
    if os.environ.get('SLURM_MEM_PER_NODE'):
        memory_limits['slurm_memory_allocation_bytes']=int(os.environ['SLURM_MEM_PER_NODE'])*1024**2
    elif os.environ.get('SLURM_MEM_PER_CPU') and os.environ.get('SLURM_CPUS_PER_TASK'):
        memory_limits['slurm_memory_allocation_bytes']=(int(os.environ['SLURM_MEM_PER_CPU'])*1024**2
                                                      *int(os.environ['SLURM_CPUS_PER_TASK']))
    root=package_root()
    return {'platform':platform.platform(),'machine':platform.machine(),
            'cpu_limits':cpu_limits,'effective_cpus':min(cpu_limits.values()) if cpu_limits else None,
            'memory_limits_bytes':memory_limits,
            'available_memory_bytes':min(memory_limits.values()) if memory_limits else None,
            'disk_free_bytes':shutil.disk_usage(root).free,
            'slurm_job_id':os.environ.get('SLURM_JOB_ID'),
            'resource_scope_note':'Visibility is not permission: request/confirm the CPU allocation before launch; Slurm checks must run inside the allocation.'}

def enforce_resources(plan,snapshot):
    errors=[]
    if sys.platform!='linux':errors.append('Production launch is supported on Linux servers only')
    available=snapshot['effective_cpus']
    if available is None or available<plan['total_cpus']:
        errors.append(f"Need {plan['total_cpus']} allocated/visible CPUs, detected {available}")
    memory=snapshot['available_memory_bytes']
    if memory is None or memory < plan['planned_memory_gib']*GIB:
        errors.append(f"Memory planning threshold {plan['planned_memory_gib']:.1f} GiB exceeds available/allocated {(memory or 0)/GIB:.1f} GiB; reduce both CPU budgets or explicitly revise MEMORY_GIB_PER_WORKER after measurement")
    if snapshot['disk_free_bytes']<plan['minimum_disk_gib']*GIB:
        errors.append('Insufficient free disk in the package filesystem')
    if errors:raise RuntimeError('; '.join(errors))

def verify_dependencies():
    if sys.version_info[:2]!=(3,12):raise RuntimeError('Use the tested Python 3.12 environment')
    versions={}
    requirements=package_root()/'reproduction/requirements-bb-distance.txt'
    for line in requirements.read_text().splitlines():
        line=line.strip()
        if not line or line.startswith('#'):continue
        package,expected=line.split('==')
        actual=importlib.metadata.version(package)
        if actual!=expected:raise RuntimeError(f'{package}: expected {expected}, found {actual}')
        versions[package]=actual
    compiler=os.environ.get('CXX') or shutil.which('g++') or shutil.which('clang++')
    if not compiler:raise RuntimeError('A C++17 compiler is required for full-Aut identities; run install_env.sh or set CXX')
    compiler_version=subprocess.run([compiler,'--version'],check=True,capture_output=True,text=True).stdout.splitlines()[0]
    sys.path.insert(0,str(package_root()/'reproduction'))
    import bb_distance_backend as bb
    import pbb_distance_backend as pbb
    bb_manifest=bb.backend_manifest();pbb_manifest=pbb.backend_manifest()
    bb_import=bb.init_worker();pbb_import=pbb.init_worker()
    from training_paper.build_orbit_map import compile_helper,validate_reference
    with tempfile.TemporaryDirectory(prefix='pbb-orbit-preflight-') as directory:
        binary,_command=compile_helper(directory,cxx=compiler)
        compiler_reference=validate_reference(binary)
    return {'python':sys.version,'versions':versions,'compiler':compiler,'compiler_version':compiler_version,'codedistance_commit':bb.SOURCE_COMMIT,
            'bb_import_file':bb_import['codedistance_import_file'],
            'pbb_import_file':pbb_import['codedistance_import_file'],
            'bb_search_scope':bb_manifest['search_scope'],'pbb_search_scope':pbb_manifest['search_scope'],
            'full_aut_compiled_reference':compiler_reference,'actual_distance_trials':0}

def verify_package():
    root=package_root();path=root/'package_manifest.json'
    if not path.exists():return {'state':'source_tree_no_package_manifest'}
    manifest=json.loads(path.read_text());files=manifest.get('files')
    if not isinstance(files,dict) or not files:raise RuntimeError('Package manifest has no file inventory')
    for name,expected in files.items():
        relative=Path(name)
        if relative.is_absolute() or '..' in relative.parts:raise RuntimeError('Unsafe path in package manifest')
        source=root/relative
        if (not source.resolve().is_relative_to(root.resolve())
                or not source.is_file() or source.is_symlink()
                or source.stat().st_size!=expected['bytes']):
            raise RuntimeError('Missing/changed packaged file: '+name)
        digest=hashlib.sha256()
        with source.open('rb') as stream:
            for block in iter(lambda:stream.read(1024*1024),b''):digest.update(block)
        if digest.hexdigest()!=expected['sha256']:raise RuntimeError('Packaged file hash changed: '+name)
    return {'state':'verified','file_count':len(files)}

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--enforce',action='store_true')
    p.add_argument('--backend',action='store_true')
    p.add_argument('--output',type=Path)
    args=p.parse_args(argv)
    report={'package':verify_package(),'plan':resource_plan(),'resources':resource_snapshot()}
    if args.enforce:enforce_resources(report['plan'],report['resources'])
    if args.backend:report['backend']=verify_dependencies()
    text=json.dumps(report,ensure_ascii=False,indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(text+'\n')
    print(text)

if __name__=='__main__':main()
