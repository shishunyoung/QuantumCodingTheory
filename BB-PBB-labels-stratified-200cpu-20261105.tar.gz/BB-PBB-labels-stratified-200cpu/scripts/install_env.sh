#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "$0")/common.sh"
[[ "$(uname -s)" == Linux ]] || { echo 'Run this installation script on the destination Linux server.' >&2; exit 1; }
CONDA_BIN="${CONDA_EXE:-$(command -v conda || true)}"
if [[ -n "$CONDA_BIN" && ! -x "$CONDA_BIN" ]]; then CONDA_BIN=''; fi
ENV_PREFIX="$PACKAGE_ROOT/.env"
missing_prerequisites() {
    echo "$1" >&2
    echo 'Ask the administrator to expose Python 3.12 with venv and a C++17 compiler, or an existing Conda installation.' >&2
    echo 'Example for Ubuntu 24.04 (administrator only): sudo apt-get install python3.12 python3.12-venv g++' >&2
    echo 'Other distributions need their matching package-manager commands. No system packages or installer downloads were attempted.' >&2
    exit 1
}
if [[ ! -x "$ENV_PREFIX/bin/python" ]]; then
    [[ ! -e "$ENV_PREFIX" ]] || { echo 'The .env path exists but has no Python. Inspect it; this script will not delete it.' >&2; exit 1; }
    if [[ -n "$CONDA_BIN" ]]; then
        "$CONDA_BIN" create -y -p "$ENV_PREFIX" --override-channels -c conda-forge --strict-channel-priority python=3.12 pip
    else
        PYTHON312="${PYTHON312_BIN:-$(command -v python3.12 || true)}"
        [[ -n "$PYTHON312" && -x "$PYTHON312" ]] || missing_prerequisites 'Neither Conda nor an executable Python 3.12 was found. Set PYTHON312_BIN to an existing interpreter if needed.'
        [[ -n "${CXX:-}" ]] || missing_prerequisites 'Python 3.12 is available, but no C++ compiler was found. Set CXX to an existing compiler if needed.'
        "$PYTHON312" -c 'import sys; assert sys.version_info[:2] == (3,12), "Python 3.12 is required"'
        if ! "$PYTHON312" -m venv "$ENV_PREFIX"; then
            missing_prerequisites 'Python could not create the virtual environment. Its venv/ensurepip component may be missing. Inspect the partial .env before retrying.'
        fi
    fi
fi
if [[ -z "${CXX:-}" ]]; then
    [[ -n "$CONDA_BIN" && -d "$ENV_PREFIX/conda-meta" ]] || missing_prerequisites 'A C++17 compiler is required. An existing venv cannot receive Conda compiler packages; set CXX or ask the administrator to install a compiler.'
    "$CONDA_BIN" install -y -p "$ENV_PREFIX" --override-channels -c conda-forge --strict-channel-priority cxx-compiler
    for candidate in "$ENV_PREFIX/bin/"*-conda-linux-gnu-c++; do
        if [[ -x "$candidate" ]]; then export CXX="$candidate"; break; fi
    done
fi
[[ -n "${CXX:-}" ]] || missing_prerequisites 'The compiler installation completed without an identifiable C++ executable; set CXX explicitly.'
"$CXX" --version >/dev/null
"$ENV_PREFIX/bin/python" -c 'import sys; assert sys.version_info[:2] == (3,12), "Existing .env must use Python 3.12"'
"$ENV_PREFIX/bin/python" -m pip install -r "$PACKAGE_ROOT/reproduction/requirements-bb-distance.txt"
"$ENV_PREFIX/bin/python" -m pip check
"$ENV_PREFIX/bin/python" "$SCRIPT_DIR/check_environment.py" --backend
echo "Environment ready: $ENV_PREFIX/bin/python"
