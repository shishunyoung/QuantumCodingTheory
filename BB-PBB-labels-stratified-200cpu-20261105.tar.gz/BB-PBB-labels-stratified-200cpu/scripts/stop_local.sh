#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "$0")/common.sh"
[[ -x "$LABEL_PYTHON" ]] || { echo 'Set LABEL_PYTHON to the installed Python.' >&2; exit 1; }
exec "$LABEL_PYTHON" "$SCRIPT_DIR/supervisor.py" --stop
