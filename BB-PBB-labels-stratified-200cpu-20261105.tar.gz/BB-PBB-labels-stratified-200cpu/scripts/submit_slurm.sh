#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "$0")/common.sh"
SBATCH="${SBATCH_BIN:-$(command -v sbatch || true)}"
[[ -n "$SBATCH" && -x "$SBATCH" ]] || { echo 'sbatch not found. Set SBATCH_BIN or ask the administrator about the scheduler.' >&2; exit 1; }
[[ -x "$LABEL_PYTHON" ]] || { echo 'Python environment missing; install it first.' >&2; exit 1; }
# Only parse our allocation arithmetic here. Resources must be checked again
# INSIDE the Slurm allocation, not against the login node's CPU affinity.
"$LABEL_PYTHON" -c 'import sys; sys.path.insert(0,sys.argv[1]); import check_environment as c; print(c.resource_plan())' "$SCRIPT_DIR"
args=(--parsable --job-name=bb-pbb-labels --nodes=1 --ntasks=1
      --cpus-per-task="${TOTAL_CPUS:-200}" --mem="${SLURM_MEMORY:-408G}"
      --time="${SLURM_TIME:-7-00:00:00}" --signal=B:USR1@3600
      --chdir="$PACKAGE_ROOT" --output="$PACKAGE_ROOT/logs/slurm-%j.out"
      --open-mode=append --export=ALL)
[[ -z "${SLURM_PARTITION:-}" ]] || args+=(--partition="$SLURM_PARTITION")
[[ -z "${SLURM_ACCOUNT:-}" ]] || args+=(--account="$SLURM_ACCOUNT")
[[ -z "${SLURM_QOS:-}" ]] || args+=(--qos="$SLURM_QOS")
"$SBATCH" "${args[@]}" "$SCRIPT_DIR/job.sbatch"
